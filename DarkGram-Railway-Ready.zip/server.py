"""Teegram server: threaded TCP server, SQLite storage, push events.

Run:  python server.py [--host 0.0.0.0] [--port 8765] [--http]
"""
import argparse
import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import secrets
import socket
import sqlite3
import ssl
import subprocess
import sys
import shutil
import threading
import time
import uuid
from pathlib import Path
from collections import defaultdict, deque

import common
from rooms import make_rooms
from social import make_social
from adminapi import make_adminapi, PREM_MARK, OFFICIAL_MARK, NEWS_MARK
from bots import make_bots, ApiError
from stories import make_stories
from common import (DATA_DIR, GIFTS, GIFT_MAP, NFT_GIFTS, NFT_MAP, NFT_BACKDROPS, STAR_PER_USD, MAX_FILE, MAX_TEXT, REACTIONS, STICKERS, STICKER_PACKS, STATUS_EMOJIS, SECURITY_QUESTIONS, SESSION_TTL, USERNAME_RE,
                    avatar_folder_for_chat, avatar_folder_for_user, check_password_rules, connect_db, encode_frame,
                    hash_secret, media_info, avatar_pics, valid_pic_name, retire_avatar, migrate_legacy_uploads, normalize_answer, now, recv_frame,
                    remove_upload, resolve_upload, store_avatar, thumb_rel, upload_relpath, verify_secret)

RESERVED = {"admin", "administrator", "root", "system", "support", "telegram", "null", "botfather", "darkgramai", "darkstickers", "spam", "game"}
MAX_FAILS = 5
LOCK_SECONDS = 300
CALL_RING_SECONDS = 45
CALL_GRACE_SECONDS = int(os.environ.get("TEEGRAM_CALL_GRACE", "60"))          # a dropped call participant has this long to come back before the call ends
ADMIN_USER = os.environ.get("TEEGRAM_ADMIN", "teegram").strip().lower()   # only this user posts in the channel
# DarkGram owners: comma-separated usernames with full admin-panel access
# (set TEEGRAM_ADMINS on the host; the legacy single ADMIN_USER always stays an owner too)
ADMIN_USERS = {x.strip().lower() for x in os.environ.get("TEEGRAM_ADMINS", "").split(",") if x.strip()} | {ADMIN_USER}
LABELER_USERS = {"reza", "msmdjdjdj"}  # only these two accounts may apply scam/fake labels
OWNER_USERNAME = os.environ.get("TEEGRAM_OWNER", "Reza_id_tell").strip().lower()   # THE owner of DarkGram: special badge 3
CHANNEL_TITLE = "اطلاعیه پریمیوم"
CHANNEL_DESC = "⭐ کانال رسمی دارک گرام — اطلاعیه‌های پریمیوم و اخبار مهم؛ فقط مدیریت پیام می‌ذاره"
MEDIA_KEY_TTL = 24 * 3600
DEFAULT_ICE = [{"urls": ["stun:stun.cloudflare.com:3478", "stun:stun.l.google.com:19302",
                         "stun:stun1.l.google.com:19302", "stun:global.stun.twilio.com:3478"]}]
FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
BADGE_MARK = {1: "\u2063\u200b", 2: "\u2063\u200c"}     # invisible suffix after a verified name; the web UI turns it into a tick
CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\u2063]")
CEMJ_RE = re.compile(r"\uE001\d{1,2}\uE002")   # MixOrder custom-emoji tokens in message text (premium only)      # \u2063 is stripped from all user input -> nobody can fake a tick


class Fail(Exception):
    """Expected, user-facing error."""


def clean_line(text, limit, field="مقدار"):
    text = CTRL_RE.sub("", str(text or "")).replace("\r", " ").replace("\n", " ").strip()
    if len(text) > limit:
        raise Fail(f"{field} خیلی طولانیه (حداکثر {limit} کاراکتر)")
    return text


_LOG_LOCK = threading.Lock()


def log(*a):
    line = time.strftime("%H:%M:%S") + " " + " ".join(str(x) for x in a)
    print(line, flush=True)
    try:                                   # keep a rotating log file (data/teegram.log, 3 x ~1 MB) so a crash can be diagnosed later
        p = common.DATA_DIR / "teegram.log"
        with _LOG_LOCK:
            if p.exists() and p.stat().st_size > 1_000_000:
                for i in (2, 1):
                    o = p.with_name(f"teegram.log.{i}")
                    if o.exists():
                        o.replace(p.with_name(f"teegram.log.{i + 1}"))
                p.replace(p.with_name("teegram.log.1"))
            with open(p, "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d ") + line + "\n")
    except Exception:
        pass


RoomsMixin = make_rooms(Fail, common, ADMIN_USER)
SocialMixin = make_social(Fail, common)
BotsMixin = make_bots(Fail, common, log)
StoriesMixin = make_stories(Fail, common, log)
AdminApiMixin = make_adminapi(Fail, common, log)


class Conn:
    def __init__(self, server, sock, addr):
        self.server, self.sock, self.addr = server, sock, addr
        self.ip = addr[0]
        self.uid = None
        self.db = None
        self.caps = set()           # what this client can do (the web UI announces {"call"})
        self.session_id = None      # row in `sessions` when logged in with a persistent session
        self.send_lock = threading.Lock()
        self.alive = True
        self.vis_at = time.time()
        self.vis = True             # is the app visible on screen? (web UI reports it; hidden -> a push wakes the phone)

    def send(self, obj):
        if not self.alive:
            return
        try:
            data = encode_frame(obj)
            with self.send_lock:
                self.sock.sendall(data)
        except Exception:
            self.alive = False

    def relay(self, obj, video=False):
        """Queue a call frame (audio/video). A slow receiver never blocks the sender: old frames are dropped,
        audio always goes out before video."""
        if getattr(self, "_rq", None) is None:
            self._rq, self._rvq, self._rev = deque(maxlen=60), deque(maxlen=2), threading.Event()
            threading.Thread(target=self._relay_loop, daemon=True).start()
        (self._rvq if video else self._rq).append(obj)
        self._rev.set()

    def _relay_loop(self):
        while self.alive:
            self._rev.wait(5)
            self._rev.clear()
            while self.alive and (self._rq or self._rvq):
                try:
                    obj = self._rq.popleft() if self._rq else self._rvq.popleft()
                except IndexError:
                    break
                self.send(obj)

    def close(self):
        self.alive = False
        try:
            if getattr(self, "_rev", None):
                self._rev.set()
        except Exception:
            pass
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


class TeegramServer(RoomsMixin, SocialMixin, BotsMixin, StoriesMixin, AdminApiMixin):
    def __init__(self, host="127.0.0.1", port=common.DEFAULT_PORT, tls=False, db_path=None, web_port=None):
        self.host, self.port, self.tls = host, port, tls
        self.web_port, self.web = web_port, None
        self.db_path = db_path or common.DB_PATH
        self._admin_usernames = ADMIN_USERS
        self.sessions = defaultdict(list)       # uid -> [Conn]
        self.sessions_lock = threading.Lock()
        self.ip_hits = defaultdict(deque)       # ip -> timestamps of auth attempts
        self.send_hits = defaultdict(deque)     # uid -> timestamps of sent messages
        self.conns_lock = threading.Lock()
        self.conns_total = 0
        self.conns_by_ip = defaultdict(int)     # raw TCP connections currently open, before any login (flood guard)
        self.notify_q = defaultdict(lambda: deque(maxlen=50))   # uid -> recent {seq, chat_id, title, text} for the Android app's long-poll
        self.notify_seq = defaultdict(int)
        self.notify_cv = threading.Condition()
        self.listener = None
        self.ssl_ctx = None
        self._stop = threading.Event()
        self._rooms_init()
        self._bots_init()
        self.calls = {}                         # call_id -> call dict (voice calls)
        self.user_call = {}                     # uid -> call_id
        self.calls_lock = threading.Lock()
        self._learn_lock = threading.Lock()
        try:
            self.ice_servers = json.loads(os.environ.get("TEEGRAM_ICE", "")) or DEFAULT_ICE
        except ValueError:
            self.ice_servers = DEFAULT_ICE
        self._secret = self._load_secret()
        boot = connect_db(self.db_path)         # make sure schema exists
        try:
            qc = boot.execute("PRAGMA quick_check").fetchone()[0]
            if qc != "ok":
                log("WARNING: database integrity check failed:", qc, "- stop the server and restore data/teegram.db from a copy")
        except sqlite3.Error as e:
            log("WARNING: database check error:", repr(e))
        self._ensure_channel(boot)
        self._ensure_botfather(boot)
        self._ensure_ai_bot(boot)
        self._ensure_sticker_bot(boot)
        self._purge_deleted_bots(boot)
        self._ensure_spam_bot(boot)
        self._ensure_game_bot(boot)
        self._ensure_admins(boot)
        self._pw_reset_hook(boot)
        self._restrict_once_hook(boot)
        self._rename_hook(boot)
        self._avatar_fix_hook(boot)
        self._mass_join_hook(boot)
        self._ensure_group_owners(boot)
        self._adminapi_init(boot)
        n = migrate_legacy_uploads(boot)
        if n:
            log(f"moved {n} old upload(s) into data/uploads/")
        with boot:                              # rooms live in RAM only: whatever was open before a restart is over
            boot.execute("UPDATE rooms_log SET closed_at=? WHERE closed_at IS NULL", (now(),))
        boot.close()

    # ------------------------------------------------------------------ run
    def start(self):
        if self.tls:
            self.ssl_ctx = self._make_ssl_context()
            self.tls = self.ssl_ctx is not None
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind((self.host, self.port))
        self.listener.listen(64)
        self.port = self.listener.getsockname()[1]
        threading.Thread(target=self._accept_loop, daemon=True).start()
        threading.Thread(target=self._song_sweeper, daemon=True).start()
        threading.Thread(target=self._extras_sweeper, daemon=True).start()
        log(f"server listening on {self.host}:{self.port} (tls={'on' if self.tls else 'off'})")
        if self.web_port is not None:
            from webgw import WebGateway
            self.web = WebGateway(self, self.host, self.web_port)
            self.web_port = self.web.start()
        return self.port

    def _extras_sweeper(self):
        """Every 5 minutes: expired stories + their files, old bot updates."""
        while not self._stop.is_set():
            self._stop.wait(300)
            for fn in (self.sweep_stories, self.sweep_bots):
                try:
                    fn()
                except Exception as e:
                    log("sweep error:", fn.__name__, repr(e))

    def serve_forever(self):
        if self.listener is None:
            self.start()
        try:
            while not self._stop.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
        self.stop()

    def stop(self):
        self._stop.set()
        if self.web:
            self.web.stop()
        try:
            self.listener.close()
        except Exception:
            pass
        with self.sessions_lock:
            conns = [c for lst in self.sessions.values() for c in lst]
        for c in conns:
            c.close()

    def _cert_names(self):
        names = {"localhost", "127.0.0.1", lan_ip(), socket.gethostname()}
        names |= {n.strip() for n in os.environ.get("TEEGRAM_CERT_NAMES", "").split(",") if n.strip()}
        f = DATA_DIR / "cert_names.txt"            # public IP / domain names (also filled in automatically, see learn_host)
        if f.exists():
            names |= {n.strip() for n in f.read_text(encoding="utf-8").split() if n.strip() and not n.startswith("#")}
        return sorted(names)

    def _make_ssl_context(self):
        """Self-signed certificate valid for localhost, this PC's name, its LAN IP and the public IP people use.
        Made with the `cryptography` package (installed by start.bat); openssl is the fallback.
        The certificate is also a 'CA' so it can be installed on a phone (Android: Install a certificate -> CA)
        and then Chrome trusts it: no red warning, the app can be installed. Returns None (-> http) on failure."""
        crt, key, meta = DATA_DIR / "server.crt", DATA_DIR / "server.key", DATA_DIR / "server.names"
        self._crt_path, self._key_path, self._meta_path = crt, key, meta
        names = self._cert_names()
        text = meta.read_text(encoding="utf-8") if meta.exists() else ""
        have = [x for x in text.split() if not x.startswith("#")]
        # an existing certificate is KEPT even when this PC gets a new address: a new certificate means a new fingerprint and the phone
        # app (which trusts one fingerprint) would refuse to connect. Delete data/server.crt by hand to make a fresh one.
        if not (crt.exists() and key.exists()) or "#v2" not in text:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            # keep the names of earlier certificates too (a changing LAN/VPN address must not make a NEW certificate on every start:
            # that breaks the phone app's pinned fingerprint). The list only grows, up to 12 names.
            merged = sorted(set(names) | set(have))
            if len(merged) <= 12:
                names = merged
            if not (self._cert_cryptography(crt, key, names) or self._cert_openssl(crt, key, names)):
                log("could not create a certificate (pip install cryptography) -> falling back to plain http")
                return None
            meta.write_text("#v2\n" + "\n".join(names), encoding="utf-8")
            try:
                os.chmod(key, 0o600)
            except OSError:
                pass
            log("generated self-signed certificate in data/ for:", ", ".join(names))
        self.cert_names = names
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        try:
            ctx.num_tickets = 0        # no TLS 1.3 session tickets: they are written right after the handshake, racing with the
        except (AttributeError, ValueError):   # first request on the same socket (rare stalls seen in tests)
            pass
        ctx.load_cert_chain(str(crt), str(key))
        return ctx

    def learn_host(self, host, client_ip=None):
        """Someone opened the site through an IPv4 address the certificate does not cover (e.g. the public/static IP):
        add it, make a new certificate and use it for new connections. (Phones must install the new one once.)"""
        if not self.ssl_ctx or host in getattr(self, "cert_names", ()) or len(getattr(self, "cert_names", ())) > 12:
            return
        if getattr(self, "keep_cert", True):
            return                                  # never replace the certificate behind the phones' backs
        import ipaddress
        try:
            ip = ipaddress.ip_address(host)
            src = ipaddress.ip_address(client_ip or "")
        except ValueError:
            return
        if not (src.is_private or src.is_loopback):
            return          # SECURITY: a stranger on the internet must never be able to make the server replace its certificate
        if ip.version != 4 or ip.is_unspecified or ip.is_multicast:
            return
        with self._learn_lock:
            if host in self.cert_names:
                return
            f = DATA_DIR / "cert_names.txt"
            old = f.read_text(encoding="utf-8") if f.exists() else ""
            f.write_text(old.rstrip() + "\n" + host + "\n", encoding="utf-8")
            names = self._cert_names()
            if self._cert_cryptography(self._crt_path, self._key_path, names) or \
                    self._cert_openssl(self._crt_path, self._key_path, names):
                self._meta_path.write_text("#v2\n" + "\n".join(names), encoding="utf-8")
                self.cert_names = names
                try:
                    self.ssl_ctx.load_cert_chain(str(self._crt_path), str(self._key_path))
                except (ssl.SSLError, OSError) as e:
                    log("reloading certificate failed:", repr(e))
                log("new certificate now also covers", host)

    @staticmethod
    def _cert_cryptography(crt, key, names):
        try:
            import datetime
            import ipaddress
            from cryptography import x509
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import rsa
            from cryptography.x509.oid import NameOID
        except ImportError:
            return False
        try:
            k = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            san = []
            for n in names:
                try:
                    san.append(x509.IPAddress(ipaddress.ip_address(n)))
                except ValueError:
                    san.append(x509.DNSName(n))
            nm = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Teegram")])
            now_ = datetime.datetime.now(datetime.timezone.utc)
            cert = (x509.CertificateBuilder().subject_name(nm).issuer_name(nm).public_key(k.public_key())
                    .serial_number(x509.random_serial_number()).not_valid_before(now_ - datetime.timedelta(days=1))
                    .not_valid_after(now_ + datetime.timedelta(days=3650))
                    .add_extension(x509.SubjectAlternativeName(san), critical=False)
                    .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
                    .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=True, key_cert_sign=True,
                                                 content_commitment=False, data_encipherment=False, key_agreement=False,
                                                 crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
                    .add_extension(x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
                    .sign(k, hashes.SHA256()))
            key.write_bytes(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                            serialization.NoEncryption()))
            crt.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
            return True
        except Exception as e:
            log("cryptography cert failed:", repr(e))
            return False

    @staticmethod
    def _cert_openssl(crt, key, names):
        import ipaddress
        san = []
        for n in names:
            try:
                ipaddress.ip_address(n)
                san.append(f"IP:{n}")
            except ValueError:
                san.append(f"DNS:{n}")
        try:
            subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", str(key),
                            "-out", str(crt), "-days", "3650", "-subj", "/CN=Teegram",
                            "-addext", "subjectAltName=" + ",".join(san),
                            "-addext", "basicConstraints=critical,CA:TRUE",
                            "-addext", "keyUsage=critical,digitalSignature,keyEncipherment,keyCertSign"], check=True, capture_output=True)
            return True
        except (OSError, subprocess.CalledProcessError):
            return False

    def _ensure_channel(self, db):
        """The official premium announcement channel: EVERY user is a member, only admins post."""
        with db:
            row = db.execute("SELECT id FROM chats WHERE channel=1 LIMIT 1").fetchone()
            if row is None:
                cur = db.execute("INSERT INTO chats(kind, title, owner_id, created_at, channel, description) "
                                 "VALUES ('group',?,NULL,?,1,?)",
                                 (CHANNEL_TITLE, now(), CHANNEL_DESC))
                cid = cur.lastrowid
            else:
                cid = row["id"]
                db.execute("UPDATE chats SET title=?, description=? WHERE id=?",
                           (CHANNEL_TITLE, CHANNEL_DESC, cid))
            db.execute("INSERT OR IGNORE INTO members(chat_id, user_id, joined_at) "
                       "SELECT ?, id, ? FROM users WHERE is_bot=0", (cid, now()))
            if os.environ.get("DG_WIPE_ANNOUNCE"):
                n = db.execute("SELECT COUNT(*) FROM messages WHERE chat_id=?", (cid,)).fetchone()[0]
                if n:
                    db.execute("DELETE FROM reactions WHERE message_id IN "
                               "(SELECT id FROM messages WHERE chat_id=?)", (cid,))
                    db.execute("DELETE FROM messages WHERE chat_id=?", (cid,))
                    db.execute("UPDATE chats SET pinned_id=NULL WHERE id=?", (cid,))
                    print(f"[DarkGram] announcement history wiped: {n} messages", flush=True)
            cur = db.execute("SELECT avatar_at FROM chats WHERE id=?", (cid,)).fetchone()
            if not cur["avatar_at"]:
                try:
                    raw = (Path(__file__).parent / "announce_avatar.jpg").read_bytes()
                    rel = store_avatar(avatar_folder_for_chat(cid, CHANNEL_TITLE), raw)
                    db.execute("UPDATE chats SET avatar=?, avatar_at=? WHERE id=?",
                               (rel, int(time.time() * 1000), cid))
                    print("[DarkGram] announcement avatar set", flush=True)
                except Exception as e:
                    print("[DarkGram] announcement avatar failed:", e, flush=True)
        return cid


    def _restrict_once_hook(self, db):
        """One-shot timed restriction: DG_RESTRICT_ONCE='username:seconds'.
        Applies once at boot (owner self-test of the restriction system)."""
        spec = os.environ.get("DG_RESTRICT_ONCE", "")
        if ":" not in spec:
            return
        uname, secs = spec.rsplit(":", 1)
        uname = uname.strip().lower()
        try:
            secs = int(secs)
        except Exception:
            return
        if not uname or secs <= 0:
            return
        row = db.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (uname,)).fetchone()
        if not row:
            log("restrict once: user not found:", uname)
            return
        db.execute("UPDATE users SET restricted_until=? WHERE id=?",
                   (int(time.time()) + secs, row[0]))
        db.commit()
        log("restrict once: user", row[0], "restricted for", secs, "s")

    def _pw_reset_hook(self, db):
        """One-shot operator password reset: DG_PW_RESET='username:newpassword'.
        Applies once at boot, kills the user's sessions, logs no secret."""
        spec = os.environ.get("DG_PW_RESET", "")
        if ":" not in spec:
            return
        uname, newpw = spec.split(":", 1)
        uname = uname.strip().lower()
        if not uname or len(newpw) < 6:
            return
        row = db.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (uname,)).fetchone()
        if not row:
            log("pw reset: user not found:", uname)
            return
        salt, digest = hash_secret(newpw[:128])
        db.execute("UPDATE users SET pw_salt=?, pw_hash=?, failed_logins=0, locked_until=0 WHERE id=?",
                   (salt, digest, row[0]))
        db.execute("DELETE FROM sessions WHERE user_id=?", (row[0],))
        db.commit()
        log("pw reset applied for:", uname)


    def _mass_join_hook(self, db):
        """One-shot bulk join: DG_MASS_JOIN='<chat username or id>' adds every
        human (non-bot, non-banned) user as a member of that group/channel."""
        spec = os.environ.get("DG_MASS_JOIN", "").strip().lstrip("@")
        if not spec:
            return
        chat = db.execute("SELECT id, username FROM chats WHERE kind='group' AND (username=? COLLATE NOCASE OR id=?)",
                          (spec, int(spec) if spec.isdigit() else -1)).fetchone()
        if not chat:
            log("mass join: chat not found:", spec)
            return
        added = 0
        for u in db.execute("SELECT id FROM users WHERE banned=0 AND is_bot=0").fetchall():
            cur = db.execute("INSERT INTO members(chat_id, user_id, joined_at) SELECT ?,?,? "
                             "WHERE NOT EXISTS (SELECT 1 FROM members WHERE chat_id=? AND user_id=?)",
                             (chat["id"], u["id"], now(), chat["id"], u["id"]))
            added += cur.rowcount
        db.commit()
        log("mass join: added", added, "users to chat", chat["id"], "(@%s)" % (chat["username"] or "-"))

    def _rename_hook(self, db):
        """One-shot operator rename: DG_RENAME='olduser:newuser'.
        Frees a colliding public chat username, moves the avatar/wallpaper
        folders, kills the user's sessions, and applies the Telegram-style
        FAKE flag + English warning bio. Logs no secrets."""
        import re as _re
        spec = os.environ.get("DG_RENAME", "")
        if ":" not in spec:
            return
        old, new = spec.split(":", 1)
        old = old.strip().lower()
        new = new.strip()
        if not old or not _re.match(r"^[A-Za-z0-9_]{3,32}$", new):
            return
        row = db.execute("SELECT id, username FROM users WHERE username=? COLLATE NOCASE", (old,)).fetchone()
        if not row:
            log("rename: user not found:", old)
            return
        uid, stored = row[0], row[1]
        if db.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE AND id!=?", (new, uid)).fetchone():
            log("rename: new name taken by another user")
            return
        chat = db.execute("SELECT id FROM chats WHERE username=? COLLATE NOCASE AND kind!='private'", (new,)).fetchone()
        if chat:
            db.execute("UPDATE chats SET username=NULL WHERE id=?", (chat[0],))
            log("rename: freed chat username held by chat", chat[0])
        db.execute("UPDATE users SET username=?, fake=1, bio=? WHERE id=?",
                   (new, "\u26a0 FAKE \u2014 This account is fake.", uid))
        db.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
        db.commit()
        try:
            from common import AVATARS_DIR, _userwalls_dir
            for base in (AVATARS_DIR, _userwalls_dir()):
                src = base / avatar_folder_for_user(stored)
                dst = base / avatar_folder_for_user(new)
                if src.exists() and not dst.exists():
                    src.rename(dst)
        except Exception as e:
            log("rename: folder move skipped:", e)
        log("rename applied:", stored, "->", new)


    def _avatar_fix_hook(self, db):
        """One-shot avatar path repair after a rename: DG_FIX_AVATAR='olduser:newuser'.
        Points the stored avatar path at the new folder and moves the folder if needed."""
        spec = os.environ.get("DG_FIX_AVATAR", "")
        if ":" not in spec:
            return
        old, new = spec.split(":", 1)
        row = db.execute("SELECT id, avatar FROM users WHERE username=? COLLATE NOCASE", (new.strip(),)).fetchone()
        if not row:
            log("avatarfix: user not found:", new)
            return
        uid, av = row[0], row[1]
        log("avatarfix: stored avatar path:", av)
        try:
            from common import AVATARS_DIR, _userwalls_dir
            of = avatar_folder_for_user(old.strip())
            nf = avatar_folder_for_user(new.strip())
            if av and of in av:
                db.execute("UPDATE users SET avatar=? WHERE id=?", (av.replace(of, nf), uid))
                db.commit()
                log("avatarfix: path updated ->", av.replace(of, nf))
            for base in (AVATARS_DIR, _userwalls_dir()):
                src, dst = base / of, base / nf
                log("avatarfix: folder", of, "exists:", src.exists(), "| target", nf, "exists:", dst.exists())
                if src.exists() and not dst.exists():
                    src.rename(dst)
                    log("avatarfix: folder moved")
        except Exception as e:
            log("avatarfix failed:", e)

    def _ensure_admins(self, db):
        """DarkGram owners (TEEGRAM_ADMINS) get the gold tick automatically."""
        if not ADMIN_USERS:
            return
        marks = ",".join("?" * len(ADMIN_USERS))
        with db:
            db.execute(f"UPDATE users SET badge=2 WHERE username COLLATE NOCASE IN ({marks}) AND badge=0",
                       tuple(ADMIN_USERS))
            db.execute("UPDATE users SET badge=3 WHERE username=? COLLATE NOCASE AND badge!=3", (OWNER_USERNAME,))
            db.execute(f"UPDATE users SET premium=1 WHERE username COLLATE NOCASE IN ({marks}) AND premium=0",
                       tuple(ADMIN_USERS))
        log("DarkGram owners:", ", ".join(sorted(ADMIN_USERS)), "| owner:", OWNER_USERNAME)

    def _ensure_group_owners(self, db):
        """Designated group owners from TEEGRAM_GROUP_OWNERS ('ChatUser:UserName:Tag,...'):
        transfer the group's ownership to that user and give them an in-group-only label."""
        raw = os.environ.get("TEEGRAM_GROUP_OWNERS", "").strip()
        if not raw:
            return
        for entry in raw.split(","):
            parts = [p.strip() for p in entry.strip().split(":", 2)]
            if len(parts) < 2 or not parts[0] or not parts[1]:
                continue
            tag = parts[2] if len(parts) > 2 and parts[2] else "مالک گروه"
            chat = db.execute("SELECT id FROM chats WHERE username=? COLLATE NOCASE AND kind!='private'",
                              (parts[0],)).fetchone()
            user = db.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (parts[1],)).fetchone()
            if not chat or not user:
                log("group owner fixup skipped (not found):", entry)
                continue
            with db:
                db.execute("INSERT OR IGNORE INTO members(chat_id, user_id, role, joined_at) VALUES (?,?, 'owner', ?)",
                           (chat["id"], user["id"], now()))
                db.execute("UPDATE members SET role='admin' WHERE chat_id=? AND role='owner' AND user_id!=?",
                           (chat["id"], user["id"]))
                db.execute("UPDATE members SET role='owner', tag=? WHERE chat_id=? AND user_id=?",
                           (tag, chat["id"], user["id"]))
                db.execute("UPDATE chats SET owner_id=? WHERE id=?", (user["id"], chat["id"]))
            log("group owner set:", parts[0], "->", parts[1], "| tag:", tag)

    def _require_admin(self, conn):
        row = conn.db.execute("SELECT username FROM users WHERE id=?", (conn.uid,)).fetchone()
        if not row or row["username"].lower() not in ADMIN_USERS:
            raise Fail("دسترسی مدیریت نداری")
        return row

    def _require_labeler(self, conn):
        row = self._require_admin(conn)
        if row["username"].lower() not in LABELER_USERS:
            raise Fail("فقط @Reza و @msmdjdjdj می‌تونن برچسب کلاهبرداری/جعلی بزنن")
        return row

    def op_admin_stats(self, conn, req):
        self._require_admin(conn)
        db = conn.db
        one = lambda sql: db.execute(sql).fetchone()[0]
        return {"users": one("SELECT COUNT(*) FROM users WHERE is_bot=0"),
                "bots": one("SELECT COUNT(*) FROM users WHERE is_bot=1"),
                "chats": one("SELECT COUNT(*) FROM chats"),
                "messages": one("SELECT COUNT(*) FROM messages"),
                "online": len([u for u, cs in self.sessions.items() if cs]),
                "premium": one("SELECT COUNT(*) FROM users WHERE premium=1"),
                "stars_total": one("SELECT IFNULL(SUM(stars),0) FROM users"),
                "gifts": one("SELECT COUNT(*) FROM gifts_owned"),
                "nfts": one("SELECT COUNT(*) FROM gifts_owned WHERE serial IS NOT NULL"),
                "new24": one(f"SELECT COUNT(*) FROM users WHERE created_at>={now() - 86400}"),
                "groups": one("SELECT COUNT(*) FROM chats WHERE kind='group' AND chan=0"),
                "channels": one("SELECT COUNT(*) FROM chats WHERE chan=1")}

    def op_admin_activity(self, conn, req):
        self._require_admin(conn)
        db = conn.db
        new_users = [{"username": r["username"], "display_name": self._badged(r["id"], r["display_name"]),
                      "created_at": r["created_at"], "is_bot": bool(r["is_bot"])}
                     for r in db.execute("SELECT id, username, display_name, created_at, is_bot FROM users "
                                         "ORDER BY id DESC LIMIT 6")]
        gifts = []
        for r in db.execute("SELECT g.gift_id, g.serial, g.created_at, f.username AS fu, t.username AS tu "
                            "FROM gifts_owned g JOIN users f ON f.id=g.from_id JOIN users t ON t.id=g.to_id "
                            "ORDER BY g.id DESC LIMIT 8"):
            g = NFT_MAP.get(r["gift_id"]) or GIFT_MAP.get(r["gift_id"]) or {}
            gifts.append({"art": g.get("art", "🎁"), "name": g.get("name", r["gift_id"]),
                          "serial": r["serial"], "from": r["fu"], "to": r["tu"], "at": r["created_at"]})
        return {"new_users": new_users, "gifts": gifts}

    def op_admin_broadcast(self, conn, req):
        """Post an announcement into the official channel (every user is a member)."""
        self._require_admin(conn)
        text = CTRL_RE.sub("", str(req.get("text") or "")).strip()
        if not text:
            raise Fail("متن اطلاعیه خالیه")
        if len(text) > 2000:
            raise Fail("متن اطلاعیه خیلی طولانیه (حداکثر ۲۰۰۰ کاراکتر)")
        ch = conn.db.execute("SELECT id FROM chats WHERE channel=1 LIMIT 1").fetchone()
        if not ch:
            raise Fail("کانال اطلاع‌رسانی پیدا نشد")
        msg = self._store_message(conn.db, conn.uid, ch["id"], text, None)
        self._announce(conn.db, ch["id"], msg, conn.uid, exclude=conn)
        return {"ok": True}

    def op_admin_users(self, conn, req):
        self._require_admin(conn)
        q = str(req.get("q") or "").strip()
        if q:
            rows = conn.db.execute("SELECT * FROM users WHERE username LIKE ? OR display_name LIKE ? "
                                   "ORDER BY id DESC LIMIT 100", (f"%{q}%", f"%{q}%")).fetchall()
        else:
            rows = conn.db.execute("SELECT * FROM users ORDER BY id DESC LIMIT 100").fetchall()
        return {"users": [{"id": r["id"], "username": r["username"],
                           "display_name": self._badged(r["id"], r["display_name"]),
                           "badge": r["badge"], "premium": r["id"] in self._premium, "loyal": r["id"] in self._loyals, "bounty": r["id"] in self._bountys, "fake": r["id"] in self._fakes, "scam": r["id"] in self._scams, "stars": r["stars"], "banned": bool(r["banned"]), "is_bot": bool(r["is_bot"]),
                           "online": self.is_online(r["id"]), "created_at": r["created_at"],
                           "is_admin": r["username"].lower() in ADMIN_USERS,
                           "restricted_until": r["restricted_until"] or 0,
                           "bot_official": r["id"] in self._official_bot_ids(conn.db)} for r in rows]}

    def op_admin_set_badge(self, conn, req):
        self._require_admin(conn)
        try:
            uid, badge = int(req.get("user_id")), int(req.get("badge"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        if badge not in (0, 1, 2, 3):
            raise Fail("نشان نامعتبر")
        with conn.db:
            conn.db.execute("UPDATE users SET badge=? WHERE id=?", (badge, uid))
        if badge:
            self._badges[uid] = badge
        else:
            self._badges.pop(uid, None)
        return {"ok": True}

    def op_premium_activate(self, conn, req):
        """Free Premium activation from Settings: star next to the name, everywhere.
        First activation also grants a 150-star welcome bonus for the gift shop."""
        row = conn.db.execute("SELECT premium, stars FROM users WHERE id=?", (conn.uid,)).fetchone()
        bonus = 0
        with conn.db:
            conn.db.execute("UPDATE users SET premium=1 WHERE id=?", (conn.uid,))
            if not row["premium"]:
                bonus = 150
                conn.db.execute("UPDATE users SET stars=stars+150 WHERE id=?", (conn.uid,))
        self._premium.add(conn.uid)
        return {"ok": True, "premium": True, "stars": row["stars"] + bonus, "bonus": bonus}

    # ------------------------------------------------ Telegram Stars & gifts (Premium only)
    def _require_premium(self, conn):
        if conn.uid not in self._premium:
            raise Fail("این بخش فقط برای مشترکین پریمیومه ⭐ اول از تنظیمات، پریمیوم رو فعال کن")

    UNLIMITED_STARS = 999999999

    def _is_owner(self, db, uid):
        r = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        return bool(r) and r["username"].lower() == OWNER_USERNAME

    def op_stars_me(self, conn, req):
        self._require_premium(conn)
        row = conn.db.execute("SELECT stars, stars_at FROM users WHERE id=?", (conn.uid,)).fetchone()
        gifts = [{"gift": r["gift_id"], "from_id": r["from_id"], "from_name": r["from_name"], "at": r["created_at"]}
                 for r in conn.db.execute(
                     "SELECT g.gift_id, g.from_id, g.created_at, u.display_name AS from_name FROM gifts_owned g "
                     "JOIN users u ON u.id=g.from_id WHERE g.to_id=? ORDER BY g.id DESC LIMIT 100", (conn.uid,))]
        minted = {r["gift_id"]: r["n"] for r in conn.db.execute(
            "SELECT gift_id, COUNT(*) AS n FROM gifts_owned WHERE serial IS NOT NULL GROUP BY gift_id")}
        nft_catalog = [dict(g, minted=minted.get(g["id"], 0),
                            price_stars=int(round(g["usd"] * STAR_PER_USD))) for g in NFT_GIFTS]
        own = self._is_owner(conn.db, conn.uid)
        return {"stars": self.UNLIMITED_STARS if own else row["stars"], "unlimited": own, "can_claim": now() - (row["stars_at"] or 0) >= 86400,
                "gifts": gifts, "catalog": GIFTS, "nft_catalog": nft_catalog}

    def op_stars_claim(self, conn, req):
        self._require_premium(conn)
        row = conn.db.execute("SELECT stars_at FROM users WHERE id=?", (conn.uid,)).fetchone()
        if now() - (row["stars_at"] or 0) < 86400:
            raise Fail("ستاره امروز رو گرفتی؛ فردا دوباره بیا ⭐")
        with conn.db:
            conn.db.execute("UPDATE users SET stars=stars+25, stars_at=? WHERE id=?", (now(), conn.uid))
        bal = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()["stars"]
        return {"ok": True, "stars": bal}

    def op_gift_send(self, conn, req):
        self._require_premium(conn)
        g = GIFT_MAP.get(str(req.get("gift") or ""))
        if not g:
            raise Fail("گیفت نامعتبر")
        username = str(req.get("username", "")).strip().lstrip("@")
        target = conn.db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE AND banned=0", (username,)).fetchone() \
            if USERNAME_RE.match(username) else None
        if not target:
            raise Fail("کاربری با این نام پیدا نشد")
        if target["id"] == conn.uid:
            raise Fail("نمی‌تونی به خودت گیفت بفرستی")
        bal = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()["stars"]
        own = self._is_owner(conn.db, conn.uid)
        if bal < g["price"] and not own:
            raise Fail(f"ستاره کافی نداری؛ این گیفت {g['price']} ستاره می‌خواد و تو {bal} ستاره داری")
        a, b = sorted((conn.uid, target["id"]))
        key = f"{a}:{b}"
        row = conn.db.execute("SELECT id FROM chats WHERE pair_key=?", (key,)).fetchone()
        if row:
            chat_id = row["id"]
        else:
            with conn.db:
                cur = conn.db.execute("INSERT INTO chats(kind, pair_key, created_at) VALUES ('private',?,?)",
                                      (key, now()))
                chat_id = cur.lastrowid
                for u in {a, b}:
                    conn.db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)",
                                    (chat_id, u, now()))
        with conn.db:
            if not own:
                conn.db.execute("UPDATE users SET stars=stars-? WHERE id=?", (g["price"], conn.uid))
            conn.db.execute("INSERT INTO gifts_owned(gift_id, from_id, to_id, created_at) VALUES (?,?,?,?)",
                            (g["id"], conn.uid, target["id"], now()))
        msg = self._store_message(conn.db, conn.uid, chat_id, f"🎁 {g['art']} {g['name']}", None,
                                  meta={"gift": {"id": g["id"], "art": g["art"], "name": g["name"],
                                                 "price": g["price"], "to": target["id"]}})
        self._announce(conn.db, chat_id, msg, conn.uid, exclude=conn)
        newbal = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()["stars"]
        return {"ok": True, "stars": self.UNLIMITED_STARS if own else newbal, "chat_id": chat_id, "message": msg}

    def op_nft_buy(self, conn, req):
        """Buy a limited NFT gift (priced in USD, paid in stars) for another user.
        Each piece gets a unique serial number; sold out when the supply runs out."""
        self._require_premium(conn)
        g = NFT_MAP.get(str(req.get("gift") or ""))
        if not g:
            raise Fail("گیفت NFT نامعتبر")
        username = str(req.get("username", "")).strip().lstrip("@")
        target = conn.db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE AND banned=0", (username,)).fetchone() \
            if USERNAME_RE.match(username) else None
        if not target:
            raise Fail("کاربری با این نام پیدا نشد")
        if target["id"] == conn.uid:
            raise Fail("نمی‌تونی به خودت گیفت بفرستی")
        price = int(round(g["usd"] * STAR_PER_USD))
        bal = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()["stars"]
        own = self._is_owner(conn.db, conn.uid)
        if bal < price and not own:
            raise Fail(f"ستاره کافی نداری؛ این NFT ‏{g['usd']}$ یعنی {price} ستاره می‌خواد و تو {bal} ستاره داری")
        minted = conn.db.execute("SELECT COUNT(*) FROM gifts_owned WHERE gift_id=? AND serial IS NOT NULL",
                                 (g["id"],)).fetchone()[0]
        if minted >= g["supply"]:
            raise Fail("این NFT کاملاً فروخته شده و دیگه موجود نیست 🏁")
        serial = minted + 1
        a, b = sorted((conn.uid, target["id"]))
        key = f"{a}:{b}"
        row = conn.db.execute("SELECT id FROM chats WHERE pair_key=?", (key,)).fetchone()
        if row:
            chat_id = row["id"]
        else:
            with conn.db:
                cur = conn.db.execute("INSERT INTO chats(kind, pair_key, created_at) VALUES ('private',?,?)",
                                      (key, now()))
                chat_id = cur.lastrowid
                for u in {a, b}:
                    conn.db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)",
                                    (chat_id, u, now()))
        with conn.db:
            if not own:
                conn.db.execute("UPDATE users SET stars=stars-? WHERE id=?", (price, conn.uid))
            conn.db.execute("INSERT INTO gifts_owned(gift_id, from_id, to_id, created_at, serial) VALUES (?,?,?,?,?)",
                            (g["id"], conn.uid, target["id"], now(), serial))
        msg = self._store_message(conn.db, conn.uid, chat_id, f"🖼 {g['art']} {g['name']} #{serial}", None,
                                  meta={"gift": {"id": g["id"], "art": g["art"], "name": g["name"],
                                                 "price": price, "usd": g["usd"], "nft": True,
                                                 "serial": serial, "supply": g["supply"], "to": target["id"]}})
        self._announce(conn.db, chat_id, msg, conn.uid, exclude=conn)
        newbal = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()["stars"]
        return {"ok": True, "stars": self.UNLIMITED_STARS if own else newbal, "chat_id": chat_id, "message": msg, "serial": serial}

    def op_gifts_of(self, conn, req):
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        rows = conn.db.execute("SELECT gift_id, COUNT(*) AS n FROM gifts_owned WHERE to_id=? AND serial IS NULL GROUP BY gift_id",
                               (uid,)).fetchall()
        nfts = conn.db.execute("SELECT gift_id, serial, backdrop FROM gifts_owned WHERE to_id=? AND serial IS NOT NULL "
                               "ORDER BY id DESC", (uid,)).fetchall()
        return {"gifts": [{"gift": r["gift_id"], "count": r["n"]} for r in rows],
                "nfts": [{"gift": r["gift_id"], "serial": r["serial"], "backdrop": r["backdrop"]} for r in nfts]}

    def op_gift_info(self, conn, req):
        """Resolve an NFT gift link (#gift=<id>-<serial>) to its current owner."""
        gid = str(req.get("gift") or "")
        try:
            serial = int(req.get("serial"))
        except (TypeError, ValueError):
            raise Fail("لینک گیفت نامعتبر")
        if gid not in NFT_MAP:
            raise Fail("گیفت پیدا نشد")
        row = conn.db.execute("SELECT to_id, backdrop FROM gifts_owned WHERE gift_id=? AND serial=?",
                              (gid, serial)).fetchone()
        if not row:
            raise Fail("گیفت پیدا نشد")
        u = conn.db.execute("SELECT username FROM users WHERE id=?", (row["to_id"],)).fetchone()
        return {"gift": gid, "serial": serial, "owner": u["username"] if u else None, "backdrop": row["backdrop"]}

    def op_my_stickers(self, conn, req):
        rows = conn.db.execute("SELECT id FROM user_stickers WHERE user_id=? ORDER BY id DESC", (conn.uid,)).fetchall()
        return {"stickers": [{"id": r["id"]} for r in rows]}

    def op_sticker_delete(self, conn, req):
        try:
            sid = int(req.get("id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        row = conn.db.execute("SELECT file FROM user_stickers WHERE id=? AND user_id=?", (sid, conn.uid)).fetchone()
        if not row:
            raise Fail("استیکر پیدا نشد")
        conn.db.execute("DELETE FROM user_stickers WHERE id=?", (sid,))
        conn.db.commit()
        p = resolve_upload(row["file"])
        if p is not None:
            try:
                p.unlink()
            except OSError:
                pass
        return {"ok": True}

    def op_set_emoji_status(self, conn, req):
        """Telegram Premium emoji status: a small emoji next to your name everywhere (premium only)."""
        self._require_premium(conn)
        e = str(req.get("emoji") or "")
        if e and e not in STATUS_EMOJIS:
            raise Fail("این ایموجی مجاز نیست")
        conn.db.execute("UPDATE users SET emoji_status=? WHERE id=?", (e, conn.uid))
        conn.db.commit()
        if e:
            self._estatus[conn.uid] = e
        else:
            self._estatus.pop(conn.uid, None)
        return {"ok": True, "emoji_status": e}

    def op_gift_upgrade(self, conn, req):
        """Telegram-style gift upgrade (free): the Eternal Dragon gets a random new backdrop."""
        import random
        gid = str(req.get("gift") or "")
        try:
            serial = int(req.get("serial"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        if gid != "nft_eternal":
            raise Fail("این گیفت قابل ارتقا نیست")
        row = conn.db.execute("SELECT id FROM gifts_owned WHERE gift_id=? AND serial=? AND to_id=?",
                              (gid, serial, conn.uid)).fetchone()
        if not row:
            raise Fail("این گیفت مال شما نیست")
        bd = random.choices(NFT_BACKDROPS, weights=[b["w"] for b in NFT_BACKDROPS])[0]["id"]
        conn.db.execute("UPDATE gifts_owned SET backdrop=? WHERE id=?", (bd, row["id"]))
        conn.db.commit()
        return {"ok": True, "backdrop": bd}

    # ---- gift collections (profile folders, Telegram-style) ----
    def _my_col(self, conn, req):
        try:
            cid = int(req.get("col_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        row = conn.db.execute("SELECT * FROM gift_cols WHERE id=? AND user_id=?", (cid, conn.uid)).fetchone()
        if not row:
            raise Fail("پوشه پیدا نشد")
        return row

    def op_gift_cols(self, conn, req):
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        cols = []
        for c in conn.db.execute("SELECT * FROM gift_cols WHERE user_id=? ORDER BY ord, id", (uid,)).fetchall():
            items = [r["gkey"] for r in conn.db.execute(
                "SELECT gkey FROM gift_col_items WHERE col_id=? ORDER BY ord, rowid", (c["id"],)).fetchall()]
            cols.append({"id": c["id"], "name": c["name"], "items": items})
        return {"cols": cols}

    def op_gift_col_create(self, conn, req):
        name = str(req.get("name") or "").strip()[:32]
        if not name:
            raise Fail("اسم پوشه رو بنویس")
        n = conn.db.execute("SELECT COUNT(*) AS n FROM gift_cols WHERE user_id=?", (conn.uid,)).fetchone()["n"]
        if n >= 20:
            raise Fail("حداکثر ۲۰ پوشه می‌تونی بسازی")
        with conn.db:
            cur = conn.db.execute("INSERT INTO gift_cols(user_id, name, ord, created_at) VALUES(?,?,?,?)",
                                  (conn.uid, name, n, int(time.time())))
        return {"ok": True, "col": {"id": cur.lastrowid, "name": name, "items": []}}

    def op_gift_col_rename(self, conn, req):
        col = self._my_col(conn, req)
        name = str(req.get("name") or "").strip()[:32]
        if not name:
            raise Fail("اسم پوشه رو بنویس")
        with conn.db:
            conn.db.execute("UPDATE gift_cols SET name=? WHERE id=?", (name, col["id"]))
        return {"ok": True}

    def op_gift_col_delete(self, conn, req):
        col = self._my_col(conn, req)
        with conn.db:
            conn.db.execute("DELETE FROM gift_col_items WHERE col_id=?", (col["id"],))
            conn.db.execute("DELETE FROM gift_cols WHERE id=?", (col["id"],))
        return {"ok": True}

    def op_gift_col_move(self, conn, req):
        col = self._my_col(conn, req)
        d = -1 if int(req.get("dir") or 0) < 0 else 1
        rows = conn.db.execute("SELECT id, ord FROM gift_cols WHERE user_id=? ORDER BY ord, id", (conn.uid,)).fetchall()
        i = next((k for k, r in enumerate(rows) if r["id"] == col["id"]), -1)
        j = i + d
        if i < 0 or j < 0 or j >= len(rows):
            return {"ok": True}
        with conn.db:
            conn.db.execute("UPDATE gift_cols SET ord=? WHERE id=?", (rows[j]["ord"], col["id"]))
            conn.db.execute("UPDATE gift_cols SET ord=? WHERE id=?", (col["ord"], rows[j]["id"]))
        return {"ok": True}

    def _check_gkey(self, conn, gkey):
        parts = str(gkey or "").split(":")
        r = None
        if len(parts) == 2 and parts[0] == "gift":
            r = conn.db.execute("SELECT 1 FROM gifts_owned WHERE to_id=? AND gift_id=? AND serial IS NULL LIMIT 1",
                                (conn.uid, parts[1])).fetchone()
        elif len(parts) == 3 and parts[0] == "nft":
            try:
                ser = int(parts[2])
            except ValueError:
                ser = None
            if ser is not None:
                r = conn.db.execute("SELECT 1 FROM gifts_owned WHERE to_id=? AND gift_id=? AND serial=? LIMIT 1",
                                    (conn.uid, parts[1], ser)).fetchone()
        if not r:
            raise Fail("این گیفت مال تو نیست")

    def op_gift_col_add(self, conn, req):
        col = self._my_col(conn, req)
        gkey = str(req.get("gkey") or "")
        self._check_gkey(conn, gkey)
        n = conn.db.execute("SELECT COUNT(*) AS n FROM gift_col_items WHERE col_id=?", (col["id"],)).fetchone()["n"]
        with conn.db:
            conn.db.execute("INSERT OR IGNORE INTO gift_col_items(col_id, gkey, ord) VALUES(?,?,?)",
                            (col["id"], gkey, n))
        return {"ok": True}

    def op_gift_col_remove(self, conn, req):
        col = self._my_col(conn, req)
        with conn.db:
            conn.db.execute("DELETE FROM gift_col_items WHERE col_id=? AND gkey=?",
                            (col["id"], str(req.get("gkey") or "")))
        return {"ok": True}

    def op_gift_col_item_move(self, conn, req):
        col = self._my_col(conn, req)
        gkey = str(req.get("gkey") or "")
        d = -1 if int(req.get("dir") or 0) < 0 else 1
        rows = conn.db.execute("SELECT gkey, ord FROM gift_col_items WHERE col_id=? ORDER BY ord, rowid",
                               (col["id"],)).fetchall()
        i = next((k for k, r in enumerate(rows) if r["gkey"] == gkey), -1)
        j = i + d
        if i < 0 or j < 0 or j >= len(rows):
            return {"ok": True}
        with conn.db:
            conn.db.execute("UPDATE gift_col_items SET ord=? WHERE col_id=? AND gkey=?", (rows[j]["ord"], col["id"], gkey))
            conn.db.execute("UPDATE gift_col_items SET ord=? WHERE col_id=? AND gkey=?", (rows[i]["ord"], col["id"], rows[j]["gkey"]))
        return {"ok": True}

    def op_admin_set_stars(self, conn, req):
        self._require_admin(conn)
        try:
            uid, amount = int(req.get("user_id")), int(req.get("stars"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        amount = max(0, min(amount, 1000000))
        with conn.db:
            conn.db.execute("UPDATE users SET stars=? WHERE id=?", (amount, uid))
        return {"ok": True, "stars": amount}

    def op_admin_set_premium(self, conn, req):
        self._require_admin(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        on = 1 if req.get("premium") else 0
        with conn.db:
            conn.db.execute("UPDATE users SET premium=? WHERE id=?", (on, uid))
        if on:
            self._premium.add(uid)
        else:
            self._premium.discard(uid)
        return {"ok": True}

    def _official_bot_ids(self, db):
        return {r["user_id"] for r in db.execute("SELECT user_id FROM bots WHERE official=1").fetchall()}

    def op_admin_delete_bot(self, conn, req):
        """Panel deletion of a bot = full server purge (same as BotFather /deletebot)."""
        self._require_admin(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        row = conn.db.execute("SELECT is_bot FROM users WHERE id=?", (uid,)).fetchone()
        if not row or not row["is_bot"]:
            raise Fail("این حساب ربات نیست")
        if uid in self._official_bot_ids(conn.db):
            raise Fail("ربات‌های رسمی دارک گرام قابل حذف نیستن")
        self._bot_delete(conn.db, uid)
        return {"ok": True}

    def _is_spam_chat(self, db, chat_id):
        sid = getattr(self, "spam_bot_id", None)
        if not sid:
            return False
        return bool(db.execute("SELECT 1 FROM chats c JOIN members m ON m.chat_id=c.id "
                               "WHERE c.id=? AND c.kind='private' AND m.user_id=?",
                               (chat_id, sid)).fetchone())

    def _check_restricted(self, db, uid):
        row = db.execute("SELECT restricted_until FROM users WHERE id=?", (uid,)).fetchone()
        if row and (row["restricted_until"] or 0) > now():
            rem = max(1, -(-(row["restricted_until"] - now()) // 60))
            raise Fail(f"⏱ حساب شما محدود شده؛ {rem} دقیقهٔ دیگه می‌تونید پیام بفرستید. برای بررسی به @Spam پیام بدید.")

    REPORT_REASONS = {"spam": "اسپم", "violence": "خشونت", "porn": "محتوای غیراخلاقی",
                      "child_abuse": "کودک‌آزاری", "scam": "کلاهبرداری / جعلی",
                      "personal": "اطلاعات شخصی", "copyright": "نقض کپی‌رایت", "other": "سایر موارد"}

    def _ensure_private_chat(self, db, a, b):
        x, y = sorted((a, b))
        key = f"{x}:{y}"
        row = db.execute("SELECT id FROM chats WHERE pair_key=?", (key,)).fetchone()
        if row:
            return row["id"]
        with db:
            cur = db.execute("INSERT INTO chats(kind, pair_key, created_at) VALUES ('private',?,?)", (key, now()))
            cid = cur.lastrowid
            for u in {x, y}:
                db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)", (cid, u, now()))
        return cid

    def op_report(self, conn, req):
        """Telegram-style report of a message / user / chat. Goes to the reports table and is
        pushed to every admin & owner as a DM from @Spam."""
        reason = str(req.get("reason") or "")
        if reason not in self.REPORT_REASONS:
            raise Fail("دلیل گزارش رو انتخاب کن")
        if not self._room_hits(("report", conn.uid), 5, 3600):
            raise Fail("تعداد گزارش‌هات زیاد شده؛ یه ساعت دیگه دوباره تلاش کن")
        comment = clean_line(req.get("comment"), 300, "توضیح") or ""
        db = conn.db
        ttype = snapshot = None
        mid = chat_id = target_user = None
        if req.get("message_id"):
            try:
                mid = int(req.get("message_id"))
            except (TypeError, ValueError):
                raise Fail("درخواست نامعتبر")
            row = db.execute("SELECT * FROM messages WHERE id=? AND deleted=0", (mid,)).fetchone()
            if not row:
                raise Fail("پیام پیدا نشد")
            self._require_member(db, row["chat_id"], conn.uid)
            if row["sender_id"] == conn.uid:
                raise Fail("پیام خودت رو نمی‌تونی گزارش کنی")
            ttype, chat_id, target_user = "message", row["chat_id"], row["sender_id"]
            snapshot = (row["body"] or "")[:200] or ("📎 " + (row["file_name"] or "فایل"))
        elif req.get("user_id"):
            try:
                target_user = int(req.get("user_id"))
            except (TypeError, ValueError):
                raise Fail("درخواست نامعتبر")
            if target_user == conn.uid:
                raise Fail("خودت رو نمی‌تونی گزارش کنی")
            if not db.execute("SELECT 1 FROM users WHERE id=?", (target_user,)).fetchone():
                raise Fail("کاربر پیدا نشد")
            ttype = "user"
        elif req.get("chat_id"):
            try:
                chat_id = int(req.get("chat_id"))
            except (TypeError, ValueError):
                raise Fail("درخواست نامعتبر")
            self._require_member(db, chat_id, conn.uid)
            crow = db.execute("SELECT owner_id, title FROM chats WHERE id=?", (chat_id,)).fetchone()
            if not crow:
                raise Fail("چت پیدا نشد")
            ttype, target_user, snapshot = "chat", crow["owner_id"], crow["title"] or ""
        else:
            raise Fail("درخواست نامعتبر")
        with db:
            cur = db.execute("INSERT INTO reports(reporter_id, target_type, message_id, chat_id, target_user_id,"
                             " reason, comment, snapshot, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                             (conn.uid, ttype, mid, chat_id, target_user, reason, comment, snapshot, now()))
            rid = cur.lastrowid
        try:
            self._notify_report(db, rid)
        except Exception as e:
            log("report notify failed:", repr(e))
        return {"ok": True}

    def _notify_report(self, db, rid):
        sid = getattr(self, "spam_bot_id", None)
        if not sid:
            return
        r = db.execute("SELECT * FROM reports WHERE id=?", (rid,)).fetchone()
        if not r:
            return
        def uname(uid):
            if not uid:
                return "—"
            u = db.execute("SELECT username, display_name FROM users WHERE id=?", (uid,)).fetchone()
            return f"{u['display_name']} (@{u['username']})" if u else "—"
        kind = {"message": "پیام", "user": "کاربر", "chat": "چت"}[r["target_type"]]
        lines = [f"🚨 گزارش جدید #{rid}",
                 f"👤 گزارش‌دهنده: {uname(r['reporter_id'])}",
                 f"🎯 مورد گزارش: {kind} — {uname(r['target_user_id'])}",
                 f"🏷 دلیل: {self.REPORT_REASONS.get(r['reason'], r['reason'])}"]
        if r["target_type"] == "message" and r["snapshot"]:
            lines.append(f"📝 متن پیام: «{r['snapshot']}»")
        if r["target_type"] == "chat" and r["snapshot"]:
            lines.append(f"💬 چت: «{r['snapshot']}»")
        if r["comment"]:
            lines.append(f"💬 توضیح: {r['comment']}")
        lines.append("از پنل مدیریت ← بخش «🚨 گزارش‌ها» می‌تونید رسیدگی کنید.")
        text = "\n".join(lines)
        admins = [u["id"] for u in db.execute("SELECT id, username FROM users WHERE banned=0").fetchall()
                  if u["username"].lower() in ADMIN_USERS]
        for aid in admins:
            try:
                cid = self._ensure_private_chat(db, sid, aid)
                self._bot_send(db, sid, cid, text)
            except Exception as e:
                log("report DM failed:", repr(e))

    def op_admin_reports(self, conn, req):
        self._require_admin(conn)
        rows = conn.db.execute("SELECT * FROM reports ORDER BY handled ASC, id DESC LIMIT 50").fetchall()
        def nm(uid):
            if not uid:
                return ""
            u = conn.db.execute("SELECT display_name FROM users WHERE id=?", (uid,)).fetchone()
            return self._badged(uid, u["display_name"]) if u else ""
        return {"reports": [{"id": r["id"], "target_type": r["target_type"], "reason": r["reason"],
                             "reason_fa": self.REPORT_REASONS.get(r["reason"], r["reason"]),
                             "comment": r["comment"] or "", "snapshot": r["snapshot"] or "",
                             "handled": bool(r["handled"]), "created_at": r["created_at"],
                             "reporter_name": nm(r["reporter_id"]), "target_name": nm(r["target_user_id"])}
                            for r in rows]}

    def op_admin_report_handle(self, conn, req):
        self._require_admin(conn)
        try:
            rid = int(req.get("id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        with conn.db:
            conn.db.execute("UPDATE reports SET handled=1 WHERE id=?", (rid,))
        return {"ok": True}

    def op_admin_restrict(self, conn, req):
        """Timed restriction from the panel: minutes<=0 lifts it. Admins/owners are immune."""
        self._require_admin(conn)
        try:
            uid = int(req.get("user_id"))
            minutes = int(req.get("minutes"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        row = conn.db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        if not row:
            raise Fail("کاربر پیدا نشد")
        if row["username"].lower() in ADMIN_USERS:
            raise Fail("ادمین‌ها و مالکان رو نمی‌شه محدود کرد")
        until = 0 if minutes <= 0 else now() + min(minutes, 43200) * 60
        with conn.db:
            conn.db.execute("UPDATE users SET restricted_until=? WHERE id=?", (until, uid))
        return {"ok": True, "restricted_until": until}

    def op_admin_set_bounty(self, conn, req):
        self._require_admin(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        on = 1 if req.get("bounty") else 0
        with conn.db:
            conn.db.execute("UPDATE users SET bounty=? WHERE id=?", (on, uid))
        if on:
            self._bountys.add(uid)
        else:
            self._bountys.discard(uid)
        return {"ok": True}

    def op_admin_set_loyal(self, conn, req):
        self._require_admin(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        on = 1 if req.get("loyal") else 0
        with conn.db:
            conn.db.execute("UPDATE users SET loyal=? WHERE id=?", (on, uid))
        if on:
            self._loyals.add(uid)
        else:
            self._loyals.discard(uid)
        return {"ok": True}

    def op_admin_set_scam(self, conn, req):
        self._require_labeler(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        on = 1 if req.get("scam") else 0
        with conn.db:
            conn.db.execute("UPDATE users SET scam=? WHERE id=?", (on, uid))
        if on:
            self._scams.add(uid)
        else:
            self._scams.discard(uid)
        return {"ok": True}

    def op_admin_set_fake(self, conn, req):
        self._require_labeler(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        on = 1 if req.get("fake") else 0
        with conn.db:
            conn.db.execute("UPDATE users SET fake=? WHERE id=?", (on, uid))
        if on:
            self._fakes.add(uid)
        else:
            self._fakes.discard(uid)
        return {"ok": True}

    def op_admin_set_ban(self, conn, req):
        self._require_admin(conn)
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        banned = 1 if req.get("banned") else 0
        row = conn.db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        if not row:
            raise Fail("کاربر پیدا نشد")
        if row["username"].lower() in ADMIN_USERS:
            raise Fail("مالک رو نمی‌شه مسدود کرد")
        with conn.db:
            conn.db.execute("UPDATE users SET banned=? WHERE id=?", (banned, uid))
            if banned:
                conn.db.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
        return {"ok": True}

    def _can_post(self, db, chat_id, uid):
        c = db.execute("SELECT channel, chan FROM chats WHERE id=?", (chat_id,)).fetchone()
        if c and c["chan"]:                                   # user-made channel: owner and admins post
            m = db.execute("SELECT role FROM members WHERE chat_id=? AND user_id=?", (chat_id, uid)).fetchone()
            return bool(m and m["role"] in ("owner", "admin"))
        if not c or not c["channel"]:
            return True
        u = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        return bool(u and u["username"].lower() in ADMIN_USERS)   # any DarkGram owner may post

    MAX_CONNS_TOTAL = 2000      # raw TCP connections (open sockets that never log in cost a thread each -> flood guard)
    MAX_CONNS_PER_IP = 40

    def _accept_loop(self):
        while not self._stop.is_set():
            try:
                sock, addr = self.listener.accept()
            except OSError:
                break
            ip = addr[0] if addr else ""
            with self.conns_lock:
                over = self.conns_total >= self.MAX_CONNS_TOTAL or self.conns_by_ip[ip] >= self.MAX_CONNS_PER_IP
                if not over:
                    self.conns_total += 1
                    self.conns_by_ip[ip] += 1
            if over:         # too many open connections already (this IP, or overall): refuse before spending a thread/DB handle
                try:
                    sock.close()
                except Exception:
                    pass
                continue
            threading.Thread(target=self._client_thread, args=(sock, addr), daemon=True).start()

    def _conn_done(self, ip):
        with self.conns_lock:
            self.conns_total = max(0, self.conns_total - 1)
            self.conns_by_ip[ip] = max(0, self.conns_by_ip[ip] - 1)
            if self.conns_by_ip[ip] == 0:
                del self.conns_by_ip[ip]

    # ------------------------------------------------------ per-connection
    def _client_thread(self, sock, addr):
        ip = addr[0] if addr else ""
        try:
            sock.settimeout(120)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            if self.ssl_ctx:
                sock = self.ssl_ctx.wrap_socket(sock, server_side=True)
        except Exception:
            try:
                sock.close()
            except Exception:
                pass
            self._conn_done(ip)
            return
        conn = Conn(self, sock, addr)
        conn.db = connect_db(self.db_path)
        try:
            while conn.alive:
                req = recv_frame(sock)
                self._dispatch(conn, req)
        except (ConnectionError, OSError, ValueError, ssl.SSLError):
            pass
        except Exception as e:  # never let one client kill the server
            log("client error:", repr(e))
        finally:
            self._drop(conn)
            self._conn_done(ip)

    def _drop(self, conn):
        conn.alive = False
        uid = conn.uid
        try:
            self._room_drop(conn)
        except Exception:
            pass
        if uid is not None:
            with self.calls_lock:
                cid = self.user_call.get(uid)
                call = self.calls.get(cid) if cid else None
            if call and (call["caller_conn"] is conn or call["callee_conn"] is conn):
                try:
                    if call["state"] == "active":
                        self._call_grace(call, uid)          # mobile networks blink: wait for the user to come back
                    else:
                        self._finish_call(cid, "disconnected", conn.db)
                except Exception:
                    pass
        if uid is not None:
            with self.sessions_lock:
                lst = self.sessions.get(uid, [])
                if conn in lst:
                    lst.remove(conn)
                offline = not lst
                if offline:
                    self.sessions.pop(uid, None)
            if offline:
                try:
                    with conn.db:
                        conn.db.execute("UPDATE users SET last_seen=? WHERE id=?", (now(), uid))
                    self._broadcast_presence(conn.db, uid, False)
                except Exception:
                    pass
        try:
            conn.db.close()
        except Exception:
            pass
        conn.close()

    def _dispatch(self, conn, req):
        if not isinstance(req, dict):
            return
        rid, op = req.get("id"), str(req.get("op", ""))
        handler = getattr(self, "op_" + op, None)
        if handler is None or op.startswith("_"):
            return conn.send({"id": rid, "ok": False, "error": "درخواست نامعتبر"})
        public = {"register", "login", "resume", "reset_question", "reset_password", "ping"}
        try:
            if op in ("call_audio", "call_video", "room_audio", "room_video"):   # hot path: many small frames/second, skip the per-request DB check
                if conn.uid is None:
                    return
                try:
                    getattr(self, "op_" + op)(conn, req)
                except Fail:
                    pass
                return
            if op not in public:
                if conn.uid is None:
                    raise Fail("اول وارد شو")
                if not self._room_hits(("op", conn.uid), 200, 10):                      # a client gone wild must not hog the server
                    raise Fail("درخواست‌های خیلی زیاد؛ چند ثانیه صبر کن")
                if op in ("search_all", "search_messages", "search_users", "invite_info", "join", "shared") \
                        and not self._room_hits(("heavy", conn.uid), 40, 60):
                    raise Fail("خیلی سریع جستجو می‌کنی، یه لحظه صبر کن")
                row = conn.db.execute("SELECT banned, username, badge FROM users WHERE id=?", (conn.uid,)).fetchone()
                if row is None or row["banned"]:
                    conn.send({"event": "banned"})
                    raise Fail("این حساب مسدود شده")
                if row["badge"] == 0 and (row["username"].lower() in ADMIN_USERS or row["username"].lower() == OWNER_USERNAME):   # DarkGram owner: gold tick on first activity
                    nb = 3 if row["username"].lower() == OWNER_USERNAME else 2
                    with conn.db:
                        conn.db.execute("UPDATE users SET badge=?, premium=1 WHERE id=?", (nb, conn.uid))
                    self._badges[conn.uid] = nb
                    self._premium.add(conn.uid)
            result = handler(conn, req) or {}
            if rid is not None:                      # fire-and-forget ops (call audio) send no id -> no reply
                conn.send({"id": rid, "ok": True, **result})
        except Fail as e:
            if rid is not None:
                conn.send({"id": rid, "ok": False, "error": str(e)})
        except sqlite3.Error as e:
            log("db error:", repr(e))
            conn.send({"id": rid, "ok": False, "error": "خطای دیتابیس"})
        except Exception as e:
            log("handler error:", op, repr(e))
            conn.send({"id": rid, "ok": False, "error": "خطای داخلی سرور"})
        if op == "logout":
            conn.close()

    # ------------------------------------------------------------- helpers
    def is_online(self, uid):
        with self.sessions_lock:
            return bool(self.sessions.get(uid))

    def push(self, uids, event, exclude=None):
        with self.sessions_lock:
            targets = [c for u in set(uids) for c in self.sessions.get(u, []) if c is not exclude]
        for c in targets:
            c.send(event)

    def _throttle_ip(self, ip, limit=30, window=60, bucket="auth"):
        q = self.ip_hits[(ip, bucket)]
        t = time.time()
        while q and q[0] < t - window:
            q.popleft()
        if len(q) >= limit:
            raise Fail("تلاش‌های زیاد؛ یه دقیقه صبر کن")
        q.append(t)

    def _user_public(self, row):
        keys = row.keys()
        d = {"id": row["id"], "username": row["username"], "display_name": self._badged(row["id"], row["display_name"]),
             "badge": self._badges.get(row["id"], 0), "premium": row["id"] in self._premium,
             "stars": (row["stars"] if "stars" in keys else 0),
             "emoji_status": (row["emoji_status"] if "emoji_status" in keys else ""),
             "bio": row["bio"], "online": self.is_online(row["id"]), "last_seen": row["last_seen"],
             "avatar_at": (row["avatar_at"] if "avatar_at" in keys and row["avatar"] else 0)}
        if "is_bot" in keys and row["is_bot"]:
            d.update(bot=True, online=True, last_seen=None)        # bots are always "there"; details added in _user_for
        return d

    def _msg(self, db, r):
        deleted = bool(r["deleted"])
        d = {"id": r["id"], "chat_id": r["chat_id"], "sender_id": r["sender_id"],
             "sender_name": self._badged(r["sender_id"], r["sender_name"]) if "sender_name" in r.keys() and r["sender_name"] else None,
             "sender_tag": (r["sender_tag"] if "sender_tag" in r.keys() else None) or None,
             "kind": r["kind"], "body": "" if deleted else (r["body"] or "").replace("\u2063", "").replace("\u2064", ""), "reply_to": r["reply_to"],
             "created_at": r["created_at"], "edited_at": r["edited_at"], "deleted": deleted,
             "file": None, "reply": None, "fwd": None, "reactions": []}
        meta = {}
        if "meta" in r.keys() and r["meta"]:
            try:
                meta = json.loads(r["meta"])
            except ValueError:
                meta = {}
        if not deleted:
            d["fwd"] = meta.get("fwd")
            d["markup"] = meta.get("markup")           # inline keyboard of a bot message
            d["story"] = meta.get("story")             # "reply to a story"
            d["sticker"] = meta.get("sticker")         # DarkGram Premium sticker (body holds the emoji too)
            d["gift"] = meta.get("gift")               # Telegram-Stars gift card {id, art, name, price, to}
            d["secret"] = bool(meta.get("secret"))     # e.g. a bot token: kept out of notifications
            d["reactions"] = self._reactions(db, r["id"])
            d["stars"] = self._star_info(db, r["id"])
        if r["kind"] == "file" and not deleted:
            d["file"] = {"name": r["file_name"], "size": r["file_size"], "kind": media_info(r["file_name"])[1]}
            if meta.get("voice"):
                d["file"].update(voice=True, dur=meta.get("dur"), wave=meta.get("wave"),
                                 played=[x[0] for x in db.execute(
                                     "SELECT user_id FROM voice_plays WHERE message_id=?", (r["id"],))])
            elif d["file"]["kind"] == "image" and not str(r["file_name"]).lower().endswith(".gif"):
                d["file"].update(thumb=True, tw=meta.get("tw"), th=meta.get("th"))     # made on demand by the server
            elif d["file"]["kind"] == "video" and resolve_upload(thumb_rel(r["file_path"])):
                d["file"].update(thumb=True, tw=meta.get("tw"), th=meta.get("th"))
        if r["reply_to"]:
            q = db.execute("SELECT m.id, m.body, m.kind, m.file_name, m.deleted, u.display_name AS sender_name "
                           "FROM messages m LEFT JOIN users u ON u.id=m.sender_id WHERE m.id=?",
                           (r["reply_to"],)).fetchone()
            if q:
                text = "پیام حذف شده" if q["deleted"] else (q["body"] or ("📎 " + (q["file_name"] or "فایل")))
                d["reply"] = {"id": q["id"], "sender_name": q["sender_name"], "text": text[:120]}
        return d

    def _star_info(self, db, mid):
        rows = db.execute("SELECT user_id, amount FROM star_reacts WHERE message_id=? ORDER BY amount DESC", (mid,)).fetchall()
        if not rows:
            return None
        top = None
        u = db.execute("SELECT display_name FROM users WHERE id=?", (rows[0]["user_id"],)).fetchone()
        if u:
            top = {"id": rows[0]["user_id"], "name": self._badged(rows[0]["user_id"], u["display_name"]), "amount": rows[0]["amount"]}
        return {"total": sum(r["amount"] for r in rows),
                "amounts": [{"id": r["user_id"], "amount": r["amount"]} for r in rows], "top": top}

    def _reactions(self, db, mid):
        out = {}
        for r in db.execute("SELECT emoji, user_id FROM reactions WHERE message_id=? ORDER BY created_at", (mid,)):
            out.setdefault(r["emoji"], []).append(r["user_id"])
        return [{"e": e, "users": u} for e, u in out.items()]

    def _msg_by_id(self, db, mid):
        r = db.execute("SELECT m.*, u.display_name AS sender_name, mb.tag AS sender_tag FROM messages m "
                       "LEFT JOIN users u ON u.id=m.sender_id "
                       "LEFT JOIN members mb ON mb.chat_id=m.chat_id AND mb.user_id=m.sender_id WHERE m.id=?", (mid,)).fetchone()
        return self._msg(db, r) if r else None

    def _member_ids(self, db, chat_id):
        return [r["user_id"] for r in db.execute("SELECT user_id FROM members WHERE chat_id=?", (chat_id,))]

    def _require_member(self, db, chat_id, uid):
        try:
            chat_id = int(chat_id)
        except (TypeError, ValueError):
            raise Fail("چت نامعتبر")
        row = db.execute("SELECT * FROM members WHERE chat_id=? AND user_id=?", (chat_id, uid)).fetchone()
        if not row:
            raise Fail("به این چت دسترسی نداری")
        return chat_id, row

    def _chat_view(self, db, chat_id, uid):
        c = db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
        me = db.execute("SELECT * FROM members WHERE chat_id=? AND user_id=?", (chat_id, uid)).fetchone()
        if not c or not me:
            return None
        last = db.execute("SELECT m.*, u.display_name AS sender_name FROM messages m LEFT JOIN users u "
                          "ON u.id=m.sender_id WHERE m.chat_id=? AND m.deleted=0 ORDER BY m.id DESC LIMIT 1", (chat_id,)).fetchone()
        unread = db.execute("SELECT COUNT(*) FROM messages WHERE chat_id=? AND id>? AND deleted=0 "
                            "AND kind!='system' AND IFNULL(sender_id,0)!=?",
                            (chat_id, me["last_read_id"], uid)).fetchone()[0]
        my_rr = db.execute("SELECT read_receipts FROM users WHERE id=?", (uid,)).fetchone()
        peer_read = 0
        if my_rr is None or my_rr[0]:          # both sides must have read receipts on (like Telegram)
            peer_read = db.execute("SELECT IFNULL(MAX(m.last_read_id),0) FROM members m JOIN users u ON u.id=m.user_id "
                                   "WHERE m.chat_id=? AND m.user_id!=? AND u.read_receipts=1", (chat_id, uid)).fetchone()[0]
        count = db.execute("SELECT COUNT(*) FROM members WHERE chat_id=?", (chat_id,)).fetchone()[0]
        title = self._cbadged(c["id"], c["title"])
        if c["channel"]:
            title += PREM_MARK + OFFICIAL_MARK
        if c["news"]:
            title += NEWS_MARK
        view = {"id": c["id"], "kind": c["kind"], "title": title, "badge": self._cbadges.get(c["id"], 0), "owner_id": c["owner_id"],
                "official": bool(c["channel"]),
                "unread": unread, "last": self._msg(db, last) if last else None, "peer_read": peer_read,
                "member_count": count, "created_at": c["created_at"], "peer": None, "saved": False,
                "avatar_at": c["avatar_at"] if c["avatar"] else 0, "description": c["description"] or "",
                "channel": bool(c["channel"] or c["chan"]), "bcast": bool(c["chan"]), "username": c["username"],
                "invite": c["invite"] if me["role"] == "owner" else None, "can_post": self._can_post(db, chat_id, uid),
                "my_read": me["last_read_id"], "my_role": me["role"], "muted": bool(me["muted"]), "fav": bool(me["fav"]), "pin_msg": None}
        if c["pinned_id"]:
            pm = db.execute("SELECT m.*, u.display_name AS sender_name FROM messages m LEFT JOIN users u "
                            "ON u.id=m.sender_id WHERE m.id=? AND m.deleted=0", (c["pinned_id"],)).fetchone()
            if pm:
                view["pin_msg"] = {"id": pm["id"], "sender_name": pm["sender_name"],
                                   "text": (pm["body"] or ("📎 " + (pm["file_name"] or "فایل")))[:120]}
        if c["kind"] == "private":
            other = db.execute("SELECT u.* FROM members m JOIN users u ON u.id=m.user_id "
                               "WHERE m.chat_id=? AND m.user_id!=?", (chat_id, uid)).fetchone()
            if other:
                view["title"] = self._badged(other["id"], other["display_name"])
                view["peer"] = self._user_for(db, other, uid)
            elif count == 1:                                   # chat with yourself = "Saved messages"
                view["saved"] = True
                view["title"] = "پیام‌های ذخیره‌شده"
                view["peer_read"] = db.execute("SELECT IFNULL(MAX(id),0) FROM messages WHERE chat_id=?",
                                               (chat_id,)).fetchone()[0]
        return view

    def _push_chat_update(self, db, chat_id):
        """Every member gets his own fresh view of the chat (title, photo, pinned message, ...)."""
        for u in self._member_ids(db, chat_id):
            view = self._chat_view(db, chat_id, u)
            if view:
                self.push([u], {"event": "chat_updated", "chat": view})

    def _system_message(self, db, chat_id, text):
        ch = db.execute("SELECT chan FROM chats WHERE id=?", (chat_id,)).fetchone()
        if ch and ch["chan"]:                                  # channels stay clean: no "X joined / left" lines
            return None
        with db:
            cur = db.execute("INSERT INTO messages(chat_id, sender_id, kind, body, created_at) "
                             "VALUES (?,NULL,'system',?,?)", (chat_id, text, now()))
        msg = self._msg_by_id(db, cur.lastrowid)
        self.push(self._member_ids(db, chat_id), {"event": "message", "message": msg})
        return msg

    # -------------------------------------------------------- auth: public
    def op_ping(self, conn, req):
        return {"pong": now()}

    def _new_session(self, db, uid, device=""):
        token = secrets.token_urlsafe(32)
        device = CTRL_RE.sub("", str(device or ""))[:80]
        with db:
            db.execute("DELETE FROM sessions WHERE last_used<?", (now() - SESSION_TTL,))
            cur = db.execute("INSERT INTO sessions(user_id, token_hash, device, created_at, last_used) "
                             "VALUES (?,?,?,?,?)", (uid, hashlib.sha256(token.encode()).digest(), device, now(), now()))
        return token, cur.lastrowid

    def _login_ok(self, conn, row, device=None):
        conn.uid = row["id"]
        with self.sessions_lock:
            first = not self.sessions[row["id"]]
            self.sessions[row["id"]].append(conn)
        with conn.db:
            conn.db.execute("UPDATE users SET last_seen=? WHERE id=?", (now(), row["id"]))
        if first:
            self._broadcast_presence(conn.db, row["id"], True)
        fresh = conn.db.execute("SELECT * FROM users WHERE id=?", (row["id"],)).fetchone()
        out = {"me": self._me_view(fresh)}
        if device is not None:                      # fresh login/register -> remember this device
            token, conn.session_id = self._new_session(conn.db, row["id"], device)
            out["session"] = token
        return out

    def op_register(self, conn, req):
        self._throttle_ip(conn.ip, limit=10, window=600, bucket="register")
        username = str(req.get("username", "")).strip()
        if not USERNAME_RE.match(username):
            raise Fail("نام کاربری باید ۳ تا ۳۲ کاراکتر و فقط شامل حرف انگلیسی، عدد یا _ باشه")
        if username.lower() in RESERVED:
            raise Fail("این نام کاربری رزرو شده")
        if username.lower().endswith("bot"):
            raise Fail("نام‌های کاربری که با bot تموم می‌شن مخصوص رباتن؛ یه اسم دیگه بذار")
        password = req.get("password", "")
        err = check_password_rules(password, username)
        if err:
            raise Fail(err)
        display = clean_line(req.get("display_name") or username, 40, "نام نمایشی") or username
        self._check_display_name(display, username)
        question = clean_line(req.get("sec_question"), 100, "سوال امنیتی")
        answer = normalize_answer(req.get("sec_answer", ""))
        if len(question) < 5:
            raise Fail("یه سوال امنیتی انتخاب کن")
        if len(answer) < 2:
            raise Fail("جواب سوال امنیتی خیلی کوتاهه")
        if len(answer) > 100:
            raise Fail("جواب سوال امنیتی خیلی طولانیه")
        if conn.db.execute("SELECT 1 FROM chats WHERE username=? COLLATE NOCASE", (username,)).fetchone():
            raise Fail("این نام کاربری قبلاً گرفته شده")
        ps, ph = hash_secret(password)
        ss, sh = hash_secret(answer)
        try:
            with conn.db:
                cur = conn.db.execute(
                    "INSERT INTO users(username, display_name, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                    " created_at) VALUES (?,?,?,?,?,?,?,?)", (username, display, ps, ph, question, ss, sh, now()))
        except sqlite3.IntegrityError:
            raise Fail("این نام کاربری قبلاً گرفته شده")
        row = conn.db.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
        try:
            self._ensure_channel(conn.db)
        except sqlite3.Error:
            pass
        log("registered", username)
        return self._login_ok(conn, row, device=req.get("device", ""))

    def _check_lock(self, row):
        if row["locked_until"] > now():
            raise Fail(f"حساب موقتاً قفل شده؛ {row['locked_until'] - now()} ثانیه دیگه تلاش کن")

    def _register_failure(self, db, row):
        fails = row["failed_logins"] + 1
        if fails >= MAX_FAILS:
            with db:
                db.execute("UPDATE users SET failed_logins=0, locked_until=? WHERE id=?",
                           (now() + LOCK_SECONDS, row["id"]))
            raise Fail("چند بار اشتباه زدی؛ حساب ۵ دقیقه قفل شد")
        with db:
            db.execute("UPDATE users SET failed_logins=? WHERE id=?", (fails, row["id"]))

    def op_login(self, conn, req):
        self._throttle_ip(conn.ip)
        username = str(req.get("username", "")).strip()
        password = str(req.get("password", ""))
        row = conn.db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone() \
            if USERNAME_RE.match(username) else None
        generic = Fail("نام کاربری یا رمز اشتباهه")
        if row is not None and row["is_bot"]:
            hash_secret(password[:128])
            raise generic
        if row is None:
            hash_secret(password[:128])  # equalise timing, no user enumeration
            raise generic
        self._check_lock(row)
        if not verify_secret(password[:128], row["pw_salt"], row["pw_hash"]):
            self._register_failure(conn.db, row)
            raise generic
        if row["banned"]:
            raise Fail("این حساب مسدود شده")
        with conn.db:
            conn.db.execute("UPDATE users SET failed_logins=0 WHERE id=?", (row["id"],))
        return self._login_ok(conn, row, device=req.get("device", ""))

    def op_resume(self, conn, req):
        """Log back in with the saved session token (this is what keeps you signed in, like Telegram)."""
        self._throttle_ip(conn.ip, limit=60, window=60, bucket="resume")
        token = str(req.get("token") or "")
        if conn.uid is not None:
            return self.op_me(conn, req)
        expired = Fail("نشست تموم شده؛ دوباره وارد شو")
        if not 20 <= len(token) <= 100:
            raise expired
        row = conn.db.execute("SELECT s.id AS sid, s.last_used, u.* FROM sessions s JOIN users u ON u.id=s.user_id "
                              "WHERE s.token_hash=?", (hashlib.sha256(token.encode()).digest(),)).fetchone()
        if row is None:
            raise expired
        if row["last_used"] < now() - SESSION_TTL:
            with conn.db:
                conn.db.execute("DELETE FROM sessions WHERE id=?", (row["sid"],))
            raise expired
        if row["banned"]:
            raise Fail("این حساب مسدود شده")
        if now() - row["last_used"] > 3600:
            with conn.db:
                conn.db.execute("UPDATE sessions SET last_used=? WHERE id=?", (now(), row["sid"]))
        conn.session_id = row["sid"]
        return self._login_ok(conn, row)

    def op_reset_question(self, conn, req):
        self._throttle_ip(conn.ip)
        username = str(req.get("username", "")).strip()
        row = conn.db.execute("SELECT sec_question FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone() \
            if USERNAME_RE.match(username) else None
        if row:
            return {"question": row["sec_question"]}
        idx = int(hashlib.sha256(username.lower().encode()).hexdigest(), 16) % len(SECURITY_QUESTIONS)
        return {"question": SECURITY_QUESTIONS[idx]}   # same shape for unknown users

    def op_reset_password(self, conn, req):
        self._throttle_ip(conn.ip, limit=10, bucket="reset")
        username = str(req.get("username", "")).strip()
        answer = normalize_answer(req.get("answer", ""))
        new_pw = req.get("new_password", "")
        row = conn.db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone() \
            if USERNAME_RE.match(username) else None
        generic = Fail("جواب امنیتی اشتباهه")
        if row is not None and row["is_bot"]:
            hash_secret(answer[:100])
            raise generic
        if row is None:
            hash_secret(answer[:100])
            raise generic
        self._check_lock(row)
        if not verify_secret(answer[:100], row["sec_salt"], row["sec_hash"]):
            self._register_failure(conn.db, row)
            raise generic
        err = check_password_rules(new_pw, username)
        if err:
            raise Fail(err)
        salt, digest = hash_secret(new_pw)
        with conn.db:
            conn.db.execute("UPDATE users SET pw_salt=?, pw_hash=?, failed_logins=0, locked_until=0 WHERE id=?",
                            (salt, digest, row["id"]))
            conn.db.execute("DELETE FROM sessions WHERE user_id=?", (row["id"],))
        log("password reset for", username)
        return {}

    # --------------------------------------------------- account (authed)
    # ---------------------------------------------------------- web push (notifications while the app is closed)
    def _pusher_get(self):
        if getattr(self, "_pusher", None) is None:
            import webpush
            key, pub = webpush.load_vapid(common.DATA_DIR)
            def gone(ep):
                d = connect_db(self.db_path)
                try:
                    with d:
                        d.execute("DELETE FROM push_subs WHERE endpoint=?", (ep,))
                finally:
                    d.close()
            self._pusher = webpush.Pusher(key, pub, gone)
        return self._pusher

    def _push_wake(self, db, chat_id, sender_uid, members):
        """members whose app is closed/hidden get a content-free push (muted chats and the sender are skipped)"""
        for r in db.execute("SELECT user_id, muted FROM members WHERE chat_id=?", (chat_id,)).fetchall():
            uid = r["user_id"]
            if uid == sender_uid or r["muted"]:
                continue
            with self.sessions_lock:
                if any(c.alive and c.vis and time.time() - c.vis_at < 50 for c in self.sessions.get(uid, [])):
                    continue
            if not self._room_hits(("wake", uid), 1, 15):
                continue
            subs = db.execute("SELECT endpoint FROM push_subs WHERE user_id=?", (uid,)).fetchall()
            if subs:
                p = self._pusher_get()
                for s_ in subs:
                    p.send(s_["endpoint"])

    # ------------------------------------------------ notifications for the Android app (long-poll, no Google needed)
    def _notify_add(self, db, chat_id, sender_uid, msg):
        chat = db.execute("SELECT kind, title FROM chats WHERE id=?", (chat_id,)).fetchone()
        if not chat or msg.get("kind") == "system":
            return
        f = msg.get("file")
        text = (("🎤 پیام صوتی" if f.get("voice") else "📎 " + str(f.get("name"))) if f else str(msg.get("body") or ""))[:120]
        if msg.get("secret"):
            text = "🔑 پیام محرمانه (باز کن و ببین)"
        sender = msg.get("sender_name") or ""
        title = sender if chat["kind"] == "private" else (chat["title"] or "گروه")
        if chat["kind"] != "private" and sender:
            text = sender + ": " + text
        with self.notify_cv:
            for r in db.execute("SELECT user_id, muted FROM members WHERE chat_id=?", (chat_id,)).fetchall():
                if r["user_id"] == sender_uid or r["muted"]:
                    continue
                self.notify_seq[r["user_id"]] += 1
                self.notify_q[r["user_id"]].append({"seq": self.notify_seq[r["user_id"]], "chat_id": chat_id, "title": title, "text": text})
            self.notify_cv.notify_all()

    def notify_poll(self, token, since, ip, timeout=25):
        """POST /notify {token, since}: blocks up to `timeout` s until a new message arrived for this session's user.
        since=-1 just returns the current sequence number. Returns (http status, dict)."""
        if not self._room_hits(("poll", ip), 40, 60):
            return 429, {"ok": False, "error": "slow down"}
        token = str(token or "")
        if not 20 <= len(token) <= 100:
            return 403, {"ok": False, "error": "bad token"}
        db = connect_db(self.db_path)
        try:
            row = db.execute("SELECT s.last_used, u.id AS uid, u.banned FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?",
                             (hashlib.sha256(token.encode()).digest(),)).fetchone()
        finally:
            db.close()
        if row is None or row["banned"] or row["last_used"] < now() - SESSION_TTL:
            return 403, {"ok": False, "error": "session"}
        uid = row["uid"]
        try:
            since = int(since)
        except (TypeError, ValueError):
            since = -1
        end = time.time() + timeout
        with self.notify_cv:
            if since < 0:
                return 200, {"ok": True, "seq": self.notify_seq[uid], "items": []}
            while self.notify_seq[uid] <= since:
                left = end - time.time()
                if left <= 0:
                    break
                self.notify_cv.wait(left)
            items = [x for x in self.notify_q[uid] if x["seq"] > since]
            return 200, {"ok": True, "seq": self.notify_seq[uid], "items": items}

    def op_push_key(self, conn, req):
        return {"key": self._pusher_get().pub}

    def op_push_subscribe(self, conn, req):
        import webpush
        ep = str(req.get("endpoint") or "")
        if not webpush.allowed_endpoint(ep):
            raise Fail("این سرویس اعلان پشتیبانی نمی‌شه")
        n = conn.db.execute("SELECT COUNT(*) FROM push_subs WHERE user_id=?", (conn.uid,)).fetchone()[0]
        if n >= 10:
            conn.db.execute("DELETE FROM push_subs WHERE endpoint IN (SELECT endpoint FROM push_subs WHERE user_id=? ORDER BY created_at LIMIT 5)", (conn.uid,))
        with conn.db:
            conn.db.execute("INSERT OR REPLACE INTO push_subs(endpoint, user_id, created_at) VALUES (?,?,?)", (ep, conn.uid, now()))
        return {}

    def op_push_test(self, conn, req):
        """diagnose notifications: send now and report what the push service answered (201 = accepted, -1 = this server can't reach it);
        with delay=true send once more after 10 s so you can hide the app and see the real notification"""
        if not self._room_hits(("pushtest", conn.uid), 6, 60):
            raise Fail("آروم‌تر؛ چند ثانیه صبر کن")
        subs = [r["endpoint"] for r in conn.db.execute("SELECT endpoint FROM push_subs WHERE user_id=?", (conn.uid,)).fetchall()]
        p = self._pusher_get()
        codes = [p.deliver(ep) for ep in subs]
        if req.get("delay") and subs:
            threading.Timer(10, lambda: [p.send(ep) for ep in subs]).start()
        return {"subs": len(subs), "codes": codes}

    def op_push_unsubscribe(self, conn, req):
        with conn.db:
            conn.db.execute("DELETE FROM push_subs WHERE endpoint=? AND user_id=?", (str(req.get("endpoint") or ""), conn.uid))
        return {}

    def op_visible(self, conn, req):
        conn.vis = bool(req.get("v"))
        conn.vis_at = time.time()
        return {}

    def op_logout(self, conn, req):
        if conn.session_id:
            with conn.db:
                conn.db.execute("DELETE FROM sessions WHERE id=?", (conn.session_id,))
            conn.session_id = None
        return {}

    def op_me(self, conn, req):
        row = conn.db.execute("SELECT * FROM users WHERE id=?", (conn.uid,)).fetchone()
        return {"me": self._me_view(row)}

    @staticmethod
    def _check_display_name(display, username):
        """Nobody may pose as the admin / official accounts through the display name (look-alike letters and spaces stripped)."""
        import unicodedata
        norm = "".join(ch for ch in unicodedata.normalize("NFKC", display).lower() if ch.isalnum())
        mine = "".join(ch for ch in username.lower() if ch.isalnum())
        official = {"".join(ch for ch in n if ch.isalnum()) for n in (ADMIN_USER, *RESERVED, "مدیر", "ادمین", "پشتیبانی", "مدیریت", "تیگرام", "بات‌فادر")}
        if norm in official and mine != norm:
            raise Fail("این نام نمایشی برای حساب‌های رسمی رزرو شده")

    def op_update_profile(self, conn, req):
        display = clean_line(req.get("display_name"), 40, "نام نمایشی")
        bio = clean_line(req.get("bio"), 300, "بیو")   # DarkGram Premium: longer bio
        if not display:
            raise Fail("نام نمایشی نمی‌تونه خالی باشه")
        self._check_display_name(display, conn.db.execute("SELECT username FROM users WHERE id=?", (conn.uid,)).fetchone()["username"])
        with conn.db:
            conn.db.execute("UPDATE users SET display_name=?, bio=? WHERE id=?", (display, bio, conn.uid))
        self._broadcast_profile(conn.db, conn.uid)
        return self.op_me(conn, req)

    def set_user_avatar(self, db, uid, raw):
        """Called by the HTTP avatar endpoint. The old photo files stay on disk (avatars/<user>/...)."""
        row = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        try:
            rel = store_avatar(avatar_folder_for_user(row["username"]), raw)
        except ValueError as e:
            raise Fail(str(e))
        at = int(time.time() * 1000)
        with db:
            db.execute("UPDATE users SET avatar=?, avatar_at=? WHERE id=?", (rel, at, uid))
        self._broadcast_profile(db, uid)
        return at

    def op_userwall_remove(self, conn, req):
        row = conn.db.execute("SELECT username FROM users WHERE id=?", (conn.uid,)).fetchone()
        try:
            v = int(req.get("v") or 0)
        except (TypeError, ValueError):
            v = 0
        common.retire_user_wall(row["username"], v)
        vs = common.user_wall_versions(row["username"])
        return {"wall_v": vs[0] if vs else 0, "walls": vs}

    def set_user_wall(self, db, uid, raw):
        row = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        try:
            return common.store_user_wall(row["username"], raw)
        except ValueError as e:
            raise Fail(str(e))

    def set_chat_avatar(self, db, uid, chat_id, raw):
        chat_id, me = self._require_member(db, chat_id, uid)
        chat = db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
        allowed = me["role"] == "owner" or (chat["channel"] and self._can_post(db, chat_id, uid))
        if chat["kind"] != "group" or not allowed:
            raise Fail("فقط سازنده گروه (یا مدیر کانال) می‌تونه عکس رو عوض کنه")
        try:
            rel = store_avatar(avatar_folder_for_chat(chat_id, chat["title"]), raw)
        except ValueError as e:
            raise Fail(str(e))
        at = int(time.time() * 1000)
        with db:
            db.execute("UPDATE chats SET avatar=?, avatar_at=? WHERE id=?", (rel, at, chat_id))
        self._push_chat_update(db, chat_id)
        return at

    def op_remove_avatar(self, conn, req):
        """Detach the current photo (the file itself is kept in avatars/ so nothing is ever lost)."""
        if req.get("chat_id"):
            chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
            ch = conn.db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
            if not (me["role"] == "owner" or (ch["channel"] and self._can_post(conn.db, chat_id, conn.uid))):
                raise Fail("فقط سازنده گروه می‌تونه عکس گروه رو عوض کنه")
            retire_avatar(ch["avatar"])
            with conn.db:
                conn.db.execute("UPDATE chats SET avatar=NULL, avatar_at=0 WHERE id=?", (chat_id,))
            self._push_chat_update(conn.db, chat_id)
        else:
            cur_av = conn.db.execute("SELECT avatar FROM users WHERE id=?", (conn.uid,)).fetchone()["avatar"]
            retire_avatar(cur_av)
            with conn.db:
                conn.db.execute("UPDATE users SET avatar=NULL, avatar_at=0 WHERE id=?", (conn.uid,))
            self._broadcast_profile(conn.db, conn.uid)
        return {}

    def op_wallpaper_list(self, conn, req):
        return {"walls": [{"name": n, "v": m, "size": s} for n, m, s in common.list_wallpapers()]}

    def op_avatar_list(self, conn, req):
        """All kept profile photos of a user or group (for the swipe-through gallery), newest first."""
        if req.get("chat_id"):
            chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
            c = conn.db.execute("SELECT title FROM chats WHERE id=?", (chat_id,)).fetchone()
            return {"pics": avatar_pics(avatar_folder_for_chat(chat_id, c["title"] or "")), "chat_id": chat_id}
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("کاربر نامعتبر")
        u = conn.db.execute("SELECT username, banned FROM users WHERE id=?", (uid,)).fetchone()
        if not u or u["banned"]:
            raise Fail("کاربر پیدا نشد")
        return {"pics": avatar_pics(avatar_folder_for_user(u["username"])), "user_id": uid}

    # --------------------------------------- group @id and invite links
    def _new_invite(self, db, chat_id):
        for _ in range(5):
            tok = secrets.token_urlsafe(9)
            try:
                with db:
                    db.execute("UPDATE chats SET invite=? WHERE id=?", (tok, chat_id))
                return tok
            except sqlite3.IntegrityError:
                continue
        raise Fail("ساخت لینک ناموفق بود")

    def op_invite_link(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        chat = self._group_owner_check(conn, chat_id)
        if me["role"] != "owner":
            raise Fail("فقط سازنده گروه به لینک دعوت دسترسی داره")
        tok = chat["invite"]
        if not tok or req.get("reset"):
            tok = self._new_invite(conn.db, chat_id)
        return {"invite": tok}

    def op_invite_info(self, conn, req):
        c = self._chat_by_token_or_name(conn.db, req)
        mine = conn.db.execute("SELECT 1 FROM members WHERE chat_id=? AND user_id=?", (c["id"], conn.uid)).fetchone()
        n = conn.db.execute("SELECT COUNT(*) FROM members WHERE chat_id=?", (c["id"],)).fetchone()[0]
        return {"chat": {"id": c["id"], "title": self._cbadged(c["id"], c["title"]), "badge": self._cbadges.get(c["id"], 0), "description": c["description"] or "", "member_count": n,
                         "username": c["username"], "member": bool(mine), "bcast": bool(c["chan"])}}

    def _chat_by_token_or_name(self, db, req):
        tok, name = str(req.get("token") or ""), str(req.get("username") or "").lstrip("@")
        c = None
        if tok and len(tok) < 40:
            c = db.execute("SELECT * FROM chats WHERE invite=? AND kind='group' AND channel=0", (tok,)).fetchone()
        elif name and USERNAME_RE.match(name):
            c = db.execute("SELECT * FROM chats WHERE username=? COLLATE NOCASE AND kind='group' AND channel=0",
                           (name,)).fetchone()
        if not c:
            raise Fail("این لینک یا آیدی معتبر نیست (یا گروه حذف شده)")
        return c

    def op_join(self, conn, req):
        c = self._chat_by_token_or_name(conn.db, req)
        if not conn.db.execute("SELECT 1 FROM members WHERE chat_id=? AND user_id=?", (c["id"], conn.uid)).fetchone():
            n = conn.db.execute("SELECT COUNT(*) FROM members WHERE chat_id=?", (c["id"],)).fetchone()[0]
            if n >= 2000:
                raise Fail("ظرفیت گروه پره")
            with conn.db:
                conn.db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)",
                                (c["id"], conn.uid, now()))
            name = conn.db.execute("SELECT display_name FROM users WHERE id=?", (conn.uid,)).fetchone()[0]
            self._system_message(conn.db, c["id"], f"{name} با لینک به گروه پیوست")
            self.push(self._member_ids(conn.db, c["id"]), {"event": "members_changed", "chat_id": c["id"]})
        return {"chat": self._chat_view(conn.db, c["id"], conn.uid)}

    # ------------------------------------------------ devices (sessions)
    def op_sessions(self, conn, req):
        rows = conn.db.execute("SELECT id, device, created_at, last_used FROM sessions WHERE user_id=? "
                               "ORDER BY last_used DESC", (conn.uid,)).fetchall()
        return {"sessions": [dict(id=r["id"], device=r["device"], created_at=r["created_at"],
                                  last_used=r["last_used"], current=r["id"] == conn.session_id) for r in rows]}

    def op_terminate_session(self, conn, req):
        try:
            sid = int(req.get("session_id"))
        except (TypeError, ValueError):
            raise Fail("نشست نامعتبر")
        with conn.db:
            n = conn.db.execute("DELETE FROM sessions WHERE id=? AND user_id=?", (sid, conn.uid)).rowcount
        if not n:
            raise Fail("نشست پیدا نشد")
        with self.sessions_lock:
            victims = [c for c in self.sessions.get(conn.uid, []) if c.session_id == sid and c is not conn]
        for c in victims:
            c.send({"event": "session_ended"})
            c.close()
        return {}

    def op_terminate_others(self, conn, req):
        with conn.db:
            conn.db.execute("DELETE FROM sessions WHERE user_id=? AND id!=?", (conn.uid, conn.session_id or 0))
        with self.sessions_lock:
            victims = [c for c in self.sessions.get(conn.uid, []) if c is not conn and c.session_id != conn.session_id]
        for c in victims:
            c.send({"event": "session_ended"})
            c.close()
        return {}

    def op_change_password(self, conn, req):
        row = conn.db.execute("SELECT * FROM users WHERE id=?", (conn.uid,)).fetchone()
        self._check_lock(row)
        if not verify_secret(str(req.get("old_password", ""))[:128], row["pw_salt"], row["pw_hash"]):
            self._register_failure(conn.db, row)
            raise Fail("رمز فعلی اشتباهه")
        err = check_password_rules(req.get("new_password", ""), row["username"])
        if err:
            raise Fail(err)
        salt, digest = hash_secret(req["new_password"])
        with conn.db:
            conn.db.execute("UPDATE users SET pw_salt=?, pw_hash=? WHERE id=?", (salt, digest, conn.uid))
            conn.db.execute("DELETE FROM sessions WHERE user_id=? AND id IS NOT ?", (conn.uid, conn.session_id))
        return {}

    def op_search_users(self, conn, req):
        q = str(req.get("q", "")).strip().lstrip("@")
        if not q:
            return {"users": []}
        if not USERNAME_RE.match(q):
            return {"users": []}
        rows = conn.db.execute("SELECT * FROM users WHERE id!=? AND banned=0 AND username=? COLLATE NOCASE",
                               (conn.uid, q)).fetchall()      # exact username only: nobody can browse the user list
        gr = conn.db.execute("SELECT c.*, (SELECT COUNT(*) FROM members m WHERE m.chat_id=c.id) AS n FROM chats c "
                             "WHERE c.username=? COLLATE NOCASE AND c.kind='group' AND c.channel=0", (q,)).fetchall()
        groups = [{"id": g["id"], "title": self._cbadged(g["id"], g["title"]), "badge": self._cbadges.get(g["id"], 0), "username": g["username"], "member_count": g["n"],
                   "description": g["description"] or "", "bcast": bool(g["chan"])} for g in gr]
        return {"users": [self._user_for(conn.db, r, conn.uid) for r in rows], "groups": groups}

    # ------------------------------------------------------------- chats
    def op_chats(self, conn, req):
        ids = [r[0] for r in conn.db.execute(
            "SELECT c.id FROM chats c JOIN members m ON m.chat_id=c.id WHERE m.user_id=? AND "
            "(c.kind='group' OR c.pair_key=? OR EXISTS (SELECT 1 FROM messages WHERE chat_id=c.id))",
            (conn.uid, f"{conn.uid}:{conn.uid}"))]
        views = [v for v in (self._chat_view(conn.db, i, conn.uid) for i in ids) if v]
        views.sort(key=lambda v: (v["fav"], v["last"]["created_at"] if v["last"] else v["created_at"],
                                  v["last"]["id"] if v["last"] else 0), reverse=True)
        return {"chats": views}

    def op_open_private(self, conn, req):
        username = str(req.get("username", "")).strip().lstrip("@")
        target = conn.db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE AND banned=0", (username,)).fetchone() \
            if USERNAME_RE.match(username) else None
        if not target:
            raise Fail("کاربری با این نام پیدا نشد")
        a, b = sorted((conn.uid, target["id"]))                   # a == b -> "Saved messages"
        key = f"{a}:{b}"
        row = conn.db.execute("SELECT id FROM chats WHERE pair_key=?", (key,)).fetchone()
        if row:
            chat_id = row["id"]
        else:
            with conn.db:
                cur = conn.db.execute("INSERT INTO chats(kind, pair_key, created_at) VALUES ('private',?,?)",
                                      (key, now()))
                chat_id = cur.lastrowid
                for u in {a, b}:
                    conn.db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)",
                                    (chat_id, u, now()))
        return {"chat": self._chat_view(conn.db, chat_id, conn.uid)}

    def op_create_group(self, conn, req):
        chan = 1 if req.get("channel") else 0
        title = clean_line(req.get("title"), 40, "اسم کانال" if chan else "اسم گروه")
        if not title:
            raise Fail("اسم کانال رو بنویس" if chan else "اسم گروه رو بنویس")
        if chan:
            n = conn.db.execute("SELECT COUNT(*) FROM chats WHERE chan=1 AND owner_id=?", (conn.uid,)).fetchone()[0]
            if n >= 20:
                raise Fail("حداکثر ۲۰ کانال می‌تونی بسازی")
        names = req.get("usernames") or []
        if not isinstance(names, list) or len(names) > 50:
            raise Fail("لیست اعضا نامعتبره")
        ids, missing = [], []
        for n in names:
            n = str(n).strip().lstrip("@")
            if not n:
                continue
            row = conn.db.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE AND banned=0", (n,)).fetchone() \
                if USERNAME_RE.match(n) else None
            if row is None:
                missing.append(n)
            elif row["id"] != conn.uid and row["id"] not in ids:
                ids.append(row["id"])
        if missing:
            raise Fail("این کاربرا پیدا نشدن: " + "، ".join(missing))
        with conn.db:
            cur = conn.db.execute("INSERT INTO chats(kind, title, owner_id, created_at, chan) VALUES ('group',?,?,?,?)",
                                  (title, conn.uid, now(), chan))
            chat_id = cur.lastrowid
            conn.db.execute("INSERT INTO members(chat_id, user_id, role, joined_at) VALUES (?,?, 'owner', ?)",
                            (chat_id, conn.uid, now()))
            for u in ids:
                conn.db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)",
                                (chat_id, u, now()))
        me = conn.db.execute("SELECT display_name FROM users WHERE id=?", (conn.uid,)).fetchone()
        for u in ids:
            self.push([u], {"event": "chat_added", "chat": self._chat_view(conn.db, chat_id, u)})
        self._system_message(conn.db, chat_id, f"{me['display_name']} گروه «{title}» رو ساخت")
        if chan:
            self._new_invite(conn.db, chat_id)                 # a channel is shared by link: make it right away
        return {"chat": self._chat_view(conn.db, chat_id, conn.uid)}

    def op_members(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        rows = conn.db.execute("SELECT u.*, m.role, m.tag FROM members m JOIN users u ON u.id=m.user_id "
                               "WHERE m.chat_id=? ORDER BY m.joined_at", (chat_id,)).fetchall()
        ch = conn.db.execute("SELECT chan FROM chats WHERE id=?", (chat_id,)).fetchone()
        if ch and ch["chan"] and not self._can_post(conn.db, chat_id, conn.uid):
            rows = [r for r in rows if r["role"] in ("owner", "admin")]     # subscribers can't browse each other
        return {"members": [dict(self._user_for(conn.db, r, conn.uid), role=r["role"], tag=r["tag"]) for r in rows]}

    def _group_owner_check(self, conn, chat_id):
        chat = conn.db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
        if chat["kind"] != "group" or chat["channel"]:
            raise Fail("این کار فقط تو گروه ممکنه")
        return chat

    def op_add_member(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        chat = self._group_owner_check(conn, chat_id)
        if me["role"] not in ("owner", "admin"):
            raise Fail("فقط سازنده یا ادمین گروه می‌تونه عضو اضافه کنه")
        name = str(req.get("username", "")).strip().lstrip("@")
        target = conn.db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE AND banned=0", (name,)).fetchone() \
            if USERNAME_RE.match(name) else None
        if not target:
            raise Fail("کاربری با این نام پیدا نشد")
        if conn.db.execute("SELECT 1 FROM members WHERE chat_id=? AND user_id=?", (chat_id, target["id"])).fetchone():
            raise Fail("این کاربر قبلاً عضو گروهه")
        with conn.db:
            conn.db.execute("INSERT INTO members(chat_id, user_id, joined_at) VALUES (?,?,?)",
                            (chat_id, target["id"], now()))
        self.push([target["id"]], {"event": "chat_added", "chat": self._chat_view(conn.db, chat_id, target["id"])})
        self._system_message(conn.db, chat_id, f"{target['display_name']} به گروه اضافه شد")
        self.push(self._member_ids(conn.db, chat_id), {"event": "members_changed", "chat_id": chat_id})
        return {}

    def op_set_role(self, conn, req):
        """owner promotes a member to admin (add/remove members, pin, edit group info) or demotes him again"""
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        self._group_owner_check(conn, chat_id)
        if me["role"] != "owner":
            raise Fail("فقط سازنده گروه می‌تونه ادمین تعیین کنه")
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("کاربر نامعتبر")
        role = "admin" if req.get("admin") else "member"
        t = conn.db.execute("SELECT role FROM members WHERE chat_id=? AND user_id=?", (chat_id, uid)).fetchone()
        if not t or t["role"] == "owner":
            raise Fail("این کاربر عضو عادی گروه نیست")
        with conn.db:
            conn.db.execute("UPDATE members SET role=? WHERE chat_id=? AND user_id=?", (role, chat_id, uid))
        name = conn.db.execute("SELECT display_name FROM users WHERE id=?", (uid,)).fetchone()[0]
        self._system_message(conn.db, chat_id, f"{name} " + ("ادمین شد" if role == "admin" else "دیگه ادمین نیست"))
        self.push(self._member_ids(conn.db, chat_id), {"event": "members_changed", "chat_id": chat_id})
        for m in self._member_ids(conn.db, chat_id):
            self.push([m], {"event": "chat_updated", "chat": self._chat_view(conn.db, chat_id, m)})
        return {}

    def op_remove_member(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        self._group_owner_check(conn, chat_id)
        if me["role"] not in ("owner", "admin"):
            raise Fail("فقط سازنده یا ادمین گروه می‌تونه عضو حذف کنه")
        try:
            uid = int(req.get("user_id"))
        except (TypeError, ValueError):
            raise Fail("کاربر نامعتبر")
        if uid == conn.uid:
            raise Fail("برای خروج از «ترک گروه» استفاده کن")
        target = conn.db.execute("SELECT display_name FROM users WHERE id=?", (uid,)).fetchone()
        trole = conn.db.execute("SELECT role FROM members WHERE chat_id=? AND user_id=?", (chat_id, uid)).fetchone()
        if trole and trole["role"] == "owner" or (trole and trole["role"] == "admin" and me["role"] != "owner"):
            raise Fail("ادمین‌ها رو فقط سازنده گروه می‌تونه حذف کنه")
        with conn.db:
            n = conn.db.execute("DELETE FROM members WHERE chat_id=? AND user_id=?", (chat_id, uid)).rowcount
        if not n:
            raise Fail("این کاربر عضو گروه نیست")
        self.push([uid], {"event": "chat_removed", "chat_id": chat_id})
        self._system_message(conn.db, chat_id, f"{target['display_name']} از گروه حذف شد")
        self.push(self._member_ids(conn.db, chat_id), {"event": "members_changed", "chat_id": chat_id})
        return {}

    def op_leave(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        ch = self._group_owner_check(conn, chat_id)
        if ch["chan"] and me["role"] == "owner":
            raise Fail("سازنده نمی‌تونه کانال رو ترک کنه؛ اول یه ادمین بذار یا کانال رو حذف کن")
        name = conn.db.execute("SELECT display_name FROM users WHERE id=?", (conn.uid,)).fetchone()[0]
        with conn.db:
            conn.db.execute("DELETE FROM members WHERE chat_id=? AND user_id=?", (chat_id, conn.uid))
            rest = conn.db.execute("SELECT user_id FROM members WHERE chat_id=? ORDER BY joined_at LIMIT 1",
                                   (chat_id,)).fetchone()
            if rest is None:
                conn.db.execute("DELETE FROM chats WHERE id=?", (chat_id,))
            elif me["role"] == "owner":
                conn.db.execute("UPDATE members SET role='owner' WHERE chat_id=? AND user_id=?",
                                (chat_id, rest["user_id"]))
                conn.db.execute("UPDATE chats SET owner_id=? WHERE id=?", (rest["user_id"], chat_id))
        if rest is not None:
            self._system_message(conn.db, chat_id, f"{name} گروه رو ترک کرد")
            self.push(self._member_ids(conn.db, chat_id), {"event": "members_changed", "chat_id": chat_id})
        self.push([conn.uid], {"event": "chat_removed", "chat_id": chat_id}, exclude=conn)
        return {}

    def sweep_deleted_files(self):
        """remove files of deleted groups once their delay is over (unless a forward in another chat still uses the file)"""
        db = connect_db(self.db_path)
        try:
            n = 0
            for r in db.execute("SELECT rel FROM purge_files WHERE due<=?", (now(),)).fetchall():
                if not common.file_in_use(db, r["rel"]):
                    common.remove_upload(r["rel"])
                    n += 1
                with db:
                    db.execute("DELETE FROM purge_files WHERE rel=?", (r["rel"],))
            return n
        finally:
            db.close()

    def op_delete_group(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        self._group_owner_check(conn, chat_id)
        if me["role"] != "owner":
            raise Fail("فقط سازنده گروه می‌تونه گروه رو حذف کنه")
        members = self._member_ids(conn.db, chat_id)
        due = now() + int(common.GROUP_FILE_TTL_HOURS * 3600)
        with conn.db:                    # the group's files are removed GROUP_FILE_TTL_HOURS (4 h) later by the sweeper
            for r in conn.db.execute("SELECT DISTINCT file_path FROM messages WHERE chat_id=? AND file_path IS NOT NULL", (chat_id,)).fetchall():
                conn.db.execute("INSERT OR REPLACE INTO purge_files(rel, due) VALUES (?,?)", (r["file_path"], due))
            conn.db.execute("DELETE FROM chats WHERE id=?", (chat_id,))
        self.push(members, {"event": "chat_removed", "chat_id": chat_id, "deleted": True}, exclude=conn)
        return {}

    # ----------------------------------------------------------- messages
    def op_history(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        try:
            limit = max(1, min(int(req.get("limit") or 40), 100))
            before = int(req["before_id"]) if req.get("before_id") else None
            after = int(req["after_id"]) if req.get("after_id") else None
            around = int(req["around"]) if req.get("around") else None
        except (TypeError, ValueError):
            raise Fail("پارامتر نامعتبر")
        base = ("SELECT m.*, u.display_name AS sender_name, mb.tag AS sender_tag FROM messages m "
                "LEFT JOIN users u ON u.id=m.sender_id "
                "LEFT JOIN members mb ON mb.chat_id=m.chat_id AND mb.user_id=m.sender_id "
                "WHERE m.chat_id=?")
        db = conn.db
        newer = False
        if around:                                           # a window of messages centred on one message
            half = max(5, limit // 2)
            older = db.execute(base + " AND m.id<=? ORDER BY m.id DESC LIMIT ?", (chat_id, around, half + 1)).fetchall()
            nxt = db.execute(base + " AND m.id>? ORDER BY m.id ASC LIMIT ?", (chat_id, around, half + 1)).fetchall()
            has_more, newer = len(older) > half, len(nxt) > half
            rows = list(reversed(older[:half])) + nxt[:half]
        elif after:                                          # scrolling down towards the newest messages
            nxt = db.execute(base + " AND m.id>? ORDER BY m.id ASC LIMIT ?", (chat_id, after, limit + 1)).fetchall()
            has_more, newer, rows = False, len(nxt) > limit, nxt[:limit]
        else:
            sql, args = base, [chat_id]
            if before:
                sql += " AND m.id<?"
                args.append(before)
            rows = db.execute(sql + " ORDER BY m.id DESC LIMIT ?", args + [limit + 1]).fetchall()
            has_more = len(rows) > limit
            rows = list(reversed(rows[:limit]))
        return {"messages": [self._msg(db, r) for r in rows], "has_more": has_more, "has_newer": newer}

    def op_search_messages(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        q = str(req.get("q") or "").strip()[:100]
        if not q:
            return {"messages": []}
        like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        rows = conn.db.execute(
            "SELECT m.*, u.display_name AS sender_name, mb.tag AS sender_tag FROM messages m LEFT JOIN users u ON u.id=m.sender_id "
            "LEFT JOIN members mb ON mb.chat_id=m.chat_id AND mb.user_id=m.sender_id "
            "WHERE m.chat_id=? AND m.deleted=0 AND m.kind!='system' AND (m.body LIKE ? ESCAPE '\\' "
            "OR m.file_name LIKE ? ESCAPE '\\') ORDER BY m.id DESC LIMIT 40", (chat_id, like, like)).fetchall()
        return {"messages": [self._msg(conn.db, r) for r in rows]}

    def op_search_all(self, conn, req):
        """search the text of every chat I am a member of (the main search box)"""
        q = str(req.get("q") or "").strip()[:100]
        if len(q) < 2:
            return {"results": []}
        like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        rows = conn.db.execute(
            "SELECT m.id, m.chat_id, m.body, m.file_name, m.created_at, u.display_name AS sender_name FROM messages m "
            "JOIN members mb ON mb.chat_id=m.chat_id AND mb.user_id=? LEFT JOIN users u ON u.id=m.sender_id "
            "WHERE m.deleted=0 AND m.kind!='system' AND (m.body LIKE ? ESCAPE '\\' OR m.file_name LIKE ? ESCAPE '\\') "
            "ORDER BY m.id DESC LIMIT 30", (conn.uid, like, like)).fetchall()
        return {"results": [{"id": r["id"], "chat_id": r["chat_id"], "sender": r["sender_name"] or "",
                             "text": (r["body"] or r["file_name"] or "")[:160], "at": r["created_at"]} for r in rows]}

    def op_shared(self, conn, req):
        """Shared media/files/voice/links of a chat (the 'Shared media' tabs in the chat info)."""
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        kind = str(req.get("kind") or "media")
        try:
            before = int(req["before_id"]) if req.get("before_id") else None
        except (TypeError, ValueError):
            raise Fail("پارامتر نامعتبر")
        sql = ("SELECT m.*, u.display_name AS sender_name FROM messages m LEFT JOIN users u ON u.id=m.sender_id "
               "WHERE m.chat_id=? AND m.deleted=0 AND ")
        sql += "m.kind='file'" if kind != "link" else "m.kind='text' AND (m.body LIKE '%http://%' OR m.body LIKE '%https://%')"
        args = [chat_id]
        if before:
            sql += " AND m.id<?"
            args.append(before)
        out = []
        for r in conn.db.execute(sql + " ORDER BY m.id DESC LIMIT 600", args):
            if kind != "link":
                m = self._msg(conn.db, r)
                f = m["file"] or {}
                ok = {"media": f.get("kind") in ("image", "video") and not f.get("voice"),
                      "voice": bool(f.get("voice")),
                      "audio": f.get("kind") == "audio" and not f.get("voice"),
                      "file": f.get("kind") == "file"}.get(kind, False)
                if not ok:
                    continue
            else:
                m = self._msg(conn.db, r)
            out.append(m)
            if len(out) >= 60:
                break
        return {"messages": out}

    def _check_send_rate(self, uid):
        q = self.send_hits[uid]
        t = time.time()
        while q and q[0] < t - 10:
            q.popleft()
        if len(q) >= 20:
            raise Fail("خیلی سریع پیام می‌فرستی، یه لحظه صبر کن")
        q.append(t)

    @staticmethod
    def _safe_filename(name):
        name = os.path.basename(str(name or "file").replace("\\", "/"))
        name = CTRL_RE.sub("", name).strip().strip(".") or "file"
        return name[:100]

    def _store_message(self, db, uid, chat_id, text, reply_to, fname=None, raw=None, src=None, meta=None, ref=None):
        """Insert a text/file message. A file comes either as bytes (`raw`) or as a finished temp file (`src`)."""
        if not fname and not text:
            raise Fail("پیام خالیه")
        if not self._can_post(db, chat_id, uid):
            raise Fail("فقط مدیر می‌تونه تو این کانال پیام بذاره")
        self._check_not_blocked_private(db, chat_id, uid)
        if reply_to:
            if not isinstance(reply_to, int):
                raise Fail("پیامی که جوابش رو می‌دی نامعتبره")
            if not db.execute("SELECT 1 FROM messages WHERE id=? AND chat_id=?", (reply_to, chat_id)).fetchone():
                raise Fail("پیامی که جوابش رو می‌دی پیدا نشد")
        fsize = None
        if fname:
            fsize = len(raw) if raw is not None else Path(src if ref is None else resolve_upload(ref)).stat().st_size
        saved = None
        try:
            with db:       # message row + file on disk succeed or fail together
                cur = db.execute(
                    "INSERT INTO messages(chat_id, sender_id, kind, body, reply_to, file_name, file_size,"
                    " created_at, meta) VALUES (?,?,?,?,?,?,?,?,?)",
                    (chat_id, uid, "file" if fname else "text", text, reply_to or None, fname, fsize, now(),
                     json.dumps(meta, ensure_ascii=False) if meta else None))
                mid = cur.lastrowid
                if fname and ref is not None:        # forward: point at the same stored file, no copy
                    db.execute("UPDATE messages SET file_path=? WHERE id=?", (ref, mid))
                elif fname:
                    rel = upload_relpath(db, chat_id, mid, fname, uid)
                    dest = common.UPLOADS_DIR / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    if raw is not None:
                        dest.write_bytes(raw)
                    else:
                        shutil.move(str(src), str(dest))
                    saved = rel
                    db.execute("UPDATE messages SET file_path=? WHERE id=?", (rel, mid))
                db.execute("UPDATE members SET last_read_id=MAX(last_read_id, ?) WHERE chat_id=? AND user_id=?",
                           (mid, chat_id, uid))
        except Exception as e:
            if saved:
                remove_upload(saved)
            if isinstance(e, OSError):
                raise Fail("ذخیره فایل روی سرور ناموفق بود")
            raise
        return self._msg_by_id(db, mid)

    def _announce(self, db, chat_id, msg, uid, exclude=None):
        members = self._member_ids(db, chat_id)
        self.push(members, {"event": "message", "message": msg}, exclude=exclude)
        try:
            self._notify_add(db, chat_id, uid, msg)
        except Exception as e:
            log("notify queue error:", repr(e))
        try:
            self._push_wake(db, chat_id, uid, members)
        except Exception as e:
            log("push wake error:", repr(e))
        # replying implies you have seen everything before it -> peers get the double tick
        self.push(members, {"event": "read", "chat_id": chat_id, "user_id": uid, "up_to": msg["id"]},
                  exclude=exclude)
        try:
            self._bot_on_message(db, chat_id, msg)
        except Exception as e:
            log("bot hand-over error:", repr(e))

    @staticmethod
    def _voice_meta(name, voice):
        """Validate the voice-message info sent by the client -> meta dict (or None for normal files)."""
        if not voice:
            return None
        if media_info(name)[1] != "audio":
            raise Fail("پیام صوتی باید فایل صوتی باشه")
        try:
            dur = round(float(voice.get("dur")), 1) if isinstance(voice, dict) else 0.0
        except (TypeError, ValueError):
            dur = 0.0
        wave = voice.get("wave") if isinstance(voice, dict) else None
        if isinstance(wave, str):
            wave = [int(x) for x in wave.split(",") if x.strip().isdigit()]
        if not isinstance(wave, list):
            wave = []
        wave = [max(0, min(31, int(x))) for x in wave[:64] if isinstance(x, (int, float))]
        return {"voice": True, "dur": max(0.0, min(dur, 3600.0)), "wave": wave}

    def op_send(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        if not self._is_spam_chat(conn.db, chat_id):
            self._check_restricted(conn.db, conn.uid)
        self._check_send_rate(conn.uid)
        sticker = req.get("sticker")                       # DarkGram Premium sticker message
        if sticker is not None:
            ok = sticker in STICKERS
            if not ok and isinstance(sticker, str) and ":" in sticker:
                pack, _, num = sticker.partition(":")
                if pack in STICKER_PACKS and num.isdigit() and 1 <= int(num) <= STICKER_PACKS[pack]:
                    self._require_premium(conn)   # live image sticker packs are Premium-only
                    ok = True
                elif pack == "user" and num.isdigit():
                    ok = bool(conn.db.execute("SELECT 1 FROM user_stickers WHERE id=? AND user_id=?",
                                              (int(num), conn.uid)).fetchone())
            if not ok:
                raise Fail("استیکر نامعتبر")
            msg = self._store_message(conn.db, conn.uid, chat_id, sticker, req.get("reply_to"), meta={"sticker": sticker})
            self._announce(conn.db, chat_id, msg, conn.uid, exclude=conn)
            return {"message": msg}
        text = CTRL_RE.sub("", str(req.get("text") or "").replace("\r\n", "\n").strip())
        if conn.uid not in self._premium:
            text = CEMJ_RE.sub("", text)
        if len(text) > MAX_TEXT:
            raise Fail(f"پیام خیلی طولانیه (حداکثر {MAX_TEXT} کاراکتر)")
        file = req.get("file")
        fname, raw = None, None
        if file:
            if not isinstance(file, dict):
                raise Fail("فایل نامعتبر")
            try:
                raw = base64.b64decode(str(file.get("data", "")), validate=True)
            except (binascii.Error, ValueError):
                raise Fail("فایل نامعتبر")
            if not raw:
                raise Fail("فایل خالیه")
            if len(raw) > MAX_FILE:
                raise Fail(f"حجم فایل بیشتر از {MAX_FILE // (1024 * 1024)} مگابایته")
            fname = self._safe_filename(file.get("name"))
        meta = self._voice_meta(fname, file.get("voice")) if file else None
        msg = self._store_message(conn.db, conn.uid, chat_id, text, req.get("reply_to"), fname, raw=raw, meta=meta)
        self._announce(conn.db, chat_id, msg, conn.uid, exclude=conn)
        return {"message": msg}

    def create_file_message(self, db, uid, chat_id, text, reply_to, name, src, voice=None):
        """Used by the HTTP upload endpoint (large files are streamed to a temp file first)."""
        user = db.execute("SELECT banned FROM users WHERE id=?", (uid,)).fetchone()
        if user is None or user["banned"]:
            raise Fail("این حساب مسدود شده")
        chat_id, _ = self._require_member(db, chat_id, uid)
        self._check_send_rate(uid)
        text = CTRL_RE.sub("", str(text or "").replace("\r\n", "\n").strip())
        if len(text) > MAX_TEXT:
            raise Fail(f"پیام خیلی طولانیه (حداکثر {MAX_TEXT} کاراکتر)")
        fname = self._safe_filename(name)
        msg = self._store_message(db, uid, chat_id, text, reply_to, fname, src=src, meta=self._voice_meta(fname, voice))
        self._announce(db, chat_id, msg, uid)
        return msg

    # ----------------------------------------------- reactions / forward / pin
    def op_react(self, conn, req):
        try:
            mid = int(req.get("message_id"))
        except (TypeError, ValueError):
            raise Fail("پیام نامعتبر")
        emoji = str(req.get("emoji") or "")
        row = conn.db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
        if not row or row["deleted"] or row["kind"] == "system":
            raise Fail("پیام پیدا نشد")
        self._require_member(conn.db, row["chat_id"], conn.uid)
        if emoji not in REACTIONS:
            raise Fail("این ری‌اکشن مجاز نیست")
        # DarkGram Premium: up to 3 different reactions per user on one message
        mine = conn.db.execute("SELECT emoji, created_at FROM reactions WHERE message_id=? AND user_id=? ORDER BY created_at", (mid, conn.uid)).fetchall()
        with conn.db:
            if any(r["emoji"] == emoji for r in mine):
                conn.db.execute("DELETE FROM reactions WHERE message_id=? AND user_id=? AND emoji=?", (mid, conn.uid, emoji))
            else:
                if len(mine) >= 3:
                    conn.db.execute("DELETE FROM reactions WHERE message_id=? AND user_id=? AND emoji=?", (mid, conn.uid, mine[0]["emoji"]))
                conn.db.execute("INSERT OR REPLACE INTO reactions(message_id, user_id, emoji, created_at) "
                                "VALUES (?,?,?,?)", (mid, conn.uid, emoji, now()))
        msg = self._msg_by_id(conn.db, mid)
        self.push(self._member_ids(conn.db, row["chat_id"]), {"event": "message_updated", "message": msg}, exclude=conn)
        return {"message": msg}

    def op_star_react(self, conn, req):
        """Telegram-style paid Star reaction: stars move from the reactor to the message author."""
        try:
            mid = int(req.get("message_id"))
            amount = int(req.get("amount"))
        except (TypeError, ValueError):
            raise Fail("درخواست نامعتبر")
        if not 1 <= amount <= 100000:
            raise Fail("مبلغ ستاره نامعتبره")
        row = conn.db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
        if not row or row["deleted"] or row["kind"] == "system" or row["sender_id"] is None:
            raise Fail("پیام پیدا نشد")
        self._require_member(conn.db, row["chat_id"], conn.uid)
        author = row["sender_id"]
        unlimited = self._is_owner(conn.db, conn.uid)
        me = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()
        if not unlimited and (not me or me["stars"] < amount):
            raise Fail("موجودی ستاره کافی نیست ⭐")
        with conn.db:
            if not unlimited:
                conn.db.execute("UPDATE users SET stars=stars-? WHERE id=?", (amount, conn.uid))
            if author != conn.uid:
                conn.db.execute("UPDATE users SET stars=stars+? WHERE id=?", (amount, author))
            conn.db.execute("INSERT INTO star_reacts(message_id, user_id, amount, created_at) VALUES (?,?,?,?) "
                            "ON CONFLICT(message_id, user_id) DO UPDATE SET amount=amount+excluded.amount",
                            (mid, conn.uid, amount, now()))
        msg = self._msg_by_id(conn.db, mid)
        self.push(self._member_ids(conn.db, row["chat_id"]), {"event": "message_updated", "message": msg}, exclude=conn)
        bal = conn.db.execute("SELECT stars FROM users WHERE id=?", (conn.uid,)).fetchone()["stars"]
        return {"message": msg, "stars": 999999999 if unlimited else bal}

    def op_forward(self, conn, req):
        try:
            mid = int(req.get("message_id"))
        except (TypeError, ValueError):
            raise Fail("پیام نامعتبر")
        targets = req.get("chat_ids")
        if not isinstance(targets, list) or not 1 <= len(targets) <= 20:   # DarkGram Premium: forward to up to 20 chats
            raise Fail("حداکثر ۲۰ چت رو انتخاب کن")
        src = conn.db.execute("SELECT m.*, u.display_name AS sender_name FROM messages m LEFT JOIN users u "
                              "ON u.id=m.sender_id WHERE m.id=?", (mid,)).fetchone()
        if not src or src["deleted"] or src["kind"] == "system":
            raise Fail("پیام پیدا نشد")
        self._require_member(conn.db, src["chat_id"], conn.uid)
        try:
            meta = json.loads(src["meta"]) if src["meta"] else {}
        except ValueError:
            meta = {}
        meta["fwd"] = meta.get("fwd") or src["sender_name"] or "—"
        sent = []
        for cid in dict.fromkeys(targets):
            cid, _ = self._require_member(conn.db, cid, conn.uid)
            self._check_send_rate(conn.uid)
            if src["kind"] == "file" and resolve_upload(src["file_path"]) is None:
                raise Fail("فایل این پیام روی سرور نیست")
            msg = self._store_message(conn.db, conn.uid, cid, src["body"], None,
                                      src["file_name"] if src["kind"] == "file" else None,
                                      meta=meta, ref=src["file_path"] if src["kind"] == "file" else None)
            self._announce(conn.db, cid, msg, conn.uid, exclude=conn)
            sent.append(msg)
        return {"messages": sent}

    def image_thumb(self, db, row):
        """Small preview of an image message, made (and cached next to the file) the first time somebody needs it."""
        tp = resolve_upload(thumb_rel(row["file_path"]))
        if tp:
            return tp
        src = resolve_upload(row["file_path"])
        if src is None or src.stat().st_size > 60 * 1024 * 1024:
            return None
        try:
            from PIL import Image, ImageOps
            im = Image.open(src)
            im = ImageOps.exif_transpose(im)
            w, h = im.size
            im.thumbnail((360, 360))
            dest = common.UPLOADS_DIR / thumb_rel(row["file_path"])
            dest.parent.mkdir(parents=True, exist_ok=True)
            im.convert("RGB").save(dest, "JPEG", quality=72)
            try:
                meta = json.loads(row["meta"]) if row["meta"] else {}
            except ValueError:
                meta = {}
            if not meta.get("tw"):
                meta.update(tw=w, th=h)
                with db:
                    db.execute("UPDATE messages SET meta=? WHERE id=?", (json.dumps(meta), row["id"]))
            return dest
        except Exception:
            return None

    def op_voice_played(self, conn, req):
        """The listener tells us he played a voice message -> the sender sees it (like Telegram's blue dot)."""
        try:
            mid = int(req.get("message_id"))
        except (TypeError, ValueError):
            raise Fail("پیام نامعتبر")
        row = conn.db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
        if not row or row["deleted"] or row["kind"] != "file" or '"voice"' not in (row["meta"] or ""):
            return {}
        self._require_member(conn.db, row["chat_id"], conn.uid)
        if row["sender_id"] == conn.uid:
            return {}
        with conn.db:
            new = conn.db.execute("INSERT OR IGNORE INTO voice_plays(message_id, user_id, played_at) VALUES (?,?,?)",
                                  (mid, conn.uid, now())).rowcount
        if new:
            self.push(self._member_ids(conn.db, row["chat_id"]),
                      {"event": "voice_played", "chat_id": row["chat_id"], "message_id": mid, "user_id": conn.uid})
        return {}

    def set_thumb(self, db, uid, mid, raw, w=0, h=0):
        """Preview picture of an image/video message (made by the sender's browser). Stored next to the file."""
        row = db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
        if not row or row["deleted"] or row["kind"] != "file" or not row["file_path"]:
            raise Fail("پیام پیدا نشد")
        self._require_member(db, row["chat_id"], uid)
        if row["sender_id"] != uid and resolve_upload(thumb_rel(row["file_path"])):
            raise Fail("پریویو قبلاً ساخته شده")           # any member may add a missing preview, nobody may replace one
        if media_info(row["file_name"])[1] not in ("image", "video"):
            raise Fail("این فایل پریویو نداره")
        try:
            from PIL import Image
            import io
            im = Image.open(io.BytesIO(raw))
            im.thumbnail((360, 360))
            out = io.BytesIO()
            im.convert("RGB").save(out, "JPEG", quality=70)
            raw = out.getvalue()
        except Exception:
            if not raw.startswith(b"\xff\xd8"):
                raise Fail("تصویر پریویو نامعتبره")
        dest = common.UPLOADS_DIR / thumb_rel(row["file_path"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        try:
            meta = json.loads(row["meta"]) if row["meta"] else {}
        except ValueError:
            meta = {}
        meta.update(tw=max(0, min(int(w or 0), 20000)), th=max(0, min(int(h or 0), 20000)))
        with db:
            db.execute("UPDATE messages SET meta=? WHERE id=?", (json.dumps(meta, ensure_ascii=False), mid))
        msg = self._msg_by_id(db, mid)
        self.push(self._member_ids(db, row["chat_id"]), {"event": "message_updated", "message": msg})
        return msg

    def op_pin(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        chat = conn.db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
        if chat["channel"]:
            if not self._can_post(conn.db, chat_id, conn.uid):
                raise Fail("فقط مدیر کانال می‌تونه پیام سنجاق کنه")
        elif chat["kind"] == "group" and me["role"] not in ("owner", "admin"):
            raise Fail("فقط سازنده یا ادمین گروه می‌تونه پیام سنجاق کنه")
        mid = req.get("message_id")
        if mid:
            row = conn.db.execute("SELECT * FROM messages WHERE id=? AND chat_id=?", (mid, chat_id)).fetchone()
            if not row or row["deleted"] or row["kind"] == "system":
                raise Fail("پیام پیدا نشد")
        with conn.db:
            conn.db.execute("UPDATE chats SET pinned_id=? WHERE id=?", (int(mid) if mid else None, chat_id))
        if mid:
            name = conn.db.execute("SELECT display_name FROM users WHERE id=?", (conn.uid,)).fetchone()[0]
            self._system_message(conn.db, chat_id, f"{name} یه پیام رو سنجاق کرد")
        self._push_chat_update(conn.db, chat_id)
        return {}

    def op_chat_settings(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        with conn.db:
            for key in ("muted", "fav"):
                if key in req:
                    conn.db.execute(f"UPDATE members SET {key}=? WHERE chat_id=? AND user_id=?",
                                    (1 if req[key] else 0, chat_id, conn.uid))
        view = self._chat_view(conn.db, chat_id, conn.uid)
        self.push([conn.uid], {"event": "chat_updated", "chat": view}, exclude=conn)
        return {"chat": view}

    def op_edit_group(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        chat = conn.db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
        if chat["kind"] != "group":
            raise Fail("این کار فقط تو گروه ممکنه")
        if chat["channel"]:
            if not self._can_post(conn.db, chat_id, conn.uid):
                raise Fail("فقط مدیر کانال می‌تونه اطلاعاتش رو عوض کنه")
        elif me["role"] not in ("owner", "admin"):
            raise Fail("فقط سازنده یا ادمین گروه می‌تونه اطلاعات گروه رو عوض کنه")
        title = clean_line(req.get("title", chat["title"]), 40, "اسم گروه")
        title = title.replace("\u2063", "").replace("\u2064", "").replace("\u200e", "")
        desc = clean_line(req.get("description", chat["description"]), 200, "توضیح گروه")
        if not title:
            raise Fail("اسم گروه نمی‌تونه خالی باشه")
        uname = chat["username"]
        if "username" in req and not chat["channel"]:
            u = str(req.get("username") or "").strip().lstrip("@")
            if not u:
                uname = None
            else:
                if not USERNAME_RE.match(u) or len(u) < 4:
                    raise Fail("آیدی گروه باید ۴ تا ۳۲ کاراکتر و فقط حرف انگلیسی، عدد یا _ باشه")
                if u.lower() in RESERVED or conn.db.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", (u,)).fetchone():
                    raise Fail("این آیدی قبلاً گرفته شده")
                uname = u
        try:
            with conn.db:
                conn.db.execute("UPDATE chats SET title=?, description=?, username=? WHERE id=?",
                                (title, desc, uname, chat_id))
        except sqlite3.IntegrityError:
            raise Fail("این آیدی قبلاً گرفته شده")
        if title != chat["title"] and not chat["channel"] and not chat["chan"]:
            self._system_message(conn.db, chat_id, f"اسم گروه شد «{title}»")
        self._push_chat_update(conn.db, chat_id)
        return {"chat": self._chat_view(conn.db, chat_id, conn.uid)}

    def _own_message(self, conn, req, allow_owner=False):
        try:
            mid = int(req.get("message_id"))
        except (TypeError, ValueError):
            raise Fail("پیام نامعتبر")
        row = conn.db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
        if not row or row["deleted"] or row["kind"] == "system":
            raise Fail("پیام پیدا نشد")
        _, member = self._require_member(conn.db, row["chat_id"], conn.uid)
        if row["sender_id"] != conn.uid and not (allow_owner and member["role"] in ("owner", "admin")):
            raise Fail("این پیام مال تو نیست")
        return row

    def op_edit(self, conn, req):
        row = self._own_message(conn, req)
        text = CTRL_RE.sub("", str(req.get("text") or "").strip())
        if conn.uid not in self._premium:
            text = CEMJ_RE.sub("", text)
        if not text and row["kind"] == "text":
            raise Fail("پیام نمی‌تونه خالی باشه")
        if len(text) > MAX_TEXT:
            raise Fail("پیام خیلی طولانیه")
        with conn.db:
            conn.db.execute("UPDATE messages SET body=?, edited_at=? WHERE id=?", (text, now(), row["id"]))
        msg = self._msg_by_id(conn.db, row["id"])
        self.push(self._member_ids(conn.db, row["chat_id"]), {"event": "message_updated", "message": msg},
                  exclude=conn)
        return {"message": msg}

    def op_delete(self, conn, req):
        row = self._own_message(conn, req, allow_owner=True)
        remove_upload(row["file_path"], conn.db, row["id"])
        with conn.db:
            conn.db.execute("UPDATE messages SET deleted=1, body='', file_path=NULL WHERE id=?", (row["id"],))
            was_pinned = conn.db.execute("UPDATE chats SET pinned_id=NULL WHERE id=? AND pinned_id=?",
                                         (row["chat_id"], row["id"])).rowcount
            conn.db.execute("DELETE FROM reactions WHERE message_id=?", (row["id"],))
        msg = self._msg_by_id(conn.db, row["id"])
        self.push(self._member_ids(conn.db, row["chat_id"]), {"event": "message_updated", "message": msg},
                  exclude=conn)
        self._push_chat_update(conn.db, row["chat_id"])      # the list shows the message before the deleted one
        return {"message": msg}

    def op_read(self, conn, req):
        chat_id, me = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        try:
            up_to = int(req.get("up_to"))
        except (TypeError, ValueError):
            raise Fail("پارامتر نامعتبر")
        if up_to > me["last_read_id"]:
            with conn.db:
                conn.db.execute("UPDATE members SET last_read_id=? WHERE chat_id=? AND user_id=?",
                                (up_to, chat_id, conn.uid))
            rr = conn.db.execute("SELECT read_receipts FROM users WHERE id=?", (conn.uid,)).fetchone()
            if rr is None or rr[0]:                 # reader turned receipts off -> nobody sees "read"
                ok_users = [r[0] for r in conn.db.execute(
                    "SELECT m.user_id FROM members m JOIN users u ON u.id=m.user_id WHERE m.chat_id=? AND u.read_receipts=1",
                    (chat_id,))]
                self.push(ok_users, {"event": "read", "chat_id": chat_id, "user_id": conn.uid, "up_to": up_to}, exclude=conn)
        return {}

    def op_typing(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        action = "voice" if req.get("action") == "voice" else "text"
        self.push(self._member_ids(conn.db, chat_id),
                  {"event": "typing", "chat_id": chat_id, "user_id": conn.uid, "action": action}, exclude=conn)
        return {}

    def op_get_file(self, conn, req):
        try:
            mid = int(req.get("message_id"))
        except (TypeError, ValueError):
            raise Fail("پیام نامعتبر")
        row = conn.db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
        if not row or row["deleted"] or row["kind"] != "file":
            raise Fail("فایل پیدا نشد")
        self._require_member(conn.db, row["chat_id"], conn.uid)
        path = resolve_upload(row["file_path"])
        if path is None:
            raise Fail("فایل روی سرور نیست")
        if path.stat().st_size > 8 * 1024 * 1024:
            raise Fail("این فایل بزرگه؛ از نسخه وب دانلودش کن")
        return {"name": row["file_name"], "data": base64.b64encode(path.read_bytes()).decode("ascii")}

    # ----------------------------------------------------- media access keys
    def _load_secret(self):
        path = Path(self.db_path).parent / "secret.key"
        try:
            data = path.read_bytes()
            if len(data) >= 32:
                return data
        except OSError:
            pass
        data = os.urandom(32)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            os.chmod(path, 0o600)
        except OSError:
            pass
        return data

    def make_media_key(self, uid):
        """Signed, expiring key the browser puts in /media/... and /upload URLs (players can't send headers)."""
        msg = f"{uid}.{now() + MEDIA_KEY_TTL}"
        return msg + "." + hmac.new(self._secret, msg.encode(), hashlib.sha256).hexdigest()[:40]

    def check_media_key(self, key):
        try:
            uid, exp, sig = str(key).split(".")
            good = hmac.new(self._secret, f"{uid}.{exp}".encode(), hashlib.sha256).hexdigest()[:40]
            if hmac.compare_digest(sig, good) and int(exp) > now():
                return int(uid)
        except (ValueError, TypeError):
            pass
        return None

    def op_media_key(self, conn, req):
        return {"media_key": self.make_media_key(conn.uid)}

    def op_hello(self, conn, req):
        caps = req.get("caps")
        conn.caps = {str(c)[:20] for c in caps[:10]} if isinstance(caps, list) else set()
        me = conn.db.execute("SELECT username FROM users WHERE id=?", (conn.uid,)).fetchone()
        return {"media_key": self.make_media_key(conn.uid), "ice_servers": self.ice_servers,
                "max_upload": common.MAX_UPLOAD, "wall_v": common.current_user_wall(me["username"])[1] if me else 0,
                "walls": common.user_wall_versions(me["username"]) if me else []}

    # ------------------------------------------------------------ voice calls
    # Audio itself flows peer-to-peer (WebRTC); the server only rings, relays offer/answer/ICE and logs the call.
    def _call_of(self, conn, req, need_state=None):
        cid = str(req.get("call_id") or "")
        with self.calls_lock:
            call = self.calls.get(cid)
        if not call or conn.uid not in (call["caller"], call["callee"]):
            raise Fail("تماس دیگه فعال نیست")
        if need_state and call["state"] != need_state:
            raise Fail("تماس دیگه فعال نیست")
        return call

    def op_call_invite(self, conn, req):
        chat_id, _ = self._require_member(conn.db, req.get("chat_id"), conn.uid)
        chat = conn.db.execute("SELECT kind FROM chats WHERE id=?", (chat_id,)).fetchone()
        if chat["kind"] != "private":
            raise Fail("تماس فقط تو چت خصوصی ممکنه")
        peer = conn.db.execute("SELECT u.* FROM members m JOIN users u ON u.id=m.user_id "
                               "WHERE m.chat_id=? AND m.user_id!=?", (chat_id, conn.uid)).fetchone()
        if peer is None or peer["banned"]:
            raise Fail("این کاربر در دسترس نیست")
        if self._is_blocked(conn.db, peer["id"], conn.uid) or self._is_blocked(conn.db, conn.uid, peer["id"]):
            raise Fail("تماس ممکن نیست")
        me = conn.db.execute("SELECT * FROM users WHERE id=?", (conn.uid,)).fetchone()
        with self.calls_lock:
            if conn.uid in self.user_call:
                raise Fail("خودت تو یه تماس دیگه‌ای")
            if peer["id"] in self.user_call:
                raise Fail("کاربر تو تماس دیگه‌ایه")
            with self.sessions_lock:
                targets = [c for c in self.sessions.get(peer["id"], []) if "call" in c.caps and c.alive]
            if not targets:
                raise Fail("کاربر الان آنلاین نیست (یا با برنامه‌ای باز کرده که تماس نداره)")
            cid = secrets.token_hex(8)
            call = {"id": cid, "chat_id": chat_id, "caller": conn.uid, "callee": peer["id"], "caller_conn": conn,
                    "callee_conn": None, "state": "ringing", "started": None, "timer": None,
                    "video": bool(req.get("video"))}
            self.calls[cid] = call
            self.user_call[conn.uid] = self.user_call[peer["id"]] = cid
        call["timer"] = threading.Timer(CALL_RING_SECONDS, self._call_timeout, args=(cid,))
        call["timer"].daemon = True
        call["timer"].start()
        event = {"event": "call_incoming", "call_id": cid, "chat_id": chat_id, "video": call["video"],
                 "from": {"id": me["id"], "username": me["username"], "display_name": me["display_name"]}}
        for c in targets:
            c.send(event)
        return {"call_id": cid}

    def op_call_accept(self, conn, req):
        call = self._call_of(conn, req, "ringing")
        if conn.uid != call["callee"]:
            raise Fail("این تماس مال تو نیست")
        with self.calls_lock:
            if call["state"] != "ringing":
                raise Fail("تماس دیگه فعال نیست")
            call.update(state="active", callee_conn=conn, started=time.time())
        if call["timer"]:
            call["timer"].cancel()
        with self.sessions_lock:
            others = [c for c in self.sessions.get(conn.uid, []) if c is not conn]
        for c in others:                       # stop ringing on the user's other devices
            c.send({"event": "call_ended", "call_id": call["id"], "reason": "answered_elsewhere"})
        call["caller_conn"].send({"event": "call_accepted", "call_id": call["id"]})
        return {}

    def op_call_signal(self, conn, req):
        call = self._call_of(conn, req, "active")
        data = req.get("data")
        if not isinstance(data, dict) or len(json.dumps(data)) > 30000:
            raise Fail("سیگنال نامعتبر")
        peer = call["callee_conn"] if conn is call["caller_conn"] else call["caller_conn"]
        if peer is None or not peer.alive:
            raise Fail("طرف مقابل قطع شد")
        peer.send({"event": "call_signal", "call_id": call["id"], "data": data})
        return {}

    def op_call_audio(self, conn, req):
        """Audio relayed THROUGH this server (works with no internet at all, only the link to this PC).
        Fire-and-forget: the client sends {op:"call_audio", call_id, d:<base64 PCM16>, sr}."""
        call = self._call_of(conn, req, "active")
        d = req.get("d")
        if not isinstance(d, str) or len(d) > 40000:
            raise Fail("صدا نامعتبر")
        peer = call["callee_conn"] if conn is call["caller_conn"] else call["caller_conn"]
        if peer is None or not peer.alive:
            raise Fail("طرف مقابل قطع شد")
        try:
            sr = int(req.get("sr") or 16000)
        except (TypeError, ValueError):
            sr = 16000
        peer.relay({"event": "call_audio", "call_id": call["id"], "d": d, "sr": max(8000, min(sr, 48000)),
                    "c": "opus" if req.get("c") == "opus" else "pcm", "hq": 1 if req.get("hq") else 0})
        return {}

    def op_call_video(self, conn, req):
        """Video frames (small JPEGs) relayed through this server. d == "" means 'camera off'. Fire-and-forget."""
        call = self._call_of(conn, req, "active")
        d = req.get("d")
        if not isinstance(d, str) or len(d) > 120000:
            raise Fail("تصویر نامعتبر")
        peer = call["callee_conn"] if conn is call["caller_conn"] else call["caller_conn"]
        if peer is None or not peer.alive:
            raise Fail("طرف مقابل قطع شد")
        peer.relay({"event": "call_video", "call_id": call["id"], "d": d}, video=True)
        return {}

    def _call_grace(self, call, uid):
        """A participant's socket died mid-call: keep the call alive for CALL_GRACE_SECONDS, tell the other side."""
        cid = call["id"]
        peer_conn = call["callee_conn"] if uid == call["caller"] else call["caller_conn"]
        graces = call.setdefault("grace", {})
        if uid in graces:
            graces[uid].cancel()
        t = threading.Timer(CALL_GRACE_SECONDS, self._grace_expired, args=(cid, uid))
        t.daemon = True
        graces[uid] = t
        t.start()
        if peer_conn is not None and peer_conn.alive:
            peer_conn.send({"event": "call_peer", "call_id": cid, "state": "reconnecting"})

    def _grace_expired(self, cid, uid):
        with self.calls_lock:
            call = self.calls.get(cid)
            pending = bool(call and uid in call.get("grace", {}))
        if pending:
            self._finish_call(cid, "disconnected")

    def op_call_rejoin(self, conn, req):
        call = self._call_of(conn, req, "active")
        key = "caller_conn" if conn.uid == call["caller"] else "callee_conn"
        call[key] = conn
        t = call.setdefault("grace", {}).pop(conn.uid, None)
        if t:
            t.cancel()
        peer = call["callee_conn"] if conn.uid == call["caller"] else call["caller_conn"]
        if peer is not None and peer.alive:
            peer.send({"event": "call_peer", "call_id": call["id"], "state": "connected"})
        return {"peer_online": bool(peer is not None and peer.alive)}

    def op_call_end(self, conn, req):
        call = self._call_of(conn, req)
        if call["state"] == "ringing":
            reason = "cancelled" if conn.uid == call["caller"] else "rejected"
        else:
            reason = "hangup"
        self._finish_call(call["id"], reason, conn.db)
        return {}

    def _call_timeout(self, cid):
        with self.calls_lock:
            call = self.calls.get(cid)
            ringing = bool(call and call["state"] == "ringing")
        if ringing:
            self._finish_call(cid, "missed")

    def _finish_call(self, cid, reason, db=None):
        with self.calls_lock:
            call = self.calls.pop(cid, None)
            if call is None:
                return
            for u in (call["caller"], call["callee"]):
                if self.user_call.get(u) == cid:
                    self.user_call.pop(u, None)
        if call["timer"]:
            call["timer"].cancel()
        for t in call.get("grace", {}).values():
            t.cancel()
        self.push([call["caller"], call["callee"]], {"event": "call_ended", "call_id": cid, "reason": reason})
        own = db is None
        db = db or connect_db(self.db_path)
        try:
            name = lambda uid: (db.execute("SELECT display_name FROM users WHERE id=?", (uid,)).fetchone() or ["—"])[0]
            if call["started"]:
                secs = int(time.time() - call["started"])
                text = f"📞 تماس صوتی · {secs // 60:02d}:{secs % 60:02d}".translate(FA_DIGITS)
            elif reason == "rejected":
                text = f"📞 {name(call['callee'])} تماس رو رد کرد"
            elif reason == "cancelled":
                text = f"📞 {name(call['caller'])} تماس رو لغو کرد"
            else:
                text = f"📞 تماس بی‌پاسخ از {name(call['caller'])}"
            self._system_message(db, call["chat_id"], text)
        finally:
            if own:
                db.close()


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def main():
    ap = argparse.ArgumentParser(description="Teegram server")
    ap.add_argument("--host", default=common.DEFAULT_HOST,
                    help="127.0.0.1 = only this PC, 0.0.0.0 = whole network")
    ap.add_argument("--port", type=int, default=common.DEFAULT_PORT)
    ap.add_argument("--http", action="store_true", help="plain http/no encryption (default is https)")
    ap.add_argument("--tls", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--web", action="store_true", help="also serve the browser UI (open it in Chrome)")
    ap.add_argument("--web-port", type=int, default=8087)
    args = ap.parse_args()
    srv = TeegramServer(args.host, args.port, not args.http, web_port=args.web_port if args.web else None)
    srv.start()
    if args.web and not os.environ.get("TEEGRAM_LAUNCHER"):
        scheme = "https" if srv.tls else "http"
        print(f"\n  Web UI:  {scheme}://127.0.0.1:{args.web_port}   |   on your network: {scheme}://{lan_ip()}:{args.web_port}\n", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
