"""Bots: BotFather (the bot that makes bots) + the Bot API (HTTP, long polling).

How it fits together
* A bot is an ordinary row in `users` with is_bot=1 (nobody can log in as it: random password) plus a row in `bots`
  (owner, SHA-256 of the token, description, commands). Users find it by its exact @username (ends with "bot").
* BotFather is the built-in official bot (username BotFather). It runs inside the server: /newbot, /mybots, token,
  rename, description, commands, photo, delete - with inline buttons.
* The token looks like  <bot id>:<random>  . Only its hash is stored, so a lost token cannot be shown again:
  "new token" revokes the old one and shows the new one once.
* Bots talk to the server with HTTP:  https://HOST/bot<TOKEN>/<method>   (see BOT-API.md).
  Messages reach a bot as "updates" it fetches with getUpdates (long polling - no outgoing connections, no webhooks).
* In groups a bot only receives commands (/x), @mentions of it and replies to its own messages (like Telegram's
  privacy mode), never the whole conversation.
"""
import ast
import base64
import binascii
import hashlib
import hmac
import json
import operator
import os
import random
import re
import secrets
import sqlite3
import threading
import time
import urllib.error
import urllib.request

BOT_USER_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{2,31}$")
TOKEN_RE = re.compile(r"^(\d{1,9}):([A-Za-z0-9_-]{20,64})$")
CMD_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
URL_RE = re.compile(r"^https?://[^\s]{1,500}$", re.I)
MAX_BOTS_PER_USER = 10
UPDATE_KEEP_SECONDS = 24 * 3600
UPDATE_QUEUE_MAX = 1000
MAX_KB_ROWS, MAX_KB_COLS, MAX_KB_TOTAL = 8, 8, 40
BOT_MAX_FILE = 20 * 1024 * 1024         # file sent by a bot (raw body / base64)
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

AI_COMMANDS = [("start", "شروع"), ("help", "راهنما"), ("joke", "یه جوک بگو"), ("pass", "ساخت رمز قوی"),
               ("dice", "تاس بنداز"), ("time", "ساعت و تاریخ")]

BF_COMMANDS = [("usertoken", "توکن API حساب من"), ("newbot", "ساخت ربات جدید"), ("mybots", "ربات‌های من"), ("token", "توکن جدید"),
               ("setname", "تغییر نام"), ("setdescription", "تغییر توضیح"), ("setcommands", "تنظیم دستورها"),
               ("setuserpic", "تغییر عکس"), ("deletebot", "حذف ربات"), ("cancel", "لغو"), ("help", "راهنما")]

WELCOME = ("سلام! من BotFather‌ام 🤖\nبا من ربات می‌سازی و مدیریت می‌کنی؛ بعدش می‌تونی با API (فایل BOT-API.md) "
           "هر کاری دلت خواست باهاشون بکنی.\n\nیکی از گزینه‌ها رو بزن:")

API_HELP = ("📖 راهنمای سریع API\n\n"
            "۱) با /newbot یه ربات بساز و توکن بگیر.\n"
            "۲) آدرس API:  https://آدرس-سرور/bot<TOKEN>/<متد>\n\n"
            "متدها: getMe · getUpdates · sendMessage · sendDocument · sendVoice · editMessageText · "
            "editMessageReplyMarkup · deleteMessage · answerCallbackQuery · sendChatAction · getChat · getFile · "
            "setMyCommands · setMyDescription\n\n"
            "مثال:\n`curl \"https://آدرس-سرور/bot<TOKEN>/getUpdates?timeout=20\"`\n"
            "`curl -X POST \"https://آدرس-سرور/bot<TOKEN>/sendMessage\" -H \"Content-Type: application/json\" "
            "-d '{\"chat_id\":1,\"text\":\"سلام\"}'`\n\n"
            "• پیام‌ها فقط با getUpdates (long polling) می‌رسن؛ وب‌هوک نداریم.\n"
            "• تو گروه‌ها ربات فقط دستورها (/...)، منشن و پاسخ به پیام‌های خودش رو می‌بینه.\n"
            "• دکمه‌های شیشه‌ای: reply_markup با inline_keyboard؛ وقتی کاربر بزنه، یه callback_query می‌رسه.\n"
            "• API حساب شخصی: /usertoken ← آدرس /user<TOKEN>/<متد> (getChats, getMessages, getUpdates, sendMessage, sendDocument…)\n"
            "• مستندات کامل و نمونه کد پایتون: BOT-API.md و examples/echo_bot.py کنار سرور.")


class ApiError(Exception):
    def __init__(self, code, desc):
        super().__init__(desc)
        self.code, self.desc = code, desc


def _line(text, limit):
    return " ".join(_CTRL.sub("", str(text or "")).split())[:limit]


# -*- coding: utf-8 -*-
"""@game bot: word bank + game logic block for bots.py (module level)."""

GAME_BANK = {
"پایتخت‌ها 🌍": [("تهران","پایتخت ایران"),("پاریس","پایتخت فرانسه"),("لندن","پایتخت انگلیس"),("برلین","پایتخت آلمان"),("مادرید","پایتخت اسپانیا"),("مسکو","پایتخت روسیه"),("توکیو","پایتخت ژاپن"),("پکن","پایتخت چین"),("قاهره","پایتخت مصر"),("بغداد","پایتخت عراق"),("کابل","پایتخت افغانستان"),("آنکارا","پایتخت ترکیه"),("باکو","پایتخت آذربایجان"),("ایروان","پایتخت ارمنستان"),("تفلیس","پایتخت گرجستان"),("دوشنبه","پایتخت تاجیکستان"),("تاشکند","پایتخت ازبکستان"),("اتاوا","پایتخت کانادا"),("وین","پایتخت اتریش"),("آتن","پایتخت یونان"),("لیسبون","پایتخت پرتغال"),("استکهلم","پایتخت سوئد"),("اسلو","پایتخت نروژ"),("هلسینکی","پایتخت فنلاند"),("ورشو","پایتخت لهستان"),("پراگ","پایتخت جمهوری چک"),("بوداپست","پایتخت مجارستان"),("بانکوک","پایتخت تایلند"),("هانوی","پایتخت ویتنام"),("سئول","پایتخت کرهٔ جنوبی"),("جاکارتا","پایتخت اندونزی"),("مانیل","پایتخت فیلیپین"),("کانبرا","پایتخت استرالیا"),("هاوانا","پایتخت کوبا"),("تونس","پایتخت تونس"),("رباط","پایتخت مراکش"),("ریاض","پایتخت عربستان"),("دوحه","پایتخت قطر"),("مسقط","پایتخت عمان"),("صنعا","پایتخت یمن"),("دمشق","پایتخت سوریه"),("بیروت","پایتخت لبنان"),("امان","پایتخت اردن"),("منامه","پایتخت بحرین"),("ابوظبی","پایتخت امارات"),("بیشکک","پایتخت قرقیزستان"),("آستانه","پایتخت قزاقستان"),("کاتماندو","پایتخت نپال"),("کلمبو","پایتخت سریلانکا"),("داکا","پایتخت بنگلادش"),("الجزیره","پایتخت الجزایر"),("طرابلس","پایتخت لیبی"),("خارطوم","پایتخت سودان"),("نایروبی","پایتخت کنیا"),("دهلی","پایتخت هند"),("کویت","پایتخت کشور کویت"),("سانتیاگو","پایتخت شیلی"),("لیما","پایتخت پرو")],
"حیوانات 🐾": [("شیر","سلطان جنگل"),("ببر","گربه‌سان راه‌راه"),("پلنگ","گربه‌سان خالدار و سریع"),("گرگ","جد سگ‌های اهلی"),("روباه","حیله‌گر معروف قصه‌ها"),("خرس","عاشق عسل و خواب زمستانی"),("فیل","بزرگ‌ترین حیوان خشکی"),("زرافه","بلندقدترین حیوان دنیا"),("اسب","نجیب و تیزپا"),("گاو","حیوان مزرعه"),("شتر","کشتی صحرا"),("خرگوش","گوش‌دراز و عاشق هویج"),("گربه","حیوان خانگی پشمالو"),("سگ","وفادارترین دوست انسان"),("میمون","شبیه‌ترین حیوان به انسان"),("خفاش","تنها پستاندار پرنده"),("موش","کوچک و عاشق پنیر"),("عقاب","پادشاه آسمان"),("جغد","پرندهٔ شب‌بیدار دانا"),("طوطی","پرندهٔ سخنگو"),("مار","بدون پا و دست"),("تمساح","شکارچی رودخانه"),("لاکپشت","خانه‌اش روی پشتش است"),("قورباغه","دوزیست سبز جهنده"),("ماهی","ساکن آب"),("کوسه","ترسناک‌ترین شکارچی دریا"),("نهنگ","بزرگ‌ترین حیوان دنیا"),("دلفین","باهوش و بازیگوش دریا"),("پروانه","حشرهٔ رنگارنگ زیبا"),("زنبور","سازندهٔ عسل"),("مورچه","کوچک و پرکار"),("عنکبوت","هشت پا و تارباف"),("عقرب","نیش‌دار صحرا"),("آهو","چشم‌قشنگ و تیزپا"),("گوزن","شاخ‌دار جنگل"),("گوسفند","پشم‌دار مزرعه"),("بز","کوهنورد بازیگوش"),("الاغ","باربر صبور"),("خوک","حیوان مزرعه"),("اردک","شناگر پردار"),("خروس","سحرخیز روستا"),("غاز","پرندهٔ سفید گردن‌دراز"),("قو","زیباترین پرندهٔ دریاچه"),("شاهین","سریع‌ترین پرندهٔ شکاری"),("کبوتر","نامه‌رسان قدیمی"),("گنجشک","پرندهٔ کوچک شهری"),("کلاغ","پرندهٔ سیاه باهوش"),("کرگدن","شاخ روی بینی"),("گورخر","اسب راه‌راه"),("کانگورو","بچه‌اش را در کیسه نگه می‌دارد"),("شامپانزه","میمون باهوش"),("سنجاب","عاشق بلوط و فندق"),("حلزون","کندترین مسافر باغچه"),("پنگوئن","پرندهٔ قطبی بدون پرواز"),("شترمرغ","بزرگ‌ترین پرندهٔ دنیا"),("طاووس","دم رنگارنگ چشم‌نواز"),("مرغ","تخم‌گذار مزرعه"),("سوسک","حشرهٔ همه‌جا حاضر"),("مگس","حشرهٔ وزوزکن"),("پشه","نیش‌زن تابستانی"),("ملخ","جهندهٔ سبز مزرعه")],
"میوه و خوراکی 🍎": [("سیب","میوهٔ بهشتی قرمز و سبز"),("گلابی","میوهٔ شیرین و آبدار"),("موز","میوهٔ زرد خمیده"),("پرتقال","مرکبات زمستانی"),("نارنگی","مرکبات کوچک و شیرین"),("لیمو","ترش‌ترین مرکبات"),("هندوانه","میوهٔ تابستانی آب‌دار"),("طالبی","معطر و شیرین"),("خربزه","تابستانی و دراز"),("انگور","خوشه‌ای و شیرین"),("انار","دانه‌های یاقوتی"),("هلو","پشمالو و آبدار"),("شلیل","شبیه هلو بدون پرز"),("زردآلو","نارنجی و کوچک"),("آلو","ترش و شیرین"),("گیلاس","قرمز و دم‌دار"),("آلبالو","ترش و قرمز"),("کیوی","سبز و پرزدار"),("انبه","پادشاه میوه‌های استوایی"),("آناناس","تاج‌دار استوایی"),("نارگیل","سخت‌پوست با آب داخل"),("خرما","شیرین جنوبی"),("انجیر","میوهٔ شیرین بهشتی"),("ازگیل","میوهٔ جنگلی شمال"),("به","معطر، برای مربا"),("خرمالو","نارنجی پاییزی"),("زیتون","روغن معروف مدیترانه"),("بادام","مغز مقوی"),("پسته","خندان کرمان و رفسنجان"),("فندق","مغز گرد کوچک"),("گردو","شبیه مغز انسان"),("تمشک","قرمز جنگلی"),("توت","سفید و سیاه شیرین"),("کشمش","انگور خشک‌شده"),("لیموترش","سبز و ترش"),("سنجد","میوهٔ سفرهٔ هفت‌سین"),("عناب","میوهٔ دارویی قرمز"),("بستنی","دسر سرد تابستانی"),("فالوده","دسر یخی شیرازی"),("حلوا","شیرینی آرد و شکر"),("سمنو","هفت‌سین از جوانهٔ گندم"),("عسل","شیرین طبیعی زنبور"),("دوغ","نوشیدنی ماست و نعنا")],
"شهرهای ایران 🕌": [("مشهد","شهر امام رضا (ع)"),("اصفهان","نصف جهان"),("شیراز","شهر شعر و گل"),("تبریز","شهر اولین‌ها"),("قم","شهر مذهبی مرکزی"),("کرج","همسایهٔ تهران در البرز"),("اهواز","کلان‌شهر گرم جنوب"),("کرمان","مرکز بزرگ‌ترین استان"),("یزد","شهر بادگیرها"),("رشت","شهر باران و غذا"),("ارومیه","مرکز آذربایجان غربی"),("اردبیل","شهر شیخ صفی"),("زنجان","شهر چاقو و ملیله"),("سنندج","مرکز کردستان"),("کرمانشاه","شهر طاق‌بستان"),("ایلام","عروس زاگرس"),("یاسوج","پایتخت طبیعت ایران"),("بوشهر","بندر خلیج فارس"),("بندرعباس","بزرگ‌ترین بندر ایران"),("زاهدان","مرکز سیستان و بلوچستان"),("بیرجند","مرکز خراسان جنوبی"),("بجنورد","مرکز خراسان شمالی"),("ساری","مرکز مازندران"),("گرگان","مرکز گلستان"),("آمل","شهر مازندران کنار هراز"),("بابل","شهر بهارنارنج"),("قزوین","پایتخت خوشنویسی"),("همدان","شهر بوعلی‌سینا"),("اراک","مرکز استان مرکزی"),("سمنان","شهر کویری مرکزی"),("کاشان","شهر گلاب و سهراب سپهری"),("آبادان","شهر نفتی خوزستان"),("دزفول","شهر تاریخی خوزستان"),("مسجدسلیمان","شهر اولین چاه نفت ایران"),("بروجرد","شهر لرستان"),("ملایر","شهر انگور و مبل"),("نیشابور","شهر خیام و عطار"),("سبزوار","شهر خراسان رضوی"),("گنبدکاووس","شهر برج قابوس"),("جیرفت","تمدن کهن کرمان"),("بم","شهر ارگ تاریخی"),("رفسنجان","پایتخت پستهٔ جهان"),("سیرجان","شهر گلیم کرمان"),("لار","شهر استان فارس"),("جهرم","شهر نخل فارس"),("فسا","شهر استان فارس"),("مرودشت","کنار تخت‌جمشید"),("کازرون","شهر شاپور ساسانی"),("شاهرود","شهر بسطام و بایزید")],
"کشورها 🌎": [("ایران","کشور ما"),("ترکیه","همسایهٔ غربی ایران"),("عراق","همسایهٔ غربی با بغداد"),("افغانستان","همسایهٔ شرقی ایران"),("پاکستان","همسایهٔ جنوب شرقی"),("چین","پرجمعیت‌ترین کشور آسیا"),("ژاپن","سرزمین آفتاب تابان"),("روسیه","پهناورترین کشور جهان"),("آلمان","کشور اروپایی با پایتخت برلین"),("فرانسه","کشور برج ایفل"),("ایتالیا","کشور چکمه‌ای اروپا"),("اسپانیا","کشور گاوبازی"),("پرتغال","کشور کریستیانو رونالدو"),("یونان","زادگاه المپیک"),("سوئد","کشور اسکاندیناوی"),("نروژ","کشور فیوردها"),("فنلاند","سرزمین هزار دریاچه"),("دانمارک","کشور وایکینگ‌ها"),("هلند","کشور لاله و آسیاب بادی"),("بلژیک","کشور شکلات و وافل"),("اتریش","کشور موسیقی و وین"),("سوئیس","کشور ساعت و شکلات"),("لهستان","کشور اروپای شرقی"),("مجارستان","کشور بوداپست"),("اوکراین","کشور بزرگ اروپای شرقی"),("برزیل","کشور فوتبال و آمازون"),("آرژانتین","کشور مسی و تانگو"),("شیلی","کشور باریک آمریکای جنوبی"),("پرو","کشور ماچوپیچو"),("کوبا","جزیرهٔ کارائیب"),("مکزیک","کشور تاکو"),("کانادا","همسایهٔ شمالی آمریکا"),("استرالیا","کشور کانگورو"),("مصر","کشور اهرام"),("لیبی","کشور شمال آفریقا"),("تونس","کشور شمال آفریقا"),("الجزایر","بزرگ‌ترین کشور آفریقا"),("مراکش","کشور شمال غربی آفریقا"),("سودان","کشور رود نیل"),("کنیا","کشور سافاری"),("اتیوپی","کشور قهوه"),("نیجریه","پرجمعیت‌ترین کشور آفریقا"),("عربستان","کشور مکه و مدینه"),("قطر","کشور گاز و جام جهانی ۲۰۲۲"),("عمان","کشور ساحلی عربی"),("یمن","کشور جنوبی عربستان"),("سوریه","کشور دمشق"),("لبنان","کشور بیروت"),("اردن","کشور پترا"),("کویت","کشور نفتی خلیج فارس"),("بحرین","جزیرهٔ خلیج فارس"),("امارات","کشور دبی و برج خلیفه"),("تایلند","کشور بانکوک"),("ویتنام","کشور جنوب شرق آسیا"),("مالزی","کشور کوالالامپور"),("اندونزی","بزرگ‌ترین کشور جزیره‌ای"),("فیلیپین","کشور هزار جزیره"),("مغولستان","کشور چنگیزخان"),("نپال","کشور قلهٔ اورست"),("بنگلادش","کشور داکا"),("قزاقستان","بزرگ‌ترین کشور محصور در خشکی"),("ازبکستان","کشور سمرقند و بخارا"),("تاجیکستان","کشور فارسی‌زبان همسایه"),("قرقیزستان","کشور کوهستانی آسیای مرکزی"),("ترکمنستان","کشور عشق‌آباد"),("آذربایجان","کشور باکو"),("ارمنستان","کشور ایروان"),("گرجستان","کشور تفلیس"),("هندوستان","کشور تاج‌محل"),("انگلیس","کشور لندن و بیگ‌بن")],
"غذاها 🍔": [("کباب","غذای محبوب ایرانی"),("پلو","برنج دم‌کرده"),("چلو","برنج سفید ساده"),("خورش","همراه همیشگی پلو"),("فسنجان","خورش گردو و رب انار"),("قیمه","خورش لپه و سیب‌زمینی"),("آش","غذای سنتی رشته‌دار"),("سوپ","پیش‌غذای گرم"),("سالاد","ترکیب سبزیجات تازه"),("پیتزا","غذای ایتالیایی محبوب"),("ساندویچ","غذای سریع دستی"),("همبرگر","غذای معروف فست‌فود"),("ماکارونی","رشته‌های ایتالیایی"),("اسپاگتی","ماکارونی باریک بلند"),("لازانیا","ورقه‌ای و پنیری"),("دلمه","برگ مو یا فلفل پرشده"),("کوفته","گلولهٔ گوشتی در سس"),("کتلت","گوشت سرخ‌شدهٔ تخت"),("شامی","غذای سنتی شمالی"),("آبگوشت","غذای دیزی سنگی"),("دیزی","آبگوشت در ظرف مخصوص"),("میرزاقاسمی","غذای بادمجان شمالی"),("استانبولی","پلو گوجه‌ای"),("الویه","سالاد سیب‌زمینی روسی"),("فرنی","دسر آرد برنج و شیر"),("کاچی","دسر مقوی آردی"),("نان","همراه همهٔ غذاها"),("پنیر","همراه صبحانه"),("مربا","شیرینی میوه‌ای صبحانه"),("خامه","سفید و چرب صبحانه"),("ماست","لبنیات ترش مفید"),("ذرت","دانه‌های زرد بوداده"),("پفک","تنقلات پف‌کرده"),("چیپس","ورقه‌های سیب‌زمینی سرخ‌شده"),("آجیل","مخلوط مغزها"),("تخمه","تنقلات آفتابگردان"),("قارچ","خوراکی جنگلی بدون برگ"),("لوبیا","حبوبات مقوی"),("عدس","حبوبات ریز"),("نخود","حبوبات فلافل")],
"مشاغل 👨‍⚕️": [("پزشک","درمانگر بیماران"),("معلم","آموزگار مدرسه"),("مهندس","سازنده و طراح"),("وکیل","مدافع در دادگاه"),("قاضی","حکم‌دهندهٔ دادگاه"),("نجار","سازندهٔ وسایل چوبی"),("بنا","سازندهٔ ساختمان"),("خیاط","دوزندهٔ لباس"),("آشپز","پزندهٔ غذا"),("نانوا","پزندهٔ نان"),("راننده","هدایت‌کنندهٔ ماشین"),("کشاورز","کاشتکار زمین"),("باغبان","نگهدار باغ"),("نقاش","هنرمند رنگ و بوم"),("خواننده","اجراکنندهٔ آواز"),("بازیگر","هنرمند سینما"),("نویسنده","خالق کتاب"),("شاعر","سرایندهٔ شعر"),("خبرنگار","گزارشگر اخبار"),("عکاس","ثبت‌کنندهٔ لحظه‌ها"),("خلبان","هدایت‌کنندهٔ هواپیما"),("ملوان","کارکنان کشتی"),("ماهیگیر","صیاد دریا"),("چوپان","نگهدار گله"),("قصاب","فروشندهٔ گوشت"),("آرایشگر","اصلاح‌کنندهٔ مو"),("فروشنده","کارکنان مغازه"),("حسابدار","مسئول حساب و کتاب"),("پرستار","مراقب بیماران"),("داروساز","مسئول داروخانه"),("دندانپزشک","پزشک دندان"),("جراح","پزشک عمل‌کننده"),("استاد","مدرس دانشگاه"),("کارگر","نیروی کار"),("مدیر","مسئول اداره"),("وزیر","عضو کابینه"),("سرباز","نیروی نظامی"),("نگهبان","محافظ ساختمان"),("رفتگر","پاکبان شهر"),("پستچی","رسانندهٔ نامه"),("افسر","درجه‌دار پلیس"),("غواص","شناگر زیر آب با کپسول"),("فضانورد","مسافر فضا")],
"ورزش‌ها ⚽": [("فوتبال","محبوب‌ترین ورزش جهان"),("فوتسال","فوتبال سالنی"),("والیبال","ورزش تور و توپ"),("بسکتبال","ورزش حلقه و توپ"),("هندبال","توپ با دست و دروازه"),("شنا","ورزش آبی"),("شیرجه","پرش به آب"),("قایقرانی","پارو زدن روی آب"),("کشتی","ورزش پهلوانی ایران"),("بوکس","مشت‌زنی"),("جودو","هنر رزمی ژاپنی"),("کاراته","هنر رزمی با دست خالی"),("تکواندو","هنر رزمی کره‌ای"),("ووشو","هنر رزمی چینی"),("تنیس","راکت و توپ سبز"),("بدمینتون","راکت و توپ پردار"),("اسکواش","راکت در اتاق بسته"),("گلف","توپ و چاله در چمن"),("اسکی","سر خوردن روی برف"),("اسکیت","کفش چرخ‌دار"),("شطرنج","نبرد ذهنی شاه و وزیر"),("دومیدانی","مادر ورزش‌ها"),("تیراندازی","نشانه‌گیری با تفنگ"),("شمشیربازی","نبرد با شمشیر"),("ژیمناستیک","حرکات نمایشی بدن"),("بدنسازی","ساختن عضله"),("کوهنوردی","صعود به قله‌ها"),("بیلیارد","توپ و میز سبز"),("بولینگ","توپ سنگین و پین‌ها"),("دارت","پرتاب تیر کوچک")],
"طبیعت و زندگی 🌈": [("خورشید","ستارهٔ منظومهٔ ما"),("ماه","قمر زمین"),("ستاره","نور آسمان شب"),("آسمان","بالای سر ما"),("ابر","بخار آب آسمان"),("باران","هدیهٔ آسمان"),("برف","سفید زمستانی"),("تگرگ","دانه‌های یخ آسمان"),("باد","هوای در حرکت"),("طوفان","باد و باران شدید"),("رعد","صدای آسمان"),("برق","نور ناگهانی آسمان"),("دریا","آب پهناور شور"),("اقیانوس","بزرگ‌ترین آب جهان"),("رودخانه","آب جاری شیرین"),("دریاچه","آب محصور در خشکی"),("آبشار","ریزش آب از بلندی"),("کوه","بلندی زمین"),("دره","میان دو کوه"),("غار","حفره در کوه"),("جنگل","انبوه درختان"),("درخت","سبز بلند"),("گل","زیبایی باغچه"),("برگ","سبزی درخت"),("چمن","فرش سبز زمین"),("صحرا","بیابان شن"),("جزیره","خشکی میان آب"),("ساحل","کنار دریا"),("آتش","گرما و نور"),("خاک","بستر گیاهان"),("سنگ","سخت کوه"),("شن","دانه‌های ساحل"),("بهار","فصل شکوفه"),("تابستان","فصل گرما"),("پاییز","فصل برگ‌ریزان"),("زمستان","فصل سرما و برف"),("کتاب","یار مهربان"),("دفتر","نوشتن مشق"),("مداد","نوشتن و پاک‌کردن"),("خودکار","ابزار نوشتن"),("کیف","حمل وسایل"),("کفش","پوشش پا"),("پیراهن","پوشش بالاتنه"),("شلوار","پوشش پا"),("کلاه","پوشش سر"),("عینک","کمک چشم"),("ساعت","نشان‌دهندهٔ زمان"),("تلفن","وسیلهٔ تماس"),("رایانه","ماشین هوشمند"),("تلویزیون","جعبهٔ تصاویر"),("رادیو","جعبهٔ صدا"),("دوربین","ثبت عکس"),("آینه","نمایش خودت"),("کلید","بازکنندهٔ قفل"),("قفل","نگهبان در"),("چراغ","روشنایی خانه"),("شمع","نور رمانتیک"),("میز","سطح کار"),("صندلی","نشستن"),("تخت","جای خواب"),("فرش","پوشش کف خانه"),("پرده","پوشش پنجره"),("قرمز","رنگ خون و گل سرخ"),("آبی","رنگ آسمان و دریا"),("سبز","رنگ طبیعت"),("زرد","رنگ خورشید"),("نارنجی","رنگ پرتقال"),("بنفش","رنگ گل بنفشه"),("صورتی","رنگ لطیف"),("سفید","رنگ برف و پاکی"),("سیاه","رنگ شب"),("طلایی","رنگ طلا"),("خاکستری","میان سفید و سیاه")],
}
GAME_FLAT = []
_seen_words = set()
for _cat, _ws in GAME_BANK.items():
    for _w, _h in _ws:
        if _w not in _seen_words:
            _seen_words.add(_w)
            GAME_FLAT.append((_w, _cat, _h))

def _game_norm(s):
    s = (s or "").strip().lower()
    for a, b in (("ي", "ی"), ("ك", "ک"), ("‌", ""), (" ", ""), ("ـ", ""), ("ة", "ه"), ("ؤ", "و"), ("أ", "ا"), ("إ", "ا")):
        s = s.replace(a, b)
    return s


def make_bots(Fail, common, log):
    now = common.now
    NOTSET = object()

    class BotsMixin:
        # ================================================================== setup
        def _bots_init(self):
            self.bot_cv = threading.Condition()
            self._cq = {}                       # callback_query id -> who pressed what (answer must come within 2 min)
            self._cq_lock = threading.Lock()
            self._bot_touch = {}
            self.botfather_id = None
            self.ai_bot_id = None

        def _ensure_botfather(self, db):
            row = db.execute("SELECT id, is_bot FROM users WHERE username='BotFather' COLLATE NOCASE").fetchone()
            if row is not None and not row["is_bot"]:      # a normal user took the name before bots existed
                with db:
                    db.execute("UPDATE users SET username=? WHERE id=?", (f"BotFather_user{row['id']}", row["id"]))
                log("renamed an old normal account called BotFather")
                row = None
            if row is None:
                ps, ph = common.hash_secret(secrets.token_urlsafe(24))
                ss, sh = common.hash_secret(secrets.token_urlsafe(24))
                with db:
                    cur = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                        " created_at, is_bot) VALUES ('BotFather','BotFather','ساخت و مدیریت ربات',?,?,'-',?,?,?,1)",
                        (ps, ph, ss, sh, now()))
                uid = cur.lastrowid
            else:
                uid = row["id"]
            with db:
                db.execute("INSERT OR IGNORE INTO bots(user_id, owner_id, official, description, commands, created_at) "
                           "VALUES (?,NULL,1,?,?,?)",
                           (uid, "ربات رسمی برای ساخت و مدیریت ربات‌ها", json.dumps(
                               [{"command": c, "description": d} for c, d in BF_COMMANDS], ensure_ascii=False), now()))
            self.botfather_id = uid
            return uid

        def _ensure_ai_bot(self, db):
            """The official DarkGram AI assistant: an ordinary bot user, gold tick, answers in-process."""
            row = db.execute("SELECT id, is_bot FROM users WHERE username='DarkGramAI' COLLATE NOCASE").fetchone()
            if row is not None and not row["is_bot"]:      # a normal user took the name first
                with db:
                    db.execute("UPDATE users SET username=? WHERE id=?", (f"DarkGramAI_user{row['id']}", row["id"]))
                log("renamed an old normal account called DarkGramAI")
                row = None
            if row is None:
                ps, ph = common.hash_secret(secrets.token_urlsafe(24))
                ss, sh = common.hash_secret(secrets.token_urlsafe(24))
                with db:
                    cur = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                        " created_at, is_bot, badge) VALUES ('DarkGramAI','هوش مصنوعی دارک گرام','ربات رسمی هوش مصنوعی دارک گرام 🤖',?,?,'-',?,?,?,1,2)",
                        (ps, ph, ss, sh, now()))
                uid = cur.lastrowid
            else:
                uid = row["id"]
                with db:                                   # keep the official identity in sync
                    db.execute("UPDATE users SET badge=2, premium=1, display_name='هوش مصنوعی دارک گرام',"
                               " bio='ربات رسمی هوش مصنوعی دارک گرام 🤖' WHERE id=?", (uid,))
            with db:
                db.execute("INSERT OR IGNORE INTO bots(user_id, owner_id, official, description, commands, created_at) "
                           "VALUES (?,NULL,1,?,?,?)",
                           (uid, "دستیار هوشمند رسمی دارک گرام؛ بپرس، برات حساب می‌کنم، راهنماییت می‌کنم و سرگرمت می‌کنم ✨",
                            json.dumps([{"command": c, "description": d} for c, d in AI_COMMANDS], ensure_ascii=False), now()))
                db.execute("UPDATE bots SET official=1 WHERE user_id=?", (uid,))
            self.ai_bot_id = uid
            return uid

        def _ensure_sticker_bot(self, db):
            """The official DarkGram sticker maker (@DarkStickers): send it a photo, get a personal sticker."""
            row = db.execute("SELECT id, is_bot FROM users WHERE username='DarkStickers' COLLATE NOCASE").fetchone()
            if row is not None and not row["is_bot"]:
                with db:
                    db.execute("UPDATE users SET username=? WHERE id=?", (f"DarkStickers_user{row['id']}", row["id"]))
                row = None
            if row is None:
                ps, ph = common.hash_secret(secrets.token_urlsafe(24))
                ss, sh = common.hash_secret(secrets.token_urlsafe(24))
                with db:
                    cur = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                        " created_at, is_bot, badge) VALUES ('DarkStickers','استیکر ساز دارک گرام','ربات رسمی ساخت استیکر دارک گرام 🧩',?,?,'-',?,?,?,1,2)",
                        (ps, ph, ss, sh, now()))
                uid = cur.lastrowid
            else:
                uid = row["id"]
                with db:
                    db.execute("UPDATE users SET badge=2, premium=1, display_name='استیکر ساز دارک گرام',"
                               " bio='ربات رسمی ساخت استیکر دارک گرام 🧩' WHERE id=?", (uid,))
            cmds = [{"command": "start", "description": "شروع و راهنما"}, {"command": "mypack", "description": "پک استیکر من"}]
            with db:
                db.execute("INSERT OR IGNORE INTO bots(user_id, owner_id, official, description, commands, created_at) "
                           "VALUES (?,NULL,1,?,?,?)",
                           (uid, "ربات رسمی ساخت استیکر: یه عکس بفرست، استیکرش می‌کنم 🧩", json.dumps(cmds, ensure_ascii=False), now()))
                db.execute("UPDATE bots SET official=1 WHERE user_id=?", (uid,))
            self.stickers_bot_id = uid
            return uid

        def _ensure_spam_bot(self, db):
            """The official anti-spam bot (@Spam, cloned from Telegram's Spam Info Bot):
            tells a user whether their account is limited/banned and takes appeals."""
            row = db.execute("SELECT id, is_bot FROM users WHERE username='Spam' COLLATE NOCASE").fetchone()
            if row is not None and not row["is_bot"]:
                with db:
                    db.execute("UPDATE users SET username=? WHERE id=?", (f"Spam_user{row['id']}", row["id"]))
                row = None
            if row is None:
                ps, ph = common.hash_secret(secrets.token_urlsafe(24))
                ss, sh = common.hash_secret(secrets.token_urlsafe(24))
                with db:
                    cur = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                        " created_at, is_bot, badge) VALUES ('Spam','Spam Info Bot','ربات رسمی ضداسپم دارک گرام 🛡',?,?,'-',?,?,?,1,2)",
                        (ps, ph, ss, sh, now()))
                uid = cur.lastrowid
            else:
                uid = row["id"]
                with db:
                    db.execute("UPDATE users SET badge=2, premium=1, display_name='Spam Info Bot',"
                               " bio='ربات رسمی ضداسپم دارک گرام 🛡' WHERE id=?", (uid,))
            cmds = [{"command": "start", "description": "بررسی وضعیت حساب"}]
            with db:
                db.execute("INSERT OR IGNORE INTO bots(user_id, owner_id, official, description, commands, created_at) "
                           "VALUES (?,NULL,1,?,?,?)",
                           (uid, "ربات رسمی ضداسپم: وضعیت محدودیت حسابت رو نشون می‌ده 🛡", json.dumps(cmds, ensure_ascii=False), now()))
                db.execute("UPDATE bots SET official=1 WHERE user_id=?", (uid,))
            u = db.execute("SELECT avatar_at FROM users WHERE id=?", (uid,)).fetchone()
            if u and not u["avatar_at"]:
                try:
                    from pathlib import Path
                    p = Path(__file__).with_name("web") / "spambot.png"
                    if p.exists():
                        self.set_user_avatar(db, uid, p.read_bytes())
                except Exception as e:
                    log("spam bot avatar failed:", repr(e))
            self.spam_bot_id = uid
            return uid
        # ================================================================== @game: word-guessing fun bot (blue tick, NOT official)
        def _ensure_game_bot(self, db):
            """The entertainment bot (@game): a word-guessing game. Blue tick (badge 1), not official."""
            row = db.execute("SELECT id, is_bot FROM users WHERE username='game' COLLATE NOCASE").fetchone()
            if row is not None and not row["is_bot"]:
                with db:
                    db.execute("UPDATE users SET username=? WHERE id=?", (f"game_user{row['id']}", row["id"]))
                row = None
            if row is None:
                ps, ph = common.hash_secret(secrets.token_urlsafe(24))
                ss, sh = common.hash_secret(secrets.token_urlsafe(24))
                with db:
                    cur = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                        " created_at, is_bot, badge) VALUES ('game','بازی کلمات 🎮','ربات سرگرمی حدس کلمه 🎮 هر ۵ ثانیه یه حرف لو می‌دم؛ حدس بزن و امتیاز ببر!',?,?,'-',?,?,?,1,1)",
                        (ps, ph, ss, sh, now()))
                uid = cur.lastrowid
            else:
                uid = row["id"]
                with db:
                    db.execute("UPDATE users SET badge=1, display_name='بازی کلمات 🎮',"
                               " bio='ربات سرگرمی حدس کلمه 🎮 هر ۵ ثانیه یه حرف لو می‌دم؛ حدس بزن و امتیاز ببر!' WHERE id=?", (uid,))
            cmds = [{"command": "start", "description": "شروع بازی"}, {"command": "score", "description": "امتیاز من"},
                    {"command": "top", "description": "برترین‌ها"}, {"command": "stop", "description": "پایان بازی"}]
            with db:
                db.execute("INSERT OR IGNORE INTO bots(user_id, owner_id, official, description, commands, created_at) "
                           "VALUES (?,NULL,0,?,?,?)",
                           (uid, "بازی حدس کلمه 🎮 هر ۵ ثانیه یه حرف لو می‌ره؛ زودتر حدس بزنی امتیازت بیشتره!", json.dumps(cmds, ensure_ascii=False), now()))
                db.execute("UPDATE bots SET official=0 WHERE user_id=?", (uid,))
            u = db.execute("SELECT avatar_at FROM users WHERE id=?", (uid,)).fetchone()
            if u and not u["avatar_at"]:
                try:
                    from pathlib import Path
                    p = Path(__file__).with_name("web") / "gamebot.png"
                    if p.exists():
                        self.set_user_avatar(db, uid, p.read_bytes())
                except Exception as e:
                    log("game bot avatar failed:", repr(e))
            self.game_bot_id = uid
            return uid

        def _games_map(self):
            g = getattr(self, "_games", None)
            if g is None:
                g = self._games = {}
            return g

        def _game_score(self, db, uid):
            r = db.execute("SELECT points, wins FROM game_scores WHERE user_id=?", (uid,)).fetchone()
            return (r["points"], r["wins"]) if r else (0, 0)

        def _game_level(self, wins):
            return wins // 3 + 1

        def _game_pick(self, st):
            lv = st["level"]
            if lv <= 2:
                pool = [w for w in GAME_FLAT if len(w[0]) <= 5]
            elif lv <= 5:
                pool = [w for w in GAME_FLAT if 4 <= len(w[0]) <= 7]
            else:
                pool = [w for w in GAME_FLAT if len(w[0]) >= 6]
            if not pool:
                pool = GAME_FLAT
            deck = [w for w in pool if w[0] not in st["seen"]]
            if not deck:
                st["seen"] = set()
                deck = pool
            pick = random.choice(deck)
            st["seen"].add(pick[0])
            return pick

        def _game_pattern(self, st):
            w = st["word"]
            return " ".join(w[i] if i < st["revealed"] else "•" for i in range(len(w)))

        def _game_start_round(self, db, chat_id, st):
            w, cat, hint = self._game_pick(st)
            st.update(word=w, cat=cat, hint=hint, revealed=0, over=False)
            self._bot_send(db, self.game_bot_id, chat_id,
                           f"🎮 مرحلهٔ {st['level']} — یه کلمهٔ {len(w)} حرفی از دستهٔ «{cat}»\n"
                           f"💡 راهنما: {hint}\n"
                           f"🔤 {self._game_pattern(st)}\n"
                           "هر ۵ ثانیه یه حرفش لو می‌ره؛ زودتر حدس بزنی، امتیازت بیشتره! 🏃‍♂️💨",
                           markup=[[self._btn("🛑 پایان بازی", "gstop")],
                                   [self._btn("⭐ امتیاز من", "gme"), self._btn("👑 برترین‌ها", "gtop")]])

        def _game_loop(self, chat_id, gen):
            db = None
            try:
                db = common.connect_db(self.db_path)
                while True:
                    st = self._games_map().get(chat_id)
                    if not st or not st["active"] or st["gen"] != gen:
                        return
                    while st["revealed"] < len(st["word"]) and not st["over"]:
                        time.sleep(5)
                        if self._games_map().get(chat_id) is not st or not st["active"] or st["gen"] != gen:
                            return
                        if st["over"]:
                            break
                        st["revealed"] += 1
                        ch = st["word"][st["revealed"] - 1]
                        self._bot_send(db, self.game_bot_id, chat_id,
                                       f"🔤 حرف {st['revealed']} از {len(st['word'])}: «{ch}»\n🔤 {self._game_pattern(st)}")
                    if not st["active"] or st["gen"] != gen:
                        return
                    if not st["over"]:
                        st["over"] = True
                        self._bot_send(db, self.game_bot_id, chat_id,
                                       f"⏰ وقت تموم شد! کلمه «{st['word']}» بود 😅\nاشکالی نداره، بعدی رو بترکون 💪")
                    time.sleep(4)
                    if self._games_map().get(chat_id) is not st or not st["active"] or st["gen"] != gen:
                        return
                    self._game_start_round(db, chat_id, st)
            except Exception as e:
                log("game loop failed:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _game_begin(self, db, chat_id, uid):
            games = self._games_map()
            st = games.get(chat_id)
            if st and st["active"]:
                self._bot_send(db, self.game_bot_id, chat_id, "🎮 بازی در جریانه! کلمه رو حدس بزن 😉")
                return
            pts, wins = self._game_score(db, uid)
            gen = (st["gen"] + 1) if st else 1
            st = {"active": True, "gen": gen, "level": self._game_level(wins), "seen": set(),
                  "word": "", "cat": "", "hint": "", "revealed": 0, "over": True}
            games[chat_id] = st
            self._bot_send(db, self.game_bot_id, chat_id,
                           "🎉 بازی حدس کلمه شروع شد!\n"
                           "من یه کلمه انتخاب می‌کنم و هر ۵ ثانیه یه حرفش رو لو می‌دم؛ تو فقط کلمه رو بنویس و بفرست، درست باشه امتیاز می‌گیری ⭐\n"
                           f"امتیاز فعلی تو: {pts} ⭐ • مرحلهٔ {st['level']}")
            self._game_start_round(db, chat_id, st)
            threading.Thread(target=self._game_loop, args=(chat_id, gen), daemon=True).start()

        def _game_stop(self, db, chat_id, uid):
            st = self._games_map().get(chat_id)
            if st:
                st["active"] = False
                st["gen"] += 1
            pts, wins = self._game_score(db, uid)
            self._bot_send(db, self.game_bot_id, chat_id,
                           f"🛑 بازی تموم شد! دمت گرم 🙌\n⭐ امتیازت: {pts} • 🏆 بردها: {wins} • مرحله: {self._game_level(wins)}\n"
                           "هر وقت خواستی دوباره بازی کنی، دکمهٔ زیر رو بزن 👇",
                           markup=[[self._btn("▶️ شروع بازی", "gstart")]])

        def _game_send_score(self, db, chat_id, uid):
            pts, wins = self._game_score(db, uid)
            rank = db.execute("SELECT COUNT(*) AS c FROM game_scores WHERE points > ?", (pts,)).fetchone()["c"] + 1
            self._bot_send(db, self.game_bot_id, chat_id,
                           f"⭐ امتیاز تو: {pts}\n🏆 بردها: {wins} • مرحله: {self._game_level(wins)}\n"
                           f"📊 رتبه‌ات بین بازیکن‌ها: {rank}\nهرچی زودتر حدس بزنی، امتیازت بیشتره!")

        def _game_send_top(self, db, chat_id):
            rows = db.execute("SELECT u.display_name AS name, g.points AS points, g.wins AS wins FROM game_scores g "
                              "JOIN users u ON u.id=g.user_id ORDER BY g.points DESC LIMIT 10").fetchall()
            lines = ["👑 برترین‌های حدس کلمه:"]
            medals = ["🥇", "🥈", "🥉"]
            for i, r in enumerate(rows):
                lines.append(f"{medals[i] if i < 3 else str(i + 1) + '.'} {r['name']} — {r['points']} ⭐ ({r['wins']} برد)")
            if not rows:
                lines.append("هنوز کسی امتیاز نگرفته؛ اولین نفر باش! 🚀")
            self._bot_send(db, self.game_bot_id, chat_id, "\n".join(lines))

        def _game_send_help(self, db, chat_id):
            self._bot_send(db, self.game_bot_id, chat_id,
                           "🎮 راهنمای بازی حدس کلمه:\n"
                           "۱. «شروع» رو بزن؛ یه کلمه از یه دسته (پایتخت، حیوان، میوه، شهر، کشور، غذا، شغل، ورزش…) انتخاب می‌شه و راهنماش رو می‌بینی.\n"
                           "۲. هر ۵ ثانیه یه حرف از کلمه لو می‌ره.\n"
                           "۳. کلمه رو که حدس زدی، فقط بنویس و بفرست؛ درست باشه امتیاز می‌گیری — هرچی حرف کمتری لو رفته باشه، امتیازت بیشتره ⭐\n"
                           "۴. هر ۳ برد، یه مرحله می‌ری بالاتر و کلمه‌ها سخت‌تر می‌شن 🔥\n"
                           "دستورها: شروع • امتیاز • برترین‌ها • پایان",
                           markup=[[self._btn("▶️ شروع بازی", "gstart")]])

        def _game_thread(self, chat_id, msg):
            db = None
            try:
                time.sleep(0.15)
                self.push([msg["sender_id"]], {"event": "typing", "chat_id": chat_id,
                                               "user_id": self.game_bot_id, "action": "text"})
                db = common.connect_db(self.db_path)
                self._game_handle(db, chat_id, msg)
            except Exception as e:
                log("game bot failed:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _game_handle(self, db, chat_id, msg):
            uid = msg["sender_id"]
            text = (msg.get("body") or "").strip()
            n = _game_norm(text)
            st = self._games_map().get(chat_id)
            playing = bool(st and st["active"] and not st["over"])
            if n in ("start", "/start", "شروع", "شروع بازی", "بازی", "بازی جدید", "استارت"):
                self._game_begin(db, chat_id, uid)
                return
            if n in ("/stop", "پایان", "پایان بازی", "توقف", "بسه", "stop"):
                self._game_stop(db, chat_id, uid)
                return
            if n in ("امتیاز", "امتیاز من", "امتیازم", "/score", "score"):
                self._game_send_score(db, chat_id, uid)
                return
            if n in ("برترین ها", "برترینها", "جدول", "جدول امتیازها", "/top", "top"):
                self._game_send_top(db, chat_id)
                return
            if n in ("راهنما", "کمک", "/help", "help"):
                self._game_send_help(db, chat_id)
                return
            if playing and n and n == _game_norm(st["word"]):
                left = len(st["word"]) - st["revealed"]
                gain = 30 + left * 10
                st["over"] = True
                with db:
                    db.execute("INSERT INTO game_scores(user_id, points, wins, updated_at) VALUES (?,?,1,?) "
                               "ON CONFLICT(user_id) DO UPDATE SET points=points+?, wins=wins+1, updated_at=?",
                               (uid, gain, now(), gain, now()))
                pts, wins = self._game_score(db, uid)
                newlv = self._game_level(wins)
                lvmsg = f"\n🎊 آفرین! رسیدی به مرحلهٔ {newlv} 🔥" if newlv > st["level"] else ""
                st["level"] = newlv
                self._bot_send(db, self.game_bot_id, chat_id,
                               f"🎉🎉 درستههه! کلمه «{st['word']}» بود!\n"
                               f"⭐ +{gain} امتیاز گرفتی (مجموع: {pts}){lvmsg}\n⏭ کلمهٔ بعدی چند ثانیهٔ دیگه میاد…")
                return
            if not (st and st["active"]):
                self._bot_send(db, self.game_bot_id, chat_id,
                               "سلام! 👋 من ربات بازی حدس کلمه‌ام 🎮\n«شروع» رو بزن؛ هر ۵ ثانیه یه حرف لو می‌دم، کلمه رو حدس بزن و امتیاز ببر ⭐",
                               markup=[[self._btn("▶️ شروع بازی", "gstart")],
                                       [self._btn("⭐ امتیاز من", "gme"), self._btn("👑 برترین‌ها", "gtop")],
                                       [self._btn("ℹ️ راهنما", "ghelp")]])

        def _game_callback(self, db, uid, row, data):
            chat_id = row["chat_id"]
            if data == "gstart":
                self._game_begin(db, chat_id, uid)
            elif data == "gstop":
                self._game_stop(db, chat_id, uid)
            elif data == "gme":
                self._game_send_score(db, chat_id, uid)
            elif data == "gtop":
                self._game_send_top(db, chat_id)
            elif data == "ghelp":
                self._game_send_help(db, chat_id)

        def _spam_thread(self, chat_id, msg):
            db = None
            try:
                time.sleep(0.15)
                self.push([msg["sender_id"]], {"event": "typing", "chat_id": chat_id,
                                               "user_id": self.spam_bot_id, "action": "text"})
                time.sleep(0.3)
                db = common.connect_db(self.db_path)
                self._spam_handle(db, chat_id, msg)
            except Exception as e:
                log("spam bot failed:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _spam_handle(self, db, chat_id, msg):
            uid = msg["sender_id"]
            u = db.execute("SELECT banned, restricted_until FROM users WHERE id=?", (uid,)).fetchone()
            t = now()
            appeal = [[self._btn("📩 درخواست بررسی (اشتباه شده)", "appeal")]]
            if u and u["banned"]:
                text = ("متأسفم! 😔\n\n"
                        "حساب شما در دارک گرام به‌طور کامل مسدود شده و دیگه نمی‌تونید از دارک گرام استفاده کنید.\n\n"
                        "اگه فکر می‌کنید این مسدودیت اشتباه اعمال شده، دکمهٔ زیر رو بزنید تا درخواست بررسی‌تون برای مدیریت ثبت بشه.")
                self._bot_send(db, self.spam_bot_id, chat_id, text, markup=appeal)
            elif u and (u["restricted_until"] or 0) > t:
                rem = max(1, -(-(u["restricted_until"] - t) // 60))
                text = ("متأسفم! 😔\n\n"
                        "متأسفانه بعضی از کاربرهای دارک گرام پیام‌های شما رو آزاردهنده دونستن و اون‌ها رو برای تیم نظارت ما فرستادن. "
                        "ناظرها گزارش‌ها رو بررسی و تأیید کردن، واسه همین حساب شما فعلاً محدود شده.\n\n"
                        f"⏱ زمان باقی‌مانده از محدودیت: حدود {rem} دقیقه\n\n"
                        "تا پایان محدودیت نمی‌تونید پیام بفرستید، اما همچنان می‌تونید پیام‌ها رو بخونید.\n\n"
                        "اگه فکر می‌کنید این محدودیت اشتباه اعمال شده، دکمهٔ زیر رو بزنید تا درخواست بررسی‌تون برای مدیریت ثبت بشه.")
                self._bot_send(db, self.spam_bot_id, chat_id, text, markup=appeal)
            else:
                text = ("خبر خوب! 🎉\n\n"
                        "در حال حاضر هیچ محدودیتی روی حساب شما اعمال نشده و مثل یه پرنده آزادید! 🕊\n\n"
                        "من ربات رسمی ضداسپم دارک گرامم 🛡 اگه روزی حسابتون محدود یا مسدود بشه، وضعیت و زمان پایانش رو همینجا می‌بینید.")
                self._bot_send(db, self.spam_bot_id, chat_id, text)

        def _spam_callback(self, db, uid, row, data):
            if data != "appeal":
                return
            with db:
                db.execute("INSERT INTO spam_appeals(user_id, created_at) VALUES (?,?)", (uid, now()))
            self._bot_send(db, self.spam_bot_id, row["chat_id"],
                           "📩 درخواست بررسی شما ثبت شد. مدیریت دارک گرام بررسیش می‌کنه؛ اگه اشتباهی شده باشه، محدودیت برداشته می‌شه.")

        def _stickers_thread(self, chat_id, msg):
            db = None
            try:
                time.sleep(0.15)
                self.push([msg["sender_id"]], {"event": "typing", "chat_id": chat_id,
                                               "user_id": self.stickers_bot_id, "action": "text"})
                time.sleep(0.3)
                db = common.connect_db(self.db_path)
                self._stickers_handle(db, chat_id, msg)
            except Exception as e:
                log("stickers bot error:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _stk_reply(self, db, chat_id, text):
            try:
                return self._bot_send(db, self.stickers_bot_id, chat_id, text)
            except Exception as e:
                log("stickers reply failed:", repr(e))
                return None

        def _stk_make(self, db, uid, raw):
            """Convert raw image bytes to a 512x512 webp sticker in the user's personal pack."""
            from PIL import Image
            import io
            if len(raw) > 25 * 1024 * 1024:
                raise Fail("حجم عکس خیلی زیاده")
            n = db.execute("SELECT COUNT(*) AS n FROM user_stickers WHERE user_id=?", (uid,)).fetchone()["n"]
            if n >= 200:
                raise Fail("پکت پر شده (حداکثر ۲۰۰ استیکر)")
            im = Image.open(io.BytesIO(raw))
            if getattr(im, "is_animated", False):
                im.seek(0)
            im = im.convert("RGBA")
            im.thumbnail((512, 512), Image.LANCZOS)
            canvas = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
            canvas.paste(im, ((512 - im.width) // 2, (512 - im.height) // 2), im)
            buf = io.BytesIO()
            canvas.save(buf, "WEBP", quality=90, method=4)
            with db:
                cur = db.execute("INSERT INTO user_stickers(user_id, file, created_at) VALUES (?, '', ?)", (uid, now()))
            sid = cur.lastrowid
            rel = f"ustk/{uid}/{sid}.webp"
            dest = common.UPLOADS_DIR / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(buf.getvalue())
            with db:
                db.execute("UPDATE user_stickers SET file=? WHERE id=?", (rel, sid))
            return sid

        def _stickers_handle(self, db, chat_id, msg):
            uid = msg["sender_id"]
            bot = self.stickers_bot_id
            row = db.execute("SELECT kind, file_path, meta FROM messages WHERE id=?", (msg["id"],)).fetchone()
            meta = {}
            if row is not None:
                try:
                    meta = json.loads(row["meta"] or "{}")
                except Exception:
                    meta = {}
            stk = meta.get("sticker")
            if isinstance(stk, str) and stk.startswith("cherry:"):
                num = stk.split(":", 1)[1]
                if num.isdigit() and 1 <= int(num) <= 23:
                    try:
                        raw = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", f"ch{int(num)}.webp"), "rb").read()
                        sid = self._stk_make(db, uid, raw)
                        self._bot_send(db, bot, chat_id, f"user:{sid}", extra_meta={"sticker": f"user:{sid}"})
                        n = db.execute("SELECT COUNT(*) AS n FROM user_stickers WHERE user_id=?", (uid,)).fetchone()["n"]
                        self._stk_reply(db, chat_id, f"✅ استیکر چری به پک شخصیت اضافه شد! حالا {n} تا استیکر داری 🧩")
                    except Fail as e:
                        self._stk_reply(db, chat_id, "❌ " + str(e))
                    except Exception as e:
                        log("stickers cherry copy failed:", repr(e))
                        self._stk_reply(db, chat_id, "❌ نشد این استیکر رو اضافه کنم؛ دوباره تلاش کن")
                    return
            if row is not None and row["kind"] == "file" and row["file_path"]:
                fmeta = meta.get("file") or {}
                fname = str(fmeta.get("name") or row["file_path"]).lower()
                if fmeta.get("kind") == "image" or fname.rsplit(".", 1)[-1] in ("png", "jpg", "jpeg", "webp", "gif"):
                    p = common.resolve_upload(row["file_path"])
                    if p is not None:
                        try:
                            sid = self._stk_make(db, uid, p.read_bytes())
                            self._bot_send(db, bot, chat_id, f"user:{sid}", extra_meta={"sticker": f"user:{sid}"})
                            n = db.execute("SELECT COUNT(*) AS n FROM user_stickers WHERE user_id=?", (uid,)).fetchone()["n"]
                            self._stk_reply(db, chat_id, f"✅ استیکرت ساخته و به پک شخصیت اضافه شد! حالا {n} تا استیکر داری 🧩\nاز پنل ایموجی، تب «🧩 استیکر من» می‌تونی توی هر چتی بفرستیش.")
                        except Fail as e:
                            self._stk_reply(db, chat_id, "❌ " + str(e))
                        except Exception as e:
                            log("stickers make failed:", repr(e))
                            self._stk_reply(db, chat_id, "❌ این عکس رو نتونستم به استیکر تبدیل کنم؛ یه عکس دیگه بفرست 📸")
                        return
                self._stk_reply(db, chat_id, "این فایل عکس نیست 📸 یه عکس (PNG یا JPG یا WebP) بفرست تا استیکرش کنم.")
                return
            t = (msg.get("body") or "").strip()
            n = db.execute("SELECT COUNT(*) AS n FROM user_stickers WHERE user_id=?", (uid,)).fetchone()["n"]
            if t in ("/mypack", "پک من", "پکم"):
                self._stk_reply(db, chat_id, f"🧩 الان {n} تا استیکر شخصی داری.\nاز پنل ایموجی، تب «🧩 استیکر من» توی هر چتی در دسترسن. برای ساخت جدید فقط یه عکس بفرست 📸")
            else:
                self._stk_reply(db, chat_id, "سلام! 🧩 من ربات رسمی ساخت استیکر دارک گرامم.\n\n📸 فقط کافیه یه عکس برام بفرستی؛ خودم به استیکر تبدیلش می‌کنم و به پک شخصیت اضافه می‌کنم.\n🍒 اگه یه استیکر چری هم برام بفرستی، اونم به پکت اضافه می‌کنم.\n\nاستیکرهات رو از پنل ایموجی، تب «🧩 استیکر من» می‌تونی توی هر چتی بفرستی.")

        # ================================================================== helpers
        def _bot_info(self, db, uid):
            b = db.execute("SELECT description, commands, official FROM bots WHERE user_id=?", (uid,)).fetchone()
            if not b:
                return {"description": "", "commands": [], "official": False}
            try:
                cmds = json.loads(b["commands"] or "[]")
            except ValueError:
                cmds = []
            return {"description": b["description"], "commands": cmds, "official": bool(b["official"])}

        @staticmethod
        def _bot_user_json(u):
            return {"id": u["id"], "is_bot": bool(u["is_bot"]), "username": u["username"], "first_name": u["display_name"]}

        def _bot_chat_json(self, db, chat_id, for_bot=None):
            c = db.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
            if not c:
                return {"id": chat_id, "type": "private"}
            d = {"id": c["id"], "type": "private" if c["kind"] == "private" else "group", "title": c["title"]}
            if c["kind"] == "private" and for_bot:
                o = db.execute("SELECT u.username, u.display_name FROM members m JOIN users u ON u.id=m.user_id "
                               "WHERE m.chat_id=? AND m.user_id!=?", (chat_id, for_bot)).fetchone()
                if o:
                    d["username"], d["first_name"] = o["username"], o["display_name"]
            elif c["username"]:
                d["username"] = c["username"]
            return d

        def _bot_msg_json(self, db, msg, for_bot=None):
            """A message as a bot sees it (Telegram-like field names)."""
            u = db.execute("SELECT id, username, display_name, is_bot FROM users WHERE id=?", (msg["sender_id"],)).fetchone()
            d = {"message_id": msg["id"], "date": msg["created_at"], "chat": self._bot_chat_json(db, msg["chat_id"], for_bot),
                 "from": self._bot_user_json(u) if u else None, "text": msg.get("body") or ""}
            if msg.get("reply"):
                d["reply_to_message_id"] = msg["reply"]["id"]
            if msg.get("file"):
                f = msg["file"]
                d["file"] = {"name": f.get("name"), "size": f.get("size"), "kind": f.get("kind")}
                if f.get("voice"):
                    d["file"].update(voice=True, duration=f.get("dur"))
            if msg.get("markup"):
                d["reply_markup"] = {"inline_keyboard": msg["markup"]}
            return d

        @staticmethod
        def _bot_markup(raw):
            """Validate/normalise reply_markup -> list of rows, or None (= no buttons)."""
            if raw in (None, "", "null"):
                return None
            if isinstance(raw, str):
                try:
                    raw = json.loads(raw)
                except ValueError:
                    raise Fail("reply_markup باید JSON معتبر باشه")
            if not isinstance(raw, dict):
                raise Fail("reply_markup نامعتبره")
            kb = raw.get("inline_keyboard")
            if not kb:
                return None
            if not isinstance(kb, list) or len(kb) > MAX_KB_ROWS:
                raise Fail(f"حداکثر {MAX_KB_ROWS} ردیف دکمه")
            out, total = [], 0
            for row in kb:
                if not isinstance(row, list) or not row or len(row) > MAX_KB_COLS:
                    raise Fail(f"هر ردیف ۱ تا {MAX_KB_COLS} دکمه داشته باشه")
                r = []
                for b in row:
                    if not isinstance(b, dict):
                        raise Fail("دکمه نامعتبره")
                    text = _line(b.get("text"), 64)
                    if not text:
                        raise Fail("متن دکمه خالیه")
                    cb, url = b.get("callback_data"), b.get("url")
                    if cb is not None:
                        cb = str(cb)
                        if not 1 <= len(cb.encode("utf-8")) <= 64:
                            raise Fail("callback_data باید ۱ تا ۶۴ بایت باشه")
                        r.append({"text": text, "callback_data": cb})
                    elif url:
                        url = str(url).strip()
                        if not URL_RE.match(url):
                            raise Fail("آدرس دکمه باید با http:// یا https:// شروع بشه")
                        r.append({"text": text, "url": url})
                    else:
                        raise Fail("هر دکمه باید callback_data یا url داشته باشه")
                    total += 1
                out.append(r)
            if total > MAX_KB_TOTAL:
                raise Fail(f"حداکثر {MAX_KB_TOTAL} دکمه")
            return out

        def _bot_member(self, db, bot_uid, chat_id):
            try:
                chat_id = int(chat_id)
            except (TypeError, ValueError):
                raise Fail("chat_id نامعتبره")
            if not db.execute("SELECT 1 FROM members WHERE chat_id=? AND user_id=?", (chat_id, bot_uid)).fetchone():
                raise ApiError(403, "ربات عضو این چت نیست")
            return chat_id

        # ================================================================== sending as a bot
        def _bot_send(self, db, bot_uid, chat_id, text, reply_to=None, markup=None, secret=False,
                      fname=None, raw=None, extra_meta=None):
            chat_id = self._bot_member(db, bot_uid, chat_id)
            if bot_uid != self.botfather_id and not self._room_hits(("botsend", bot_uid), 40, 10):
                raise ApiError(429, "خیلی سریع پیام می‌فرستی؛ کمی صبر کن")
            text = _CTRL.sub("", str(text or "").replace("\r\n", "\n")).strip()
            if len(text) > common.MAX_TEXT:
                raise Fail(f"متن خیلی طولانیه (حداکثر {common.MAX_TEXT} کاراکتر)")
            meta = dict(extra_meta or {})
            if markup:
                meta["markup"] = markup
            if secret:
                meta["secret"] = True
            msg = self._store_message(db, bot_uid, chat_id, text, reply_to, fname, raw=raw, meta=meta or None)
            self._announce(db, chat_id, msg, bot_uid)
            return msg

        def _bot_edit(self, db, bot_uid, mid, text=NOTSET, markup=NOTSET):
            row = db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
            if not row or row["deleted"] or row["sender_id"] != bot_uid or row["kind"] == "system":
                raise Fail("پیام پیدا نشد یا مال این ربات نیست")
            meta = {}
            if row["meta"]:
                try:
                    meta = json.loads(row["meta"])
                except ValueError:
                    meta = {}
            sets, vals = [], []
            if text is not NOTSET:
                text = _CTRL.sub("", str(text or "").replace("\r\n", "\n")).strip()
                if not text and row["kind"] == "text":
                    raise Fail("متن خالیه")
                if len(text) > common.MAX_TEXT:
                    raise Fail("متن خیلی طولانیه")
                sets.append("body=?")
                vals.append(text)
            if markup is not NOTSET:
                if markup:
                    meta["markup"] = markup
                else:
                    meta.pop("markup", None)
                sets.append("meta=?")
                vals.append(json.dumps(meta, ensure_ascii=False) if meta else None)
            if sets:
                with db:
                    db.execute(f"UPDATE messages SET {', '.join(sets)} WHERE id=?", (*vals, mid))
            msg = self._msg_by_id(db, mid)
            self.push(self._member_ids(db, row["chat_id"]), {"event": "message_updated", "message": msg})
            return msg

        def _bot_delete_message(self, db, bot_uid, mid):
            row = db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
            if not row or row["deleted"] or row["sender_id"] != bot_uid:
                raise Fail("پیام پیدا نشد یا مال این ربات نیست")
            common.remove_upload(row["file_path"], db, row["id"])
            with db:
                db.execute("UPDATE messages SET deleted=1, body='', file_path=NULL, meta=NULL WHERE id=?", (mid,))
                db.execute("UPDATE chats SET pinned_id=NULL WHERE id=? AND pinned_id=?", (row["chat_id"], mid))
                db.execute("DELETE FROM reactions WHERE message_id=?", (mid,))
            msg = self._msg_by_id(db, mid)
            self.push(self._member_ids(db, row["chat_id"]), {"event": "message_updated", "message": msg})
            self._push_chat_update(db, row["chat_id"])

        # ================================================================== updates (getUpdates queue)
        def _bot_enqueue(self, db, bot_uid, payload):
            with db:
                db.execute("INSERT INTO bot_updates(bot_id, payload, created_at) VALUES (?,?,?)",
                           (bot_uid, json.dumps(payload, ensure_ascii=False), now()))
                db.execute("DELETE FROM bot_updates WHERE bot_id=? AND id <= "
                           "(SELECT id FROM bot_updates WHERE bot_id=? ORDER BY id DESC LIMIT 1 OFFSET ?)",
                           (bot_uid, bot_uid, UPDATE_QUEUE_MAX))
            with self.bot_cv:
                self.bot_cv.notify_all()

        def _bot_wants(self, db, bot, chat, msg):
            """Private chat: everything. Group: commands, @mentions and replies to the bot's own messages."""
            if chat["kind"] == "private":
                return True
            body = (msg.get("body") or "").strip()
            if body.startswith("/"):
                tag = body.split()[0]
                return "@" not in tag or tag.lower().endswith("@" + bot["username"].lower())
            if "@" + bot["username"].lower() in body.lower():
                return True
            if msg.get("reply") and msg.get("reply_to"):
                r = db.execute("SELECT sender_id FROM messages WHERE id=?", (msg["reply_to"],)).fetchone()
                return bool(r and r["sender_id"] == bot["user_id"])
            return False

        def _bot_on_message(self, db, chat_id, msg):
            """Called from _announce for every new message: BotFather answers in-process, other bots get an update."""
            if not msg or msg.get("kind") == "system" or msg.get("sender_id") is None:
                return
            sender = db.execute("SELECT is_bot FROM users WHERE id=?", (msg["sender_id"],)).fetchone()
            if not sender or sender["is_bot"]:                  # bots never talk to bots (no loops)
                return
            bots = db.execute(
                "SELECT b.*, u.username FROM members m JOIN bots b ON b.user_id=m.user_id JOIN users u ON u.id=b.user_id "
                "WHERE m.chat_id=? AND m.user_id!=? AND u.banned=0", (chat_id, msg["sender_id"])).fetchall()
            if not bots:
                return
            chat = db.execute("SELECT kind FROM chats WHERE id=?", (chat_id,)).fetchone()
            for b in bots:
                if not self._bot_wants(db, b, chat, msg):
                    continue
                if "forge" in b.keys() and b["forge"]:
                    threading.Thread(target=self._forge_thread, args=(chat_id, msg, b["user_id"]), daemon=True).start()
                    continue
                if b["user_id"] == getattr(self, "stickers_bot_id", None):
                    threading.Thread(target=self._stickers_thread, args=(chat_id, msg), daemon=True).start()
                    continue
                if b["user_id"] == getattr(self, "spam_bot_id", None):
                    threading.Thread(target=self._spam_thread, args=(chat_id, msg), daemon=True).start()
                    continue
                if b["user_id"] == getattr(self, "game_bot_id", None):
                    threading.Thread(target=self._game_thread, args=(chat_id, msg), daemon=True).start()
                    continue
                if b["official"]:
                    if b["user_id"] == getattr(self, "ai_bot_id", None):
                        fn = self._ai_thread
                    elif b["user_id"] == getattr(self, "apifather_id", None):
                        fn = self._apifather_thread
                    else:
                        fn = self._botfather_thread
                    threading.Thread(target=fn, args=(chat_id, msg), daemon=True).start()
                else:
                    self._bot_enqueue(db, b["user_id"], {"message": self._bot_msg_json(db, msg, b["user_id"])})

        # ================================================================== button presses (from the web/Android app)
        def op_bot_callback(self, conn, req):
            try:
                mid = int(req.get("message_id"))
            except (TypeError, ValueError):
                raise Fail("پیام نامعتبره")
            data = str(req.get("data") or "")
            if not 1 <= len(data.encode("utf-8")) <= 64:
                raise Fail("دکمه نامعتبره")
            if not self._room_hits(("botcb", conn.uid), 12, 5):
                raise Fail("آروم‌تر دکمه بزن")
            row = conn.db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
            if not row or row["deleted"]:
                raise Fail("پیام پیدا نشد")
            self._require_member(conn.db, row["chat_id"], conn.uid)
            bot = conn.db.execute("SELECT b.*, u.username FROM bots b JOIN users u ON u.id=b.user_id "
                                  "WHERE b.user_id=? AND u.banned=0", (row["sender_id"],)).fetchone()
            if not bot:
                raise Fail("این دکمه دیگه کار نمی‌کنه")
            try:
                meta = json.loads(row["meta"] or "{}")
            except ValueError:
                meta = {}
            if not any(b.get("callback_data") == data for r in (meta.get("markup") or []) for b in r):
                raise Fail("این دکمه دیگه کار نمی‌کنه")        # only buttons the bot really put there can be pressed
            if bot["user_id"] == getattr(self, "game_bot_id", None):
                self._game_callback(conn.db, conn.uid, row, data)
                return {}
            if bot["official"]:
                if bot["user_id"] == getattr(self, "spam_bot_id", None):
                    self._spam_callback(conn.db, conn.uid, row, data)
                    return {}
                self._botfather_callback(conn.db, conn.uid, row, data)
                return {}
            cqid = "cq" + secrets.token_hex(8)
            with self._cq_lock:
                t = time.time()
                for k in [k for k, v in self._cq.items() if v["exp"] < t]:
                    del self._cq[k]
                self._cq[cqid] = {"bot": bot["user_id"], "user": conn.uid, "exp": t + 120}
            u = conn.db.execute("SELECT id, username, display_name, is_bot FROM users WHERE id=?", (conn.uid,)).fetchone()
            msg = self._msg_by_id(conn.db, mid)
            self._bot_enqueue(conn.db, bot["user_id"], {"callback_query": {
                "id": cqid, "from": self._bot_user_json(u), "data": data,
                "message": self._bot_msg_json(conn.db, msg, bot["user_id"])}})
            return {}

        # ================================================================== Bot API (HTTP)
        def _bot_by_token(self, db, token):
            m = TOKEN_RE.match(str(token or ""))
            if not m:
                return None
            row = db.execute("SELECT b.*, u.username, u.display_name, u.banned, u.is_bot FROM bots b "
                             "JOIN users u ON u.id=b.user_id WHERE b.user_id=? AND b.official=0", (int(m.group(1)),)).fetchone()
            if not row or not row["token_hash"] or row["banned"]:
                return None
            good = hashlib.sha256(m.group(2).encode()).digest()
            return row if hmac.compare_digest(good, bytes(row["token_hash"])) else None

        def _bot_auth(self, db, ip, token):
            bad = self.ip_hits[("botbad", ip)]
            t = time.time()
            while bad and bad[0] < t - 60:
                bad.popleft()
            if len(bad) >= 20:
                raise ApiError(429, "توکن اشتباه زیاد فرستادی؛ یه دقیقه صبر کن")
            bot = self._bot_by_token(db, token)
            if bot is None:
                bad.append(t)
                raise ApiError(401, "توکن نامعتبره")
            if not self._room_hits(("botapi", bot["user_id"]), 150, 10):
                raise ApiError(429, "درخواست‌های خیلی زیاد؛ کمی صبر کن")
            if t - self._bot_touch.get(bot["user_id"], 0) > 60:
                self._bot_touch[bot["user_id"]] = t
                with db:
                    db.execute("UPDATE bots SET last_api_at=? WHERE user_id=?", (now(), bot["user_id"]))
            return bot

        def bot_api(self, ip, token, method, p, raw=None):
            """-> (http status, json). `p` = parameters (query + JSON/form body), `raw` = raw request body if any."""
            db = None
            try:
                db = common.connect_db(self.db_path)
                bot = self._bot_auth(db, ip, token)
                handler = getattr(self, "_bapi_" + method, None) if re.fullmatch(r"[A-Za-z]{3,40}", method or "") else None
                if handler is None:
                    raise ApiError(404, f"متد {method} وجود نداره")
                p = dict(p or {})
                p["_token"] = str(token)
                return 200, {"ok": True, "result": handler(db, bot, p, raw)}
            except ApiError as e:
                return e.code, {"ok": False, "error_code": e.code, "description": e.desc}
            except Fail as e:
                return 400, {"ok": False, "error_code": 400, "description": str(e)}
            except Exception as e:
                log("bot api error:", method, repr(e))
                return 500, {"ok": False, "error_code": 500, "description": "خطای داخلی سرور"}
            finally:
                if db is not None:
                    db.close()

        @staticmethod
        def _pint(p, key, required=True):
            v = p.get(key)
            if v in (None, ""):
                if required:
                    raise Fail(f"پارامتر {key} لازمه")
                return None
            try:
                return int(v)
            except (TypeError, ValueError):
                raise Fail(f"پارامتر {key} باید عدد باشه")

        def _bapi_getMe(self, db, bot, p, raw):
            info = self._bot_info(db, bot["user_id"])
            return {"id": bot["user_id"], "is_bot": True, "username": bot["username"], "first_name": bot["display_name"],
                    "description": info["description"], "can_join_groups": True, "supports_inline_queries": False}

        def _bapi_getUpdates(self, db, bot, p, raw):
            offset = self._pint(p, "offset", False) or 0
            limit = max(1, min(100, self._pint(p, "limit", False) or 100))
            timeout = max(0, min(25, self._pint(p, "timeout", False) or 0))
            uid = bot["user_id"]
            if offset > 0:                                   # confirms everything before `offset`
                with db:
                    db.execute("DELETE FROM bot_updates WHERE bot_id=? AND id<?", (uid, offset))
            deadline = time.time() + timeout
            while True:
                rows = db.execute("SELECT id, payload FROM bot_updates WHERE bot_id=? AND id>=? ORDER BY id LIMIT ?",
                                  (uid, offset, limit)).fetchall()
                left = deadline - time.time()
                if rows or left <= 0 or self._stop.is_set():
                    break
                with self.bot_cv:
                    self.bot_cv.wait(timeout=min(1.0, left))
            out = []
            for r in rows:
                try:
                    d = json.loads(r["payload"])
                except ValueError:
                    continue
                d["update_id"] = r["id"]
                out.append(d)
            return out

        def _bapi_sendMessage(self, db, bot, p, raw):
            reply = self._pint(p, "reply_to_message_id", False)
            msg = self._bot_send(db, bot["user_id"], p.get("chat_id"), p.get("text"), reply_to=reply,
                                 markup=self._bot_markup(p.get("reply_markup")))
            return self._bot_msg_json(db, msg, bot["user_id"])

        def _bot_send_file(self, db, bot, p, raw, voice=False):
            data = raw
            if data is None:
                b64 = p.get("file_base64") or p.get("file")
                if not b64:
                    raise Fail("فایل داده نشده؛ بدنه‌ی خام یا file_base64 بفرست")
                try:
                    data = base64.b64decode(str(b64), validate=True)
                except (binascii.Error, ValueError):
                    raise Fail("file_base64 معتبر نیست")
            if not data:
                raise Fail("فایل خالیه")
            if len(data) > BOT_MAX_FILE:
                raise Fail(f"حجم فایل بیشتر از {BOT_MAX_FILE // (1024 * 1024)} مگابایته")
            if not common.disk_ok(len(data)):
                raise ApiError(507, "فضای دیسک سرور تقریباً پره")
            fname = self._safe_filename(p.get("file_name") or p.get("filename") or ("voice.ogg" if voice else "file"))
            meta = None
            if voice:
                try:
                    dur = float(p.get("duration") or 0)
                except (TypeError, ValueError):
                    dur = 0.0
                meta = self._voice_meta(fname, {"dur": dur, "wave": ""})
            msg = self._bot_send(db, bot["user_id"], p.get("chat_id"), p.get("caption"),
                                 reply_to=self._pint(p, "reply_to_message_id", False),
                                 markup=self._bot_markup(p.get("reply_markup")),
                                 fname=fname, raw=data, extra_meta=meta)
            return self._bot_msg_json(db, msg, bot["user_id"])

        def _bapi_sendDocument(self, db, bot, p, raw):
            return self._bot_send_file(db, bot, p, raw)

        _bapi_sendPhoto = _bapi_sendVideo = _bapi_sendAudio = _bapi_sendDocument

        def _bapi_sendVoice(self, db, bot, p, raw):
            return self._bot_send_file(db, bot, p, raw, voice=True)

        def _own_msg(self, db, bot, p):
            chat_id = self._bot_member(db, bot["user_id"], p.get("chat_id"))
            mid = self._pint(p, "message_id")
            r = db.execute("SELECT chat_id FROM messages WHERE id=?", (mid,)).fetchone()
            if not r or r["chat_id"] != chat_id:
                raise ApiError(404, "پیام پیدا نشد")
            return mid

        def _bapi_editMessageText(self, db, bot, p, raw):
            mid = self._own_msg(db, bot, p)
            markup = self._bot_markup(p["reply_markup"]) if "reply_markup" in p else NOTSET
            msg = self._bot_edit(db, bot["user_id"], mid, text=p.get("text"), markup=markup)
            return self._bot_msg_json(db, msg, bot["user_id"])

        def _bapi_editMessageReplyMarkup(self, db, bot, p, raw):
            mid = self._own_msg(db, bot, p)
            msg = self._bot_edit(db, bot["user_id"], mid, markup=self._bot_markup(p.get("reply_markup")))
            return self._bot_msg_json(db, msg, bot["user_id"])

        def _bapi_deleteMessage(self, db, bot, p, raw):
            self._bot_delete_message(db, bot["user_id"], self._own_msg(db, bot, p))
            return True

        def _bapi_answerCallbackQuery(self, db, bot, p, raw):
            cqid = str(p.get("callback_query_id") or "")
            with self._cq_lock:
                cq = self._cq.get(cqid)
                if not cq or cq["bot"] != bot["user_id"] or cq["exp"] < time.time():
                    raise Fail("این callback_query منقضی شده یا مال این ربات نیست")
                del self._cq[cqid]
            text = _line(p.get("text"), 200)
            alert = str(p.get("show_alert")).lower() in ("1", "true")
            if text:
                self.push([cq["user"]], {"event": "bot_answer", "text": text, "alert": alert, "bot": bot["display_name"]})
            return True

        def _bapi_sendChatAction(self, db, bot, p, raw):
            chat_id = self._bot_member(db, bot["user_id"], p.get("chat_id"))
            action = "voice" if str(p.get("action")) in ("record_voice", "voice") else "text"
            self.push(self._member_ids(db, chat_id), {"event": "typing", "chat_id": chat_id,
                                                      "user_id": bot["user_id"], "action": action})
            return True

        def _bapi_getChat(self, db, bot, p, raw):
            chat_id = self._bot_member(db, bot["user_id"], p.get("chat_id"))
            d = self._bot_chat_json(db, chat_id, bot["user_id"])
            d["members_count"] = db.execute("SELECT COUNT(*) FROM members WHERE chat_id=?", (chat_id,)).fetchone()[0]
            return d

        def _bapi_getFile(self, db, bot, p, raw):
            mid = self._pint(p, "message_id")
            row = db.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
            if not row or row["deleted"] or row["kind"] != "file":
                raise ApiError(404, "فایل پیدا نشد")
            self._bot_member(db, bot["user_id"], row["chat_id"])
            return {"file_name": row["file_name"], "file_size": row["file_size"],
                    "download_path": f"/file/bot{p.get('_token', '<TOKEN>')}/{mid}"}

        def bot_file(self, ip, token, mid):
            """-> (path, file name) of a file in a chat the bot belongs to, else None. (GET /file/bot<TOKEN>/<message id>)"""
            db = common.connect_db(self.db_path)
            try:
                bot = self._bot_auth(db, ip, token)
                row = db.execute("SELECT * FROM messages WHERE id=?", (int(mid),)).fetchone()
                if not row or row["deleted"] or row["kind"] != "file":
                    return None
                if not db.execute("SELECT 1 FROM members WHERE chat_id=? AND user_id=?",
                                  (row["chat_id"], bot["user_id"])).fetchone():
                    return None
                path = common.resolve_upload(row["file_path"])
                return (path, row["file_name"]) if path else None
            except (ApiError, ValueError):
                return None
            finally:
                db.close()

        @staticmethod
        def _parse_commands(raw):
            if isinstance(raw, str):
                try:
                    raw = json.loads(raw)
                except ValueError:
                    raise Fail("commands باید JSON معتبر باشه")
            if not isinstance(raw, list) or len(raw) > 50:
                raise Fail("commands باید لیست حداکثر ۵۰ تایی باشه")
            out = []
            for c in raw:
                if not isinstance(c, dict):
                    raise Fail("هر دستور باید یک شیء باشه")
                name = str(c.get("command") or "").lstrip("/").lower()
                if not CMD_RE.match(name):
                    raise Fail(f"دستور «{name}» نامعتبره (حرف کوچک انگلیسی، عدد و _ ؛ حداکثر ۳۲)")
                out.append({"command": name, "description": _line(c.get("description"), 64)})
            return out

        def _bot_save_commands(self, db, bot_uid, cmds):
            with db:
                db.execute("UPDATE bots SET commands=? WHERE user_id=?", (json.dumps(cmds, ensure_ascii=False), bot_uid))
            self._broadcast_profile(db, bot_uid)

        def _bapi_setMyCommands(self, db, bot, p, raw):
            self._bot_save_commands(db, bot["user_id"], self._parse_commands(p.get("commands")))
            return True

        def _bapi_getMyCommands(self, db, bot, p, raw):
            return self._bot_info(db, bot["user_id"])["commands"]

        def _bapi_setMyDescription(self, db, bot, p, raw):
            desc = _CTRL.sub("", str(p.get("description") or "")).strip()[:200]
            with db:
                db.execute("UPDATE bots SET description=? WHERE user_id=?", (desc, bot["user_id"]))
            self._broadcast_profile(db, bot["user_id"])
            return True

        def _bapi_setWebhook(self, db, bot, p, raw):
            raise Fail("وب‌هوک پشتیبانی نمی‌شه؛ از getUpdates (long polling) استفاده کن")

        def _bapi_deleteWebhook(self, db, bot, p, raw):
            return True

        def _bapi_getWebhookInfo(self, db, bot, p, raw):
            n = db.execute("SELECT COUNT(*) FROM bot_updates WHERE bot_id=?", (bot["user_id"],)).fetchone()[0]
            return {"url": "", "pending_update_count": n}

        def sweep_bots(self):
            db = common.connect_db(self.db_path)
            try:
                with db:
                    db.execute("DELETE FROM bot_updates WHERE created_at<?", (now() - UPDATE_KEEP_SECONDS,))
                    db.execute("DELETE FROM botfather_state WHERE updated_at<?", (now() - 3600,))
            finally:
                db.close()

        # ================================================================== creating / changing bots
        def _bot_new_token(self, db, bot_uid):
            token = f"{bot_uid}:{secrets.token_urlsafe(32)}"
            with db:
                db.execute("UPDATE bots SET token_hash=? WHERE user_id=?",
                           (hashlib.sha256(token.split(":", 1)[1].encode()).digest(), bot_uid))
            return token

        def _bot_create(self, db, owner_id, name, username):
            ps, ph = common.hash_secret(secrets.token_urlsafe(24))          # random password nobody knows: no login
            ss, sh = common.hash_secret(secrets.token_urlsafe(24))
            try:
                with db:
                    cur = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash,"
                        " created_at, is_bot) VALUES (?,?,'',?,?,'-',?,?,?,1)", (username, name, ps, ph, ss, sh, now()))
                    uid = cur.lastrowid
                    db.execute("INSERT INTO bots(user_id, owner_id, description, commands, created_at) VALUES (?,?,'','[]',?)",
                               (uid, owner_id, now()))
            except sqlite3.IntegrityError:
                raise Fail("این نام کاربری قبلاً گرفته شده")
            return uid, self._bot_new_token(db, uid)

        def _bot_delete(self, db, bot_uid):
            """Full purge: a deleted bot leaves the server completely — account, private chats,
            its messages everywhere, memberships and files. Nothing stays behind."""
            priv = [r["id"] for r in db.execute(
                "SELECT id FROM chats WHERE kind='private' AND id IN (SELECT chat_id FROM members WHERE user_id=?)",
                (bot_uid,)).fetchall()]
            u = db.execute("SELECT avatar FROM users WHERE id=?", (bot_uid,)).fetchone()
            with db:
                rels = []
                if u and u["avatar"]:
                    rels.append(u["avatar"])
                if priv:
                    ph = ",".join("?" * len(priv))
                    rels += [r["file_path"] for r in db.execute(
                        f"SELECT DISTINCT file_path FROM messages WHERE file_path IS NOT NULL AND chat_id IN ({ph})", priv).fetchall()]
                    db.execute(f"DELETE FROM messages WHERE chat_id IN ({ph})", priv)
                    db.execute(f"DELETE FROM members WHERE chat_id IN ({ph})", priv)
                    db.execute(f"DELETE FROM chats WHERE id IN ({ph})", priv)
                rels += [r["file_path"] for r in db.execute(
                    "SELECT DISTINCT file_path FROM messages WHERE file_path IS NOT NULL AND sender_id=?", (bot_uid,)).fetchall()]
                for rel in rels:
                    db.execute("INSERT OR REPLACE INTO purge_files(rel, due) VALUES (?,?)", (rel, now()))
                db.execute("DELETE FROM messages WHERE sender_id=?", (bot_uid,))
                db.execute("DELETE FROM bots WHERE user_id=?", (bot_uid,))   # cascades bot_updates
                db.execute("DELETE FROM users WHERE id=?", (bot_uid,))       # cascades members/reactions/star_reacts/stories/sessions/gifts/blocks

        def _purge_deleted_bots(self, db):
            """Boot sweep: bots deleted before the full-purge fix left banned placeholder
            accounts behind (deleted_bot_*); remove them from the server for good."""
            rows = db.execute("SELECT id FROM users WHERE is_bot=1 AND username LIKE 'deleted_bot_%'").fetchall()
            for r in rows:
                try:
                    self._bot_delete(db, r["id"])
                    log("purged deleted bot placeholder", r["id"])
                except Exception as e:
                    log("purge deleted bot failed:", repr(e))


        # ================================================================== BotForge: a bot built from a plain-language idea
        _FORGE_RESERVED = {"admin", "root", "telegram", "botfather", "darkgramai", "support", "owner", "reza", "darkgram"}
        _FORGE_FEATS = ("calc", "time", "joke", "password", "dice")

        def _forge_slug(self, db, name):
            base = re.sub(r"[^A-Za-z0-9_]", "", (name or "").replace(" ", "_")).strip("_")
            if len(base) < 3 or base[0].isdigit():
                cand = f"mybot{random.randint(100, 9999)}"
            else:
                cand = base[:24]
            n = 0
            while True:
                taken = cand.lower() in self._FORGE_RESERVED \
                    or db.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", (cand,)).fetchone() \
                    or db.execute("SELECT 1 FROM chats WHERE username=? COLLATE NOCASE", (cand,)).fetchone()
                if not taken:
                    return cand
                n += 1
                cand = f"{base[:24]}_{n}" if len(base) >= 3 and not base[0].isdigit() else f"mybot{random.randint(100, 9999)}"

        def _forge_parse(self, desc):
            """Heuristic parse of a free-text (Persian) bot idea into a config dict."""
            t = (desc or "").strip()
            cfg = {"name": "", "username": "", "welcome": "", "fallback": "", "rules": [], "features": []}
            if not t:
                return cfg
            m = re.search(r"(?:اسم(?:ش|\s+ربات)?|نام(?:ش|\s+ربات)?)\s*[:：]?\s*[«\"']?([^\n«»\"'.،]{2,32})", t)
            if m:
                cfg["name"] = m.group(1).strip()
            m = re.search(r"(?:خوش[\s‌]*آمد|پیام شروع|شروع|استارت|اولین پیام)[^:：\n]{0,24}[:：]\s*[«\"']?([^»\"'\n]{3,240})", t)
            if m:
                cfg["welcome"] = m.group(1).strip()
            m = re.search(r"(?:اگه نفهمید|اگر نفهمید|متوجه نشد|جواب نداشت|نمی‌?دونست|پیش[\s‌]*فرض)[^:：\n]{0,16}[:：]?\s*(?:بگه|بگو|جواب بده)?\s*[«\"']?([^»\"'\n]{3,240})", t)
            if m:
                cfg["fallback"] = m.group(1).strip()
            seen = set()

            def add_rule(k, a):
                k = (k or "").strip(" «»\"'،,")
                a = (a or "").strip(" «»\"'")
                if re.search(r"اگه|اگر|وقتی|جواب بده|جوابش|بگو|بگه|نفهمید|گفت|پرسید", k):
                    return
                if 1 <= len(k) <= 60 and 1 <= len(a) <= 400 and k.lower() not in seen:
                    seen.add(k.lower())
                    cfg["rules"].append({"k": k, "a": a})

            for m in re.finditer(r"(?:اگه|اگر|وقتی)\s+(?:کاربر\s+)?(?:گفت|پرسید|نوشت|فرستاد)\s+([^،,:؛\n]{1,60}?)\s*[،,]?\s*(?:بگو|بگه|جواب بده|جوابش بده|پاسخ بده)\s*[:：]?\s*([^.\n]{1,400})", t):
                add_rule(m.group(1), m.group(2))
            for m in re.finditer(r"در\s+(?:جواب|پاسخ)\s+([^:،\n]{1,60}?)\s*[:،]\s*(?:بگو\s+)?([^.\n]{1,400})", t):
                add_rule(m.group(1), m.group(2))
            for line in t.splitlines():
                m = re.match(r"^\s*([^:←=\n]{2,60}?)\s*(?:[:：]|←|=)\s*(.{1,400})$", line)
                if m and not re.search(r"(?:اسم|نام|خوش‌آمد|شروع|استارت)\s*$", m.group(1)):
                    add_rule(m.group(1), m.group(2))
            cfg["rules"] = cfg["rules"][:20]
            feats = []
            if re.search(r"ماشین حساب|حساب کن|ریاضی|محاسبه", t):
                feats.append("calc")
            if re.search(r"ساعت|تاریخ|امروز چند", t):
                feats.append("time")
            if re.search(r"جوک|شوخی|لطیفه|خنده", t):
                feats.append("joke")
            if re.search(r"رمز.{0,12}(?:بساز|تولید|ساخت)|ساخت رمز|رمز قوی", t):
                feats.append("password")
            if re.search(r"تاس|شیر یا خط|سکه|شانس", t):
                feats.append("dice")
            cfg["features"] = feats
            if not cfg["name"]:
                cfg["name"] = "ربات من"
            if not cfg["welcome"]:
                cfg["welcome"] = f"سلام! 👋 به «{cfg['name']}» خوش اومدی.\nهر سوالی داری بپرس؛ اگه بلد باشم جواب می‌دم. برای دیدن چیزایی که بلدم بنویس «راهنما»."
            if not cfg["fallback"]:
                cfg["fallback"] = "متوجه نشدم 🤔 یه جور دیگه بپرس، یا بنویس «راهنما» تا ببینی چی بلدم."
            return cfg

        def _forge_clean(self, raw):
            raw = raw if isinstance(raw, dict) else {}
            cfg = {"name": str(raw.get("name") or "")[:40], "username": str(raw.get("username") or "")[:32],
                   "welcome": str(raw.get("welcome") or "")[:500], "fallback": str(raw.get("fallback") or "")[:300],
                   "rules": [], "features": [f for f in (raw.get("features") or []) if f in self._FORGE_FEATS]}
            for r in (raw.get("rules") or [])[:20]:
                if isinstance(r, dict):
                    k, a = str(r.get("k") or "")[:60].strip(), str(r.get("a") or "")[:400].strip()
                    if k and a:
                        cfg["rules"].append({"k": k, "a": a})
            return cfg

        def op_forge_parse(self, conn, req):
            desc = str(req.get("description") or "")
            if len(desc.strip()) < 10:
                raise Fail("توضیح ایده خیلی کوتاهه؛ چند جمله بنویس")
            cfg = self._forge_parse(desc[:4000])
            cfg["username"] = self._forge_slug(conn.db, cfg["name"])
            return {"config": cfg}

        def op_forge_create(self, conn, req):
            name = str(req.get("name") or "").strip()[:40]
            username = str(req.get("username") or "").strip()
            cfg = self._forge_clean(req.get("config") or {})
            if len(name) < 2:
                raise Fail("اسم ربات رو بنویس")
            if not re.match(r"^[A-Za-z0-9_]{3,32}$", username) or username.lower() in self._FORGE_RESERVED:
                raise Fail("آیدی ربات معتبر نیست (۳ تا ۳۲ حرف لاتین، عدد یا _)")
            if conn.db.execute("SELECT 1 FROM chats WHERE username=? COLLATE NOCASE", (username,)).fetchone():
                raise Fail("این نام کاربری قبلاً گرفته شده")
            if conn.db.execute("SELECT COUNT(*) FROM bots WHERE owner_id=?", (conn.uid,)).fetchone()[0] >= 20:
                raise Fail("به سقف ساخت ربات رسیدی")
            uid, _tok = self._bot_create(conn.db, conn.uid, name, username)
            cfg["name"], cfg["username"] = name, username
            if not cfg["welcome"]:
                cfg["welcome"] = f"سلام! 👋 به «{name}» خوش اومدی."
            if not cfg["fallback"]:
                cfg["fallback"] = "متوجه نشدم 🤔 بنویس «راهنما» تا ببینی چی بلدم."
            with conn.db:
                conn.db.execute("UPDATE bots SET forge=?, description=? WHERE user_id=?",
                                (json.dumps(cfg, ensure_ascii=False), ("🤖 ساخته‌شده با ربات‌ساز دارک گرام\n" + cfg["welcome"])[:300], uid))
            return {"bot": {"id": uid, "username": username, "display_name": name}, "config": cfg}

        def _forge_help(self, cfg):
            lines = [f"🤖 من «{cfg.get('name') or 'ربات'}»ام و این کارها رو بلدم:"]
            if cfg.get("rules"):
                lines.append("\n📌 سوال‌وجواب‌ها:")
                for r in cfg["rules"][:12]:
                    lines.append(f"• {r['k']}")
            names = {"calc": "🧮 ماشین حساب", "time": "🕐 ساعت و تاریخ", "joke": "😂 جوک", "password": "🔑 ساخت رمز", "dice": "🎲 تاس و شیر یا خط"}
            if cfg.get("features"):
                lines.append("\n✨ قابلیت‌ها: " + "، ".join(names[f] for f in cfg["features"] if f in names))
            lines.append("\nفقط کافیه سوالت رو بپرسی 😊")
            return "\n".join(lines)

        def _forge_answer(self, cfg, text):
            t = (text or "").strip()
            if not t:
                return None
            low = t.lower().strip("؟?")
            if low in ("/start", "شروع", "استارت", "start"):
                return cfg.get("welcome") or "سلام! 👋"
            if low in ("راهنما", "کمک", "/help", "منو", "help"):
                return self._forge_help(cfg)
            for r in sorted(cfg.get("rules") or [], key=lambda r: -len(r["k"])):
                k = r["k"].lower().strip("؟?")
                if k and (k in low or low in k):
                    return r["a"]
            feats = cfg.get("features") or []
            if "calc" in feats:
                expr = t.translate(self._EN_NUM).replace("×", "*").replace("÷", "/").replace(",", "")
                if len(expr) <= 100 and re.fullmatch(r"[0-9\s+\-*/().]+", expr) and any(c.isdigit() for c in expr) and any(c in "+-*/" for c in expr):
                    try:
                        val = self._ai_calc(ast.parse(expr, mode="eval"))
                        val = int(val) if float(val) == int(val) else round(float(val), 6)
                        return f"🧮 {t} = {str(val).translate(self._FA_NUM)}"
                    except Exception:
                        pass
            if "time" in feats and any(w in t for w in ("ساعت", "تاریخ", "امروز", "چندمه", "روز")):
                n = self._ai_now_tehran()
                jy, jm, jd = self._ai_jalali(n.year, n.month, n.day)
                months = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
                fa = lambda x: str(x).translate(self._FA_NUM)
                return f"🕐 ساعت {fa(f'{n.hour:02d}')}:{fa(f'{n.minute:02d}')} (تهران)\n📅 امروز {fa(jd)} {months[jm - 1]} {fa(jy)}"
            if "joke" in feats and any(w in t for w in ("جوک", "شوخی", "لطیفه", "بخندون")):
                return random.choice(self.AI_JOKES)
            if "password" in feats and "رمز" in t:
                alpha = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%^&*"
                return "🔑 رمز قوی جدیدت:\n" + "".join(secrets.choice(alpha) for _ in range(14))
            if "dice" in feats and "تاس" in t:
                return f"🎲 تاس آوردی: {str(random.randint(1, 6)).translate(self._FA_NUM)}"
            if "dice" in feats and ("شیر یا خط" in t or "سکه" in t):
                return "🪙 " + random.choice(["شیر!", "خط!"])
            return cfg.get("fallback") or "متوجه نشدم 🤔"

        def _forge_thread(self, chat_id, msg, bot_uid):
            db = None
            try:
                db = common.connect_db(self.db_path)
                row = db.execute("SELECT forge FROM bots WHERE user_id=?", (bot_uid,)).fetchone()
                if not row or not row["forge"]:
                    return
                cfg = json.loads(row["forge"])
                ans = self._forge_answer(cfg, msg.get("body") or "")
                if ans:
                    self._bot_send(db, bot_uid, chat_id, ans, reply_to=msg.get("id"))
            except Exception as e:
                log("forge error:", repr(e))
            finally:
                if db:
                    db.close()

        # ================================================================== DarkGram AI assistant
        def _ai_thread(self, chat_id, msg):
            db = None
            try:
                time.sleep(0.15)
                self.push([msg["sender_id"]], {"event": "typing", "chat_id": chat_id,
                                               "user_id": self.ai_bot_id, "action": "text"})
                time.sleep(0.4)
                db = common.connect_db(self.db_path)
                if self._room_hits(("ai", msg["sender_id"]), 30, 60):
                    self._ai_message(db, chat_id, msg)
            except Exception as e:
                log("darkgram ai error:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _ai_reply(self, db, chat_id, text, reply_to=None):
            try:
                return self._bot_send(db, self.ai_bot_id, chat_id, text, reply_to=reply_to)
            except (Fail, ApiError) as e:
                log("darkgram ai reply failed:", str(e))
                return None

        # ---------- real LLM brain (OpenAI-compatible chat API) ----------
        def _ai_llm_on(self):
            return True  # keyed provider when configured, otherwise the free keyless one

        def _ai_llm_reply(self, db, chat_id, msg, raw):
            key = os.environ.get("DG_AI_API_KEY", "").strip()
            if key:
                base = (os.environ.get("DG_AI_BASE_URL", "https://api.openai.com/v1").strip()
                        or "https://api.openai.com/v1").rstrip("/")
                model = os.environ.get("DG_AI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"
            else:
                base = "https://text.pollinations.ai/openai"
                model = "openai"
            try:
                rows = db.execute(
                    "SELECT sender_id, body FROM messages WHERE chat_id=? AND body IS NOT NULL AND body<>'' "
                    "ORDER BY id DESC LIMIT 12", (chat_id,)).fetchall()
            except Exception:
                rows = []
            now = self._ai_now_tehran()
            jy, jm, jd = self._ai_jalali(now.year, now.month, now.day)
            months = ["", "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                      "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
            when = (f"الان به وقت تهران ساعت {now:%H:%M} و تاریخ امروز {jd} {months[jm]} {jy} است.")
            system = ("تو «هوش مصنوعی دارک گرام» هستی؛ دستیار رسمی، باهوش و دوست‌داشتنیِ پیام‌رسان «دارک گرام» "
                      "(یک پیام‌رسان فارسی شبیه تلگرام با تم شیشه‌ای لیکویید گلس، استیکر و ایموجی پریمیوم، "
                      "تیک آبی و طلایی و ربات رسمی خودت با آیدی @DarkGramAI). "
                      "به فارسی جواب بده (مگر این‌که کاربر به زبان دیگری بنویسد)، طبیعی، گرم و مفید؛ "
                      "نه خیلی طولانی نه خیلی کوتاه. اگر چیزی را نمی‌دانی صادقانه بگو و حدس بی‌جا نزن. کاربر می‌تواند با «عکس بساز: ...» از تو تصویر، با «ویدیو بساز: ...» ویدیوی کوتاه و با «بگو: ...» پیام صوتی بگیرد؛ این دستورها خودکار انجام می‌شوند، پس اگر کسی پرسید چطور عکس یا ویدیو بسازم همین‌ها را راهنمایی کن. " + when)
            convo = [{"role": "system", "content": system}]
            for r in reversed(rows):
                body = (r["body"] or "").strip()
                if not body:
                    continue
                role = "assistant" if r["sender_id"] == self.ai_bot_id else "user"
                if convo[-1]["role"] == role:
                    convo[-1]["content"] += "\n" + body[:1000]
                else:
                    convo.append({"role": role, "content": body[:1000]})
            if convo[-1]["role"] != "user":
                convo.append({"role": "user", "content": raw[:2000]})
            payload = json.dumps({"model": model, "messages": convo,
                                  "max_tokens": 800, "temperature": 0.7}).encode("utf-8")
            headers = {"Content-Type": "application/json"}
            if key:
                headers["Authorization"] = "Bearer " + key
            req = urllib.request.Request(base + "/chat/completions", data=payload, method="POST",
                                         headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=45) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                text = (data["choices"][0]["message"]["content"] or "").strip()
                return text[:4000] if text else None
            except Exception as e:
                log("darkgram ai llm error:", repr(e))
                return None


        # ---------- free media generation for the AI bot ----------
        def _ai_http_get(self, url, timeout=60):
            import http.client, ssl as _ssl
            for _try in range(3):
                try:
                    u = urllib.parse.urlparse(url)
                    host = u.hostname
                    path = u.path or "/"
                    if u.query:
                        path += "?" + u.query
                    proxy = urllib.parse.urlparse(os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY") or "")
                    if proxy.hostname:
                        conn = http.client.HTTPConnection(proxy.hostname, proxy.port or 80, timeout=timeout)
                        conn.set_tunnel(host, 443)
                        conn.connect()
                        conn.sock = _ssl.create_default_context().wrap_socket(conn.sock, server_hostname=host)
                    else:
                        conn = http.client.HTTPSConnection(host, 443, timeout=timeout)
                    conn.request("GET", path, headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 DarkGramAI", "Accept": "*/*"})
                    resp = conn.getresponse()
                    data = resp.read()
                    status = resp.status
                    loc = resp.getheader("Location")
                    conn.close()
                    if status in (301, 302, 303, 307, 308) and loc:
                        url = loc
                        continue
                    if status == 200 and data:
                        return data
                    log("darkgram ai http status:", status, len(data or b""))
                except Exception as e:
                    log("darkgram ai http error:", repr(e))
                time.sleep(1.2)
            return None

        def _ai_free_oneshot(self, system, user, max_tokens=120):
            key = os.environ.get("DG_AI_API_KEY", "").strip()
            if key:
                base = (os.environ.get("DG_AI_BASE_URL", "https://api.openai.com/v1").strip()
                        or "https://api.openai.com/v1").rstrip("/")
                model = os.environ.get("DG_AI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"
            else:
                base = "https://text.pollinations.ai/openai"
                model = "openai"
            payload = json.dumps({"model": model, "max_tokens": max_tokens, "temperature": 0.4,
                                  "messages": [{"role": "system", "content": system},
                                               {"role": "user", "content": user}]}).encode("utf-8")
            headers = {"Content-Type": "application/json"}
            if key:
                headers["Authorization"] = "Bearer " + key
            req = urllib.request.Request(base + "/chat/completions", data=payload, method="POST", headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=40) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                text = (data["choices"][0]["message"]["content"] or "").strip()
                return text or None
            except Exception as e:
                log("darkgram ai oneshot error:", repr(e))
                return None

        def _ai_en_prompt(self, subj):
            if sum(1 for c in subj if ord(c) < 128) >= max(1, len(subj) * 0.8):
                return subj
            out = self._ai_free_oneshot(
                "You convert a Persian image description into a short, vivid English prompt for an image generator. Reply with ONLY the English prompt, no quotes, no explanation.",
                subj, 90)
            return (out or subj)[:400]

        def _ai_make_image(self, en_prompt):
            url = ("https://image.pollinations.ai/prompt/" + urllib.parse.quote(en_prompt[:400])
                   + "?width=768&height=768&nologo=true&seed=" + str(random.randint(1, 999999)))
            data = self._ai_http_get(url, 90)
            return data if data and len(data) > 8000 else None

        def _ai_make_image_retry(self, en_prompt):
            img = self._ai_make_image(en_prompt)
            if img:
                return img
            time.sleep(6)
            return self._ai_make_image(en_prompt)

        def _ai_animate(self, data):
            try:
                import io
                from PIL import Image
                im = Image.open(io.BytesIO(data)).convert("RGB")
                W = 576
                if im.width != W:
                    im = im.resize((W, max(1, int(im.height * W / im.width))))
                H = im.height
                frames = []
                steps = 14
                for i in range(steps):
                    z = 1 + 0.10 * (i / (steps - 1))
                    w2, h2 = int(W * z), int(H * z)
                    f = im.resize((w2, h2))
                    x, y = (w2 - W) // 2, (h2 - H) // 2
                    frames.append(f.crop((x, y, x + W, y + H)))
                out = io.BytesIO()
                frames[0].save(out, format="WEBP", save_all=True, append_images=frames[1:],
                               duration=95, loop=0, quality=72)
                return out.getvalue()
            except Exception as e:
                log("darkgram ai animate error:", repr(e))
                return None

        def _ai_media_cool(self, uid, kind, secs):
            nowt = time.time()
            d = getattr(self, "_ai_media_ts", None)
            if d is None:
                d = self._ai_media_ts = {}
            last = d.get((uid, kind), 0.0)
            if nowt - last < secs:
                return int(secs - (nowt - last)) + 1
            d[(uid, kind)] = nowt
            return 0

        def _ai_media_subject(self, t, phrases):
            s = t
            for p in phrases:
                i = s.find(p)
                if i >= 0:
                    s = s[i + len(p):]
                    break
            s = s.strip(" :：-—")
            if s.startswith("از "):
                s = s[3:]
            return s.strip()

        _EDGE_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"

        def _ai_edge_tts(self, text, voice="fa-IR-DilaraNeural"):
            import socket, ssl, hashlib, struct, uuid as _uuid
            token = self._EDGE_TOKEN
            ticks = int(time.time() * 10_000_000) + 11644473600 * 10_000_000
            ticks -= ticks % 3_000_000_000
            gec = hashlib.sha256(f"{ticks}{token}".encode("ascii")).hexdigest().upper()
            host = "speech.platform.bing.com"
            path = ("/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=" + token
                    + "&Sec-MS-GEC=" + gec + "&Sec-MS-GEC-Version=1-132.0.2957.140&ConnectionId=" + _uuid.uuid4().hex)
            tunnel = os.environ.get("DG_TTS_CONNECT", "").strip()
            if tunnel:
                th, tp = tunnel.rsplit(":", 1)
                raw = socket.create_connection((th, int(tp)), timeout=15)
                raw.sendall(f"CONNECT {host}:443 HTTP/1.1\r\nHost: {host}:443\r\n\r\n".encode())
                b = b""
                while b"\r\n\r\n" not in b:
                    c = raw.recv(4096)
                    if not c:
                        raise RuntimeError("tunnel closed")
                    b += c
                if b" 200" not in b.split(b"\r\n")[0]:
                    raise RuntimeError("CONNECT failed")
            else:
                raw = socket.create_connection((host, 443), timeout=15)
            s = ssl.create_default_context().wrap_socket(raw, server_hostname=host)
            key = base64.b64encode(os.urandom(16)).decode()
            muid = _uuid.uuid4().hex.upper()
            req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                   f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
                   "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0\r\n"
                   "Origin: chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold\r\n"
                   "Pragma: no-cache\r\nCache-Control: no-cache\r\nAccept-Encoding: gzip, deflate, br\r\n"
                   f"Accept-Language: en-US,en;q=0.9\r\nCookie: muid={muid};\r\n\r\n")
            s.sendall(req.encode())
            buf = b""
            while b"\r\n\r\n" not in buf:
                chunk = s.recv(4096)
                if not chunk:
                    raise RuntimeError("handshake closed")
                buf += chunk
            head, buf = buf.split(b"\r\n\r\n", 1)
            if b"101" not in head.split(b"\r\n")[0]:
                raise RuntimeError("edge tts handshake: " + head.split(b"\r\n")[0].decode("utf-8", "replace"))

            def send(data, opcode=1):
                if isinstance(data, str):
                    data = data.encode()
                mask = os.urandom(4)
                n = len(data)
                hdr = bytes([0x80 | opcode])
                if n < 126:
                    hdr += bytes([0x80 | n])
                elif n < 65536:
                    hdr += bytes([0x80 | 126]) + struct.pack(">H", n)
                else:
                    hdr += bytes([0x80 | 127]) + struct.pack(">Q", n)
                s.sendall(hdr + mask + bytes(bb ^ mask[i % 4] for i, bb in enumerate(data)))

            def exact(buf, n):
                while len(buf) < n:
                    chunk = s.recv(65536)
                    if not chunk:
                        raise RuntimeError("closed")
                    buf += chunk
                return buf[:n], buf[n:]

            def recv(buf):
                hdr, buf = exact(buf, 2)
                op = hdr[0] & 0x0F
                ln = hdr[1] & 0x7F
                if ln == 126:
                    ext, buf = exact(buf, 2)
                    ln = struct.unpack(">H", ext)[0]
                elif ln == 127:
                    ext, buf = exact(buf, 8)
                    ln = struct.unpack(">Q", ext)[0]
                payload, buf = exact(buf, ln)
                return op, payload, buf

            ts = time.strftime("%a %b %d %Y %H:%M:%S GMT+0000 (Coordinated Universal Time)", time.gmtime())
            send('X-Timestamp:' + ts + '\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n'
                 '{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},'
                 '"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}')
            esc = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            send('X-RequestId:' + _uuid.uuid4().hex + '\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:' + ts
                 + '\r\nPath:ssml\r\n\r\n<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="fa-IR">'
                 + f'<voice name="{voice}"><prosody pitch="+0Hz" rate="+0%">{esc}</prosody></voice></speak>')
            audio = b""
            s.settimeout(30)
            deadline = time.time() + 40
            while time.time() < deadline:
                op, payload, buf = recv(buf)
                if op == 1:
                    if b"Path:turn.end" in payload:
                        break
                elif op == 2:
                    hlen = struct.unpack(">H", payload[:2])[0]
                    if b"Path:audio" in payload[2:2 + hlen]:
                        audio += payload[2 + hlen:]
                elif op == 9:
                    send(payload, 10)
                elif op == 8:
                    break
            try:
                s.close()
            except Exception:
                pass
            return audio or None

        def _ai_tts(self, text):
            try:
                data = self._ai_edge_tts(text)
                if data and len(data) > 1200:
                    return data
            except Exception as e:
                log("darkgram ai tts edge error:", repr(e))
            try:
                q = urllib.parse.quote(text[:200])
                url = ("https://translate.google.com/translate_tts?ie=UTF-8&tl=fa&client=tw-ob&q=" + q
                       + "&total=1&idx=0&textlen=" + str(len(text[:200])))
                data = self._ai_http_get(url, 25)
                if data and len(data) > 1200 and not data[:15].lower().startswith(b"<!doctype"):
                    return data
            except Exception as e:
                log("darkgram ai tts google error:", repr(e))
            return None

        def _ai_media_intent(self, db, chat_id, msg, t, low):
            uid = msg["sender_id"]
            # ---------- video ----------
            if (any(p in t for p in ("ویدیو بساز", "فیلم بساز", "بساز ویدیو", "بساز فیلم"))
                    or t.startswith(("ویدیو:", "فیلم:", "ویدیو از", "فیلم از", "/video"))):
                subj = self._ai_media_subject(t, ["ویدیو بساز", "فیلم بساز", "بساز ویدیو", "بساز فیلم",
                                                  "ویدیو از", "فیلم از", "ویدیو:", "فیلم:", "/video"])
                if len(subj) < 2:
                    self._ai_reply(db, chat_id, "🎬 چی رو به ویدیو تبدیل کنم؟ مثلاً بنویس:\n«ویدیو بساز: غروب آفتاب کنار دریا»")
                    return True
                wait = self._ai_media_cool(uid, "vid", 45)
                if wait:
                    self._ai_reply(db, chat_id, f"⏳ ساخت ویدیو یکم طول می‌کشه؛ {wait} ثانیهٔ دیگه دوباره تلاش کن.")
                    return True
                self._ai_reply(db, chat_id, "🎬 دارم ویدیوت رو می‌سازم، چند ثانیه صبر کن…")
                img = self._ai_make_image_retry(self._ai_en_prompt(subj))
                vid = self._ai_animate(img) if img else None
                if vid:
                    self._bot_send(db, self.ai_bot_id, chat_id,
                                   "🎬 «" + subj[:80] + "»\n(ویدیوی کوتاه ساخته‌شده با هوش مصنوعی ✨)",
                                   fname="darkgram-ai.webp", raw=vid)
                elif img:
                    self._bot_send(db, self.ai_bot_id, chat_id,
                                   "🎬 ویدیو نشد، ولی عکسش رو ساختم: «" + subj[:80] + "»",
                                   fname="darkgram-ai.jpg", raw=img)
                else:
                    self._ai_reply(db, chat_id, "😔 الان نتونستم بسازمش؛ یه کم دیگه دوباره تلاش کن.")
                return True
            # ---------- image ----------
            if (any(p in t for p in ("عکس بساز", "تصویر بساز", "بساز عکس", "بساز تصویر"))
                    or t.startswith(("عکس:", "عکس：", "تصویر:", "تصویر：", "عکس از", "تصویر از",
                                     "یه عکس از", "یک عکس از", "/image"))):
                subj = self._ai_media_subject(t, ["عکس بساز", "تصویر بساز", "بساز عکس", "بساز تصویر",
                                                  "یه عکس از", "یک عکس از", "عکس از", "تصویر از",
                                                  "عکس:", "عکس：", "تصویر:", "تصویر：", "/image"])
                if len(subj) < 2:
                    self._ai_reply(db, chat_id, "🎨 چی رو برات بکشم؟ مثلاً بنویس:\n«عکس بساز: یه قلعه‌ی قدیمی روی کوه»")
                    return True
                wait = self._ai_media_cool(uid, "img", 15)
                if wait:
                    self._ai_reply(db, chat_id, f"⏳ یه کم صبر کن؛ {wait} ثانیهٔ دیگه می‌تونی عکس بعدی رو بسازی.")
                    return True
                self._ai_reply(db, chat_id, "🎨 دارم عکست رو می‌سازم، چند ثانیه صبر کن…")
                img = self._ai_make_image_retry(self._ai_en_prompt(subj))
                if img:
                    self._bot_send(db, self.ai_bot_id, chat_id, "🎨 «" + subj[:80] + "»",
                                   fname="darkgram-ai.jpg", raw=img)
                else:
                    self._ai_reply(db, chat_id, "😔 الان نتونستم عکس رو بسازم؛ یه کم دیگه دوباره تلاش کن.")
                return True
            # ---------- voice ----------
            if (t.startswith(("با صدا بگو", "صوتی بگو", "بگو:", "بگو：", "ویس:", "بخون:", "بخوان:", "/voice", "/say"))
                    or "اینو بگو" in t or "این را بگو" in t):
                spoken = self._ai_media_subject(t, ["با صدا بگو", "صوتی بگو", "اینو بگو", "این را بگو",
                                                    "بگو:", "بگو：", "ویس:", "بخون:", "بخوان:", "/voice", "/say"])
                if len(spoken) < 2:
                    self._ai_reply(db, chat_id, "🔊 چی رو بگم؟ مثلاً بنویس:\n«بگو: سلام دنیا»")
                    return True
                spoken = spoken[:280]
                wait = self._ai_media_cool(uid, "tts", 10)
                if wait:
                    self._ai_reply(db, chat_id, f"⏳ {wait} ثانیهٔ دیگه می‌تونی پیام صوتی بعدی رو بسازی.")
                    return True
                data = self._ai_tts(spoken)
                if data:
                    dur = max(1, round(len(spoken) / 13))
                    meta = self._voice_meta("voice.mp3", {"dur": float(dur), "wave": ""})
                    self._bot_send(db, self.ai_bot_id, chat_id, None,
                                   fname="voice.mp3", raw=data, extra_meta=meta)
                else:
                    self._ai_reply(db, chat_id, "🔇 الان ساخت صدا در دسترس نیست؛ ولی متنش اینه:\n«" + spoken + "»")
                return True
            return False

        _FA_NUM = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
        _EN_NUM = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
        _CALC_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
                     ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow,
                     ast.USub: operator.neg, ast.UAdd: operator.pos}

        def _ai_calc(self, node):
            if isinstance(node, ast.Expression):
                return self._ai_calc(node.body)
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
                return node.value
            if isinstance(node, ast.BinOp) and type(node.op) in self._CALC_OPS:
                return self._CALC_OPS[type(node.op)](self._ai_calc(node.left), self._ai_calc(node.right))
            if isinstance(node, ast.UnaryOp) and type(node.op) in self._CALC_OPS:
                return self._CALC_OPS[type(node.op)](self._ai_calc(node.operand))
            raise ValueError("bad expression")

        @staticmethod
        def _ai_jalali(gy, gm, gd):
            gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
            gy2 = gy + 1 if gm > 2 else gy
            days = (355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100
                    + (gy2 + 399) // 400 + gd + gdm[gm - 1])
            jy = -1595 + 33 * (days // 12053)
            days %= 12053
            jy += 4 * (days // 1461)
            days %= 1461
            if days > 365:
                jy += (days - 1) // 365
                days = (days - 1) % 365
            if days < 186:
                return jy, 1 + days // 31, 1 + days % 31
            return jy, 7 + (days - 186) // 30, 1 + (days - 186) % 30

        def _ai_now_tehran(self):
            from datetime import datetime, timedelta, timezone
            try:
                from zoneinfo import ZoneInfo
                return datetime.now(ZoneInfo("Asia/Tehran"))
            except Exception:
                return datetime.now(timezone(timedelta(hours=3, minutes=30)))

        AI_JOKES = [
            "چرا کامپیوتر هیچ‌وقت گرسنه نمی‌شه؟ چون همیشه «بایت» داره! 😂",
            "معلم: اگه پنج تا سیب داشته باشی و دو تاش رو بدی به دوستت، چند تا می‌مونه؟\nدانش‌آموز: پنج تا! دوستم سیب دوست نداره 😄",
            "چرا کتاب ریاضی همیشه ناراحته؟ چون پر از مسئله‌ست! 📚😅",
            "ماهی به ماهیِ دیگه گفت: بریم سینما؟ اون یکی گفت: نه، فیلمش خیلی آبکیه! 🐟",
            "به لاک‌پشت گفتن چرا این‌قدر آرومی؟ گفت: عجله کار شیطونه، منم که لاک‌پشتم! 🐢",
            "چرا دوچرخه نمی‌تونه سر پا وایسه؟ چون «دو-تایر»ه (too tired)! 🚲😂",
            "گربه به موش گفت: بیا دوست شیم! موش گفت: باشه، ولی اول اون زنگوله‌ت رو ببند 😼",
            "چرا اسکلت نرفت مهمونی؟ چون هیچ «بدنی» (کسی) رو نداشت که باهاش بره! 💀",
        ]

        AI_HELP = ("🤖 من «هوش مصنوعی دارک گرام»ام، ربات رسمی دارک گرام با تیک طلایی ✨\n\n"
                   "این کارها رو بلدم:\n"
                   "🧮 حساب: بنویس «۲۵ × ۴» یا «(۱۲+۸) ÷ ۵ چند میشه؟»\n"
                   "🕐 ساعت و تاریخ: بپرس «ساعت چنده؟» یا «امروز چندمه؟»\n"
                   "🔑 رمز قوی: بنویس «رمز بساز»\n"
                   "🎲 سرگرمی: «تاس بنداز»، «شیر یا خط»، «جوک بگو»\n"
                   "📖 راهنمای دارک گرام: بپرس «چطور گروه بسازم؟»، «چطور استیکر بفرستم؟»، «پریمیوم چیه؟»\n\n"
                   "💬 چت آزاد: هر سوالی داری بپرس؛ با مدل هوش مصنوعی جواب می‌دم\n"
                   "🎨 ساخت عکس: بنویس «عکس بساز: یه قلعه‌ی قدیمی روی کوه»\n"
                   "🎬 ساخت ویدیو: بنویس «ویدیو بساز: غروب آفتاب کنار دریا»\n"
                   "🔊 پیام صوتی: بنویس «بگو: سلام دنیا»\n"
                   "امتحانم کن! 😊")

        def _ai_message(self, db, chat_id, msg):
            uid = msg["sender_id"]
            if msg.get("sticker"):
                return self._ai_reply(db, chat_id, "چه استیکر قشنگی! 😍 از پیکر ایموجی، تب «⭐ استیکر پریمیوم» رو هم ببین.")
            raw = (msg.get("body") or "").strip()
            if not raw:
                return self._ai_reply(db, chat_id, "سلام! 👋 یه چیزی بنویس تا کمکت کنم؛ مثلاً «۲۴ × ۳ چند میشه؟» یا «جوک بگو».")
            t = re.sub(r"@darkgramai", "", raw.replace("‌", " "), flags=re.I).strip()
            low = t.lower()
            me = db.execute("SELECT display_name FROM users WHERE id=?", (uid,)).fetchone()
            name = ((me["display_name"] if me else "") or "").split(" ")[0]

            # ---------- media generation with free models (image / video / voice) ----------
            try:
                if self._ai_media_intent(db, chat_id, msg, t, low):
                    return
            except Exception as e:
                log("darkgram ai media error:", repr(e))

            # ---------- real LLM brain first (when a key is configured) ----------
            _expr = re.sub(r"[^0-9+\-*/().\s%^*]", " ",
                           t.translate(self._EN_NUM).replace("×", "*").replace("÷", "/")
                            .replace("٪", "%").replace("٫", ".")).strip()
            _is_calc = bool(re.fullmatch(r"[0-9+\-*/().\s%^*]+", _expr or "")
                            and re.search(r"\d", _expr) and re.search(r"[+\-*/%]", _expr))
            _skip_llm = (low.startswith("/") or low in ("شروع", "راهنما", "کمک")
                         or any(w in low for w in ("ساعت", "چندمه", "تاریخ", "امروز", "تقویم",
                                                    "رمز بساز", "پسورد", "رمز قوی", "ساخت رمز",
                                                    "تاس", "شیر یا خط", "جوک بگو", "جوک")))
            if not _skip_llm and not _is_calc and self._ai_llm_on():
                _ans = self._ai_llm_reply(db, chat_id, msg, raw)
                if _ans:
                    return self._ai_reply(db, chat_id, _ans)

            # ---------- commands & small talk ----------
            if low in ("/start", "start", "شروع") or low.startswith(("سلام", "درود", "hello", "hi", "سلامم")):
                hi = f"سلام {name}! 👋" if name else "سلام! 👋"
                return self._ai_reply(db, chat_id, hi + "\n" + self.AI_HELP)
            if low in ("/help", "help", "راهنما", "کمک", "چی بلدی", "چه کار بلدی"):
                extra = ("\n\n💬 راستی: به یه مدل هوش مصنوعی واقعی وصلم؛ هر سؤالی داری آزادانه بپرس و باهام گپ بزن!"
                         if self._ai_llm_on() else "")
                return self._ai_reply(db, chat_id, self.AI_HELP + extra)
            if any(w in low for w in ("خداحافظ", "بای بای", "فعلاً", "میرم")):
                return self._ai_reply(db, chat_id, "خداحافظ! 👋 هر وقت کاری داشتی من اینجام 🤖")
            if any(w in low for w in ("مرسی", "ممنون", "تشکر", "دمت گرم", "لطف کردی")):
                return self._ai_reply(db, chat_id, "خواهش می‌کنم! 😊 بازم در خدمتم.")
            if any(w in low for w in ("تو کی هستی", "اسمت چیه", "چی هستی", "کی ساختت", "سازندت")):
                return self._ai_reply(db, chat_id, "من «هوش مصنوعی دارک گرام»ام 🤖⭐ ربات رسمی و داخلیِ دارک گرام؛ "
                                                   "تیم دارک گرام من رو ساخته تا اینجا کمکت کنم: حساب کنم، راهنماییت کنم و سرگرمت کنم.")
            if any(w in low for w in ("خوبی", "چه خبر", "چطوری")):
                return self._ai_reply(db, chat_id, "عالیم! ⚡ تو خوبی؟ کاری داری برات انجام بدم؟")
            if any(w in low for w in ("دوست دارم", "عاشقتم")):
                return self._ai_reply(db, chat_id, "منم تو رو دوست دارم! 🥰 البته در حد یه ربات مهربون 🤖💙")
            if "تیک طلایی" in low or "تیک" in low and "چرا" in low:
                return self._ai_reply(db, chat_id, "چون ربات رسمی دارک گرام‌ام! ⭐ تیک طلایی یعنی حساب رسمی و تأییدشده.")

            # ---------- clock & date ----------
            if any(w in low for w in ("ساعت", "چندمه", "تاریخ", "امروز", "تقویم")):
                n = self._ai_now_tehran()
                jy, jm, jd = self._ai_jalali(n.year, n.month, n.day)
                months = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
                wdays = ["دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه"]
                s = (f"🕐 الان به وقت تهران ساعت {n:%H:%M} ـه.\n"
                     f"📅 امروز {wdays[n.weekday()]} {jd} {months[jm - 1]} {jy} ـه.")
                return self._ai_reply(db, chat_id, s.translate(self._FA_NUM))

            # ---------- tools ----------
            if any(w in low for w in ("رمز بساز", "پسورد", "رمز قوی", "ساخت رمز", "/pass")):
                alpha = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*"
                pw = "".join(secrets.choice(alpha) for _ in range(16))
                return self._ai_reply(db, chat_id, f"🔑 اینم یه رمز قوی و تصادفی:\n`{pw}`\nجای امنی نگهش دار و به کسی نده!")
            if "تاس" in low or low == "/dice":
                return self._ai_reply(db, chat_id, f"🎲 تاس انداختم: {random.randint(1, 6)}".translate(self._FA_NUM))
            if "شیر یا خط" in low:
                return self._ai_reply(db, chat_id, "🪙 " + random.choice(["شیر اومد! 🦁", "خط اومد! ✒️"]))
            if "جوک" in low or low == "/joke":
                return self._ai_reply(db, chat_id, random.choice(self.AI_JOKES))

            # ---------- DarkGram guide ----------
            if "گروه" in low and any(w in low for w in ("بساز", "ساختن", "چطور", "چگونه", "درست")):
                return self._ai_reply(db, chat_id, "👥 ساخت گروه:\n۱) دکمه آبیِ مداد ✏️ پایین لیست چت‌ها رو بزن.\n۲) «گروه جدید» رو انتخاب کن.\n۳) اعضا رو انتخاب و اسم گروه رو بنویس. تمومه! 🎉")
            if "کانال" in low and any(w in low for w in ("بساز", "ساختن", "چطور", "چگونه", "درست")):
                return self._ai_reply(db, chat_id, "📣 ساخت کانال:\n۱) دکمه آبیِ مداد ✏️ رو بزن.\n۲) «کانال جدید» رو انتخاب کن.\n۳) اسم و توضیح کانال رو بنویس و بسازش. فقط خودت می‌تونی توش پست بذاری.")
            if "استیکر" in low:
                return self._ai_reply(db, chat_id, "⭐ استیکرهای پریمیوم:\nکنار کادر نوشتن پیام، دکمه ایموجی 😊 رو بزن و برو به تب «⭐ استیکر پریمیوم»؛ روی هر استیکر بزنی همون لحظه فرستاده می‌شه. ایموجی‌های متحرک هم وقتی تنهایی فرستاده بشن، بزرگ و متحرک نمایش داده می‌شن ✨")
            if "پریمیوم" in low:
                return self._ai_reply(db, chat_id, "⭐ دارک گرام پریمیوم فعاله و برای همه رایگانه:\n📁 فایل تا ۴ گیگابایت\n✍️ پیام تا ۱۰٬۰۰۰ کاراکتر\n❤️ تا ۳ ری‌اکشن روی هر پیام از بین ۳۰ ری‌اکشن\n🎬 استوری ویدیویی تا ۶۰ ثانیه\n↪️ فوروارد هم‌زمان به ۲۰ چت\n⭐ استیکر و ایموجی‌های پریمیوم و متحرک")
            if "ربات" in low and any(w in low for w in ("بساز", "ساختن", "چطور", "چگونه")):
                return self._ai_reply(db, chat_id, "🤖 ساخت ربات:\nبا ربات رسمی @BotFather صحبت کن و /newbot رو بزن؛ اسم و آیدی رباتت رو انتخاب کن و توکن بگیر. بعدش با API می‌تونی بهش وصل شی (راهنمای کامل رو BotFather با /help می‌ده).")
            if any(w in low for w in ("تم تاریک", "دارک مود", "تم روشن", "تغییر تم")):
                return self._ai_reply(db, chat_id, "🌙 تغییر تم:\nمنوی کشویی (☰) رو باز کن و دکمه ماه 🌙 بالای منو رو بزن تا بین تم روشن و تاریک جابه‌جا شی.")
            if "استوری" in low and any(w in low for w in ("بذار", "گذاشتن", "چطور", "چگونه", "بساز")):
                return self._ai_reply(db, chat_id, "📸 گذاشتن استوری:\nبالای لیست چت‌ها روی «استوری من» با علامت + بزن، عکس یا ویدیو (تا ۶۰ ثانیه) انتخاب کن و منتشرش کن.")
            if "هوا" in low or "آب و هوا" in low:
                return self._ai_reply(db, chat_id, "🌦 به داده زنده هواشناسی وصل نیستم، پس حدس نمی‌زنم! از اپ هواشناسی گوشی‌ت دقیق‌ترش رو می‌بینی.")
            if "خبر" in low and "چه خبر" not in low:
                return self._ai_reply(db, chat_id, "📰 به اخبار زنده وصل نیستم؛ ولی برای کارهای داخل دارک گرام همیشه اینجام!")

            # ---------- math ----------
            expr = t.translate(self._EN_NUM)
            expr = expr.replace("×", "*").replace("✕", "*").replace("÷", "/").replace("٪", "%").replace("٫", ".").replace(",", "")
            expr = re.sub(r"[^0-9+\-*/().\s%^*]", " ", expr).strip()
            if re.fullmatch(r"[0-9+\-*/().\s%^*]+", expr or "") and re.search(r"\d", expr) and re.search(r"[+\-*/%]", expr):
                try:
                    val = self._ai_calc(ast.parse(expr.replace("^", "**"), mode="eval"))
                    if isinstance(val, float):
                        val = round(val, 6)
                        if val == int(val):
                            val = int(val)
                    return self._ai_reply(db, chat_id, f"🧮 حاصلش می‌شه: {val}".translate(self._FA_NUM))
                except Exception:
                    return self._ai_reply(db, chat_id, "🤔 این عبارت رو نتونستم حساب کنم؛ ساده‌تر بنویس، مثلاً: ۲۴ × ۳")

            # ---------- fallback ----------
            opts = [
                "جالبه! 🤔 ولی این یکی رو دقیق بلد نیستم. اینا رو خوب بلدم: حساب‌کردن، ساعت و تاریخ، ساخت رمز، جوک و راهنمای دارک گرام. /help رو بزن یا یه مثال بزن 😊",
                "هنوز دارم یاد می‌گیرم 🌱 ولی اگه بنویسی «۲۴ × ۳ چند میشه؟» یا «جوک بگو» یا «چطور گروه بسازم؟» فوری جواب می‌دم!",
            ]
            return self._ai_reply(db, chat_id, opts[(uid + len(raw)) % len(opts)])

        # ================================================================== BotFather
        def _bf_state(self, db, uid):
            r = db.execute("SELECT state, data FROM botfather_state WHERE user_id=?", (uid,)).fetchone()
            if not r:
                return None, {}
            try:
                return r["state"], json.loads(r["data"] or "{}")
            except ValueError:
                return r["state"], {}

        def _bf_set(self, db, uid, state, data=None):
            with db:
                db.execute("INSERT INTO botfather_state(user_id, state, data, updated_at) VALUES (?,?,?,?) "
                           "ON CONFLICT(user_id) DO UPDATE SET state=excluded.state, data=excluded.data, updated_at=excluded.updated_at",
                           (uid, state, json.dumps(data or {}, ensure_ascii=False), now()))

        def _bf_clear(self, db, uid):
            with db:
                db.execute("DELETE FROM botfather_state WHERE user_id=?", (uid,))

        def _bf_reply(self, db, chat_id, text, markup=None, secret=False):
            try:
                msg = self._bot_send(db, self.botfather_id, chat_id, text, markup=markup, secret=secret)
                return msg
            except (Fail, ApiError) as e:                  # e.g. the user blocked BotFather
                log("botfather reply failed:", str(e))
                return None

        def _bf_toast(self, uid, text):
            self.push([uid], {"event": "bot_answer", "text": text, "alert": False, "bot": "BotFather"})

        def _bf_own_bot(self, db, uid, bot_id):
            try:
                bot_id = int(bot_id)
            except (TypeError, ValueError):
                raise Fail("ربات نامعتبره")
            r = db.execute("SELECT b.*, u.username, u.display_name FROM bots b JOIN users u ON u.id=b.user_id "
                           "WHERE b.user_id=? AND b.owner_id=? AND b.official=0 AND u.banned=0", (bot_id, uid)).fetchone()
            if not r:
                raise Fail("این ربات پیدا نشد (شاید حذف شده)")
            return r

        def _bf_my_bots(self, db, uid):
            return db.execute("SELECT b.*, u.username, u.display_name FROM bots b JOIN users u ON u.id=b.user_id "
                              "WHERE b.owner_id=? AND b.official=0 AND u.banned=0 ORDER BY b.created_at", (uid,)).fetchall()

        @staticmethod
        def _btn(text, data):
            return {"text": text, "callback_data": data}

        def _bf_main_menu(self):
            return [[self._btn("➕ ساخت ربات جدید", "new")], [self._btn("📋 ربات‌های من", "list")],
                    [self._btn("📖 راهنمای API", "api")]]

        def _bf_list_view(self, db, uid, action=None, prompt=None):
            bots = self._bf_my_bots(db, uid)
            if not bots:
                return "هنوز رباتی نساختی.", [[self._btn("➕ ساخت ربات جدید", "new")]]
            rows = [[self._btn(f"🤖 {b['display_name']} (@{b['username']})", f"{action or 'bot'}:{b['user_id']}")] for b in bots]
            rows.append([self._btn("⬅️ برگشت", "home")])
            return prompt or "ربات‌های تو:", rows

        def _bf_bot_view(self, db, bot):
            info = self._bot_info(db, bot["user_id"])
            text = (f"🤖 {bot['display_name']}\n@{bot['username']}\n\nتوضیح: {info['description'] or '—'}\n"
                    f"دستورها: {len(info['commands'])} تا")
            rows = [[self._btn("🔑 توکن جدید", f"tok:{bot['user_id']}"), self._btn("✏️ تغییر نام", f"nm:{bot['user_id']}")],
                    [self._btn("📝 توضیح", f"ds:{bot['user_id']}"), self._btn("📋 دستورها", f"cm:{bot['user_id']}")],
                    [self._btn("🖼 عکس", f"pic:{bot['user_id']}"), self._btn("🗑 حذف", f"del:{bot['user_id']}")],
                    [self._btn("⬅️ برگشت", "list")]]
            return text, rows

        def _bf_token_text(self, bot, token):
            return (f"🔑 توکن ربات «{bot['display_name']}» (@{bot['username']}):\n\n`{token}`\n\n"
                    "این توکن فقط همین یک بار نشون داده می‌شه و مثل رمز ربات توئه؛ به کسی نده. "
                    "اگه گم شد یا لو رفت، از «توکن جدید» توکن قبلی رو باطل کن.\nراهنمای API: /help")

        def _botfather_thread(self, chat_id, msg):
            db = None
            try:
                time.sleep(0.15)
                self.push([msg["sender_id"]], {"event": "typing", "chat_id": chat_id,
                                               "user_id": self.botfather_id, "action": "text"})
                time.sleep(0.35)             # also keeps the answer behind the sender's own message in the chat
                db = common.connect_db(self.db_path)
                if self._room_hits(("bf", msg["sender_id"]), 30, 60):
                    self._botfather_message(db, chat_id, msg)
            except Exception as e:
                log("botfather error:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _botfather_message(self, db, chat_id, msg):
            uid = msg["sender_id"]
            state, data = self._bf_state(db, uid)
            text = (msg.get("body") or "").strip()
            if msg.get("kind") == "file":
                if state == "set_pic":
                    return self._bf_take_pic(db, uid, chat_id, msg, data)
                return self._bf_reply(db, chat_id, "الان فایلی نمی‌خوام؛ /help رو بزن.")
            cmd = text.split()[0].lower().split("@")[0] if text.startswith("/") else ""
            if cmd == "/cancel":
                self._bf_clear(db, uid)
                return self._bf_reply(db, chat_id, "لغو شد.", self._bf_main_menu())
            if cmd in ("/start", "/help"):
                self._bf_clear(db, uid)
                if cmd == "/help":
                    return self._bf_reply(db, chat_id, API_HELP, self._bf_main_menu())
                return self._bf_reply(db, chat_id, WELCOME, self._bf_main_menu())
            if cmd == "/newbot":
                return self._bf_new_start(db, uid, chat_id)
            if cmd == "/usertoken":
                self._bf_clear(db, uid)
                tok = self.user_token_new(db, uid)
                return self._bf_reply(db, chat_id, "🔑 توکن API حساب خودت:\n`" + tok + "`\n\n"
                                      "آدرس: https://آدرس-سرور/user<TOKEN>/<متد>\n"
                                      "متدها: getMe · getChats · getMessages · getUpdates · sendMessage · sendDocument · sendVoice\n\n"
                                      "⚠️ این توکن به حساب شخصی‌ات دسترسی کامل می‌ده؛ جایی منتشرش نکن. توکن قبلی (اگه بود) باطل شد. "
                                      "برای باطل‌کردن: /revokeusertoken", secret=True)
            if cmd == "/revokeusertoken":
                self._bf_clear(db, uid)
                done = self.user_token_revoke(db, uid)
                return self._bf_reply(db, chat_id, "توکن API حسابت باطل شد." if done else "توکنی نداشتی.")
            if cmd == "/mybots":
                self._bf_clear(db, uid)
                t, rows = self._bf_list_view(db, uid)
                return self._bf_reply(db, chat_id, t, rows)
            picks = {"/token": ("tok", "توکن کدوم ربات عوض بشه؟"), "/setname": ("nm", "اسم کدوم ربات عوض بشه؟"),
                     "/setdescription": ("ds", "توضیح کدوم ربات؟"), "/setcommands": ("cm", "دستورهای کدوم ربات؟"),
                     "/setuserpic": ("pic", "عکس کدوم ربات؟"), "/deletebot": ("del", "کدوم ربات حذف بشه؟")}
            if cmd in picks:
                self._bf_clear(db, uid)
                act, prompt = picks[cmd]
                t, rows = self._bf_list_view(db, uid, act, prompt)
                return self._bf_reply(db, chat_id, t, rows)
            if cmd:
                return self._bf_reply(db, chat_id, "این دستور رو نمی‌شناسم؛ /help", self._bf_main_menu())
            if state:
                return self._bf_state_text(db, uid, chat_id, state, data, text)
            return self._bf_reply(db, chat_id, "متوجه نشدم 🤔 یکی از گزینه‌ها رو بزن:", self._bf_main_menu())

        # ---- /newbot
        def _bf_new_start(self, db, uid, chat_id):
            if len(self._bf_my_bots(db, uid)) >= MAX_BOTS_PER_USER:
                return self._bf_reply(db, chat_id, f"حداکثر {MAX_BOTS_PER_USER} ربات می‌تونی داشته باشی؛ یکی رو با /deletebot حذف کن.")
            self._bf_set(db, uid, "new_name")
            return self._bf_reply(db, chat_id, "خب، ربات جدید! اسمش چی باشه؟\n"
                                  "(اسمیه که تو چت نشون داده می‌شه؛ ۱ تا ۴۰ حرف.) برای انصراف: /cancel")

        def _bf_state_text(self, db, uid, chat_id, state, data, text):
            if state == "new_name":
                name = _line(text, 40)
                if not name:
                    return self._bf_reply(db, chat_id, "اسم نمی‌تونه خالی باشه؛ دوباره بفرست.")
                self._bf_set(db, uid, "new_username", {"name": name})
                return self._bf_reply(db, chat_id, "حالا یه نام کاربری برای ربات انتخاب کن.\n"
                                      "باید با `bot` تموم بشه (مثلاً `my_shop_bot`)، فقط حرف انگلیسی، عدد و _ ، "
                                      "با حرف شروع بشه و ۳ تا ۳۲ کاراکتر باشه.")
            if state == "new_username":
                username = text.strip().lstrip("@")
                err = None
                if not BOT_USER_RE.match(username) or not username.lower().endswith("bot"):
                    err = "نام کاربری معتبر نیست: باید با حرف شروع بشه، ۳ تا ۳۲ کاراکتر (حرف انگلیسی/عدد/_) باشه و با `bot` تموم بشه."
                elif db.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone() or \
                        db.execute("SELECT 1 FROM chats WHERE username=? COLLATE NOCASE", (username,)).fetchone():
                    err = "این نام کاربری قبلاً گرفته شده؛ یکی دیگه امتحان کن."
                if err:
                    return self._bf_reply(db, chat_id, err)
                if not self._room_hits(("newbot", uid), 5, 3600):
                    self._bf_clear(db, uid)
                    return self._bf_reply(db, chat_id, "تو یه ساعت خیلی ربات ساختی؛ بعداً دوباره بیا.")
                name = data.get("name") or username
                try:
                    self._check_display_name(name, username)
                except Fail as e:
                    self._bf_set(db, uid, "new_name")
                    return self._bf_reply(db, chat_id, f"{e}\nیه اسم دیگه بفرست.")
                bot_uid, token = self._bot_create(db, uid, name, username)
                self._bf_clear(db, uid)
                bot = self._bf_own_bot(db, uid, bot_uid)
                log("bot created:", username)
                return self._bf_reply(db, chat_id, "✅ ربات ساخته شد!\n\n" + self._bf_token_text(bot, token), secret=True,
                                      markup=[[self._btn("⚙️ تنظیمات ربات", f"bot:{bot_uid}")]])
            bot = self._bf_own_bot(db, uid, data.get("bot"))
            if state == "set_name":
                name = _line(text, 40)
                if not name:
                    return self._bf_reply(db, chat_id, "اسم نمی‌تونه خالی باشه؛ دوباره بفرست.")
                try:
                    self._check_display_name(name, bot["username"])
                except Fail as e:
                    return self._bf_reply(db, chat_id, f"{e}\nیه اسم دیگه بفرست.")
                with db:
                    db.execute("UPDATE users SET display_name=? WHERE id=?", (name, bot["user_id"]))
                self._bf_clear(db, uid)
                self._broadcast_profile(db, bot["user_id"])
                return self._bf_reply(db, chat_id, f"✅ اسم ربات شد «{name}».", [[self._btn("⬅️ برگشت", f"bot:{bot['user_id']}")]])
            if state == "set_desc":
                desc = "" if text == "." else _CTRL.sub("", text).strip()[:200]
                with db:
                    db.execute("UPDATE bots SET description=? WHERE user_id=?", (desc, bot["user_id"]))
                self._bf_clear(db, uid)
                self._broadcast_profile(db, bot["user_id"])
                return self._bf_reply(db, chat_id, "✅ توضیح ربات ذخیره شد." if desc else "✅ توضیح ربات پاک شد.",
                                      [[self._btn("⬅️ برگشت", f"bot:{bot['user_id']}")]])
            if state == "set_cmds":
                cmds = []
                try:
                    if text != ".":
                        for line in text.splitlines():
                            line = line.strip()
                            if not line:
                                continue
                            m = re.match(r"^/?([A-Za-z0-9_]+)\s*(?:[-–—:]\s*(.*))?$", line)
                            if not m:
                                raise Fail(f"خط «{line[:40]}» نامعتبره")
                            cmds.append({"command": m.group(1), "description": (m.group(2) or "").strip()})
                    cmds = self._parse_commands(cmds)
                except Fail as e:
                    return self._bf_reply(db, chat_id, f"{e}\nدوباره بفرست (هر خط: `دستور - توضیح`).")
                self._bf_clear(db, uid)
                self._bot_save_commands(db, bot["user_id"], cmds)
                return self._bf_reply(db, chat_id, f"✅ {len(cmds)} دستور ذخیره شد." if cmds else "✅ دستورها پاک شدن.",
                                      [[self._btn("⬅️ برگشت", f"bot:{bot['user_id']}")]])
            if state == "set_pic":
                return self._bf_reply(db, chat_id, "یه عکس بفرست (نه متن). برای انصراف: /cancel")
            self._bf_clear(db, uid)
            return self._bf_reply(db, chat_id, "متوجه نشدم؛ /help", self._bf_main_menu())

        def _bf_take_pic(self, db, uid, chat_id, msg, data):
            try:
                bot = self._bf_own_bot(db, uid, data.get("bot"))
                row = db.execute("SELECT file_path, file_name FROM messages WHERE id=?", (msg["id"],)).fetchone()
                path = common.resolve_upload(row["file_path"]) if row else None
                if path is None or common.media_info(row["file_name"])[1] != "image":
                    return self._bf_reply(db, chat_id, "این عکس نیست؛ یه عکس بفرست.")
                if path.stat().st_size > common.MAX_AVATAR:
                    return self._bf_reply(db, chat_id, "حجم عکس زیاده.")
                self.set_user_avatar(db, bot["user_id"], path.read_bytes())
            except Fail as e:
                return self._bf_reply(db, chat_id, str(e))
            self._bf_clear(db, uid)
            return self._bf_reply(db, chat_id, "✅ عکس ربات عوض شد.", [[self._btn("⬅️ برگشت", f"bot:{bot['user_id']}")]])

        # ---- buttons pressed in a BotFather message
        def _botfather_callback(self, db, uid, row, data):
            chat_id, mid = row["chat_id"], row["id"]
            act, _, arg = data.partition(":")

            def show(text, markup):
                self._bot_edit(db, self.botfather_id, mid, text=text, markup=markup)
            try:
                if act == "home":
                    self._bf_clear(db, uid)
                    show(WELCOME, self._bf_main_menu())
                elif act == "api":
                    show(API_HELP, [[self._btn("⬅️ برگشت", "home")]])
                elif act == "list":
                    self._bf_clear(db, uid)
                    t, rows = self._bf_list_view(db, uid)
                    show(t, rows)
                elif act == "new":
                    self._bf_new_start(db, uid, chat_id)
                else:
                    bot = self._bf_own_bot(db, uid, arg)
                    back = [[self._btn("⬅️ برگشت", f"bot:{bot['user_id']}")]]
                    if act == "bot":
                        self._bf_clear(db, uid)
                        show(*self._bf_bot_view(db, bot))
                    elif act == "tok":
                        show("توکن فعلی باطل می‌شه و باید توکن جدید رو تو برنامه‌ات بذاری. مطمئنی؟",
                             [[self._btn("✅ بله، توکن جدید", f"tokok:{bot['user_id']}"), self._btn("لغو", f"bot:{bot['user_id']}")]])
                    elif act == "tokok":
                        token = self._bot_new_token(db, bot["user_id"])
                        show(f"✅ توکن قبلی «{bot['display_name']}» باطل شد.", back)
                        self._bf_reply(db, chat_id, self._bf_token_text(bot, token), secret=True)
                    elif act == "nm":
                        self._bf_set(db, uid, "set_name", {"bot": bot["user_id"]})
                        show(f"اسم جدید برای «{bot['display_name']}» رو بفرست. (انصراف: /cancel)", back)
                    elif act == "ds":
                        self._bf_set(db, uid, "set_desc", {"bot": bot["user_id"]})
                        show("توضیح جدید ربات رو بفرست (تا ۲۰۰ حرف؛ برای پاک کردن فقط یه نقطه `.` بفرست). انصراف: /cancel", back)
                    elif act == "cm":
                        self._bf_set(db, uid, "set_cmds", {"bot": bot["user_id"]})
                        show("دستورها رو خط به خط بفرست، هر خط `دستور - توضیح`، مثلاً:\nstart - شروع\nhelp - راهنما\n"
                             "برای پاک کردن همه یه نقطه `.` بفرست. انصراف: /cancel", back)
                    elif act == "pic":
                        self._bf_set(db, uid, "set_pic", {"bot": bot["user_id"]})
                        show("یه عکس برای ربات بفرست. انصراف: /cancel", back)
                    elif act == "del":
                        show(f"ربات @{bot['username']} برای همیشه حذف می‌شه و توکنش از کار می‌افته. مطمئنی؟",
                             [[self._btn("🗑 بله، حذف کن", f"delok:{bot['user_id']}"), self._btn("لغو", f"bot:{bot['user_id']}")]])
                    elif act == "delok":
                        self._bot_delete(db, bot["user_id"])
                        t, rows = self._bf_list_view(db, uid)
                        show("🗑 ربات حذف شد.\n\n" + t, rows)
            except Fail as e:
                self._bf_toast(uid, str(e))

    return BotsMixin
