"""Two extra HTTP APIs (served by the web gateway, same JSON style as the bot API):

  /user<ID>:<SECRET>/<method>   personal API for a normal account (token from BotFather: /usertoken)
        getMe  getChats  getMessages  getUpdates  sendMessage  sendDocument/sendPhoto/sendVideo/sendAudio/sendVoice
  /admin/<action>               local admin API for the desktop datasheet (127.0.0.1 only + key in data/admin.key)
        announce  botfatherGet  botfatherSet  botfatherPhoto
"""
import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time

from bots import ApiError, BOT_MAX_FILE

USER_TOKEN_RE = re.compile(r"(\d{1,12}):([A-Za-z0-9_\-]{20,80})")
BADGE_MARK = {1: "\u2063\u200b", 2: "\u2063\u200c", 3: "\u2063\u200d"}
PREM_MARK = "\u2064"          # invisible premium flag appended after the badge marker
FAKE_MARK = "\u2063\u200f"       # invisible fake flag -> red FAKE label (Telegram-style)
LOYAL_MARK = "\u2063\u200a"
BOUNTY_MARK = "\u2063\u2060"
SCAM_MARK = "\u2063\u2062"       # invisible scam flag -> red SCAM label (Telegram-style)
NEWS_MARK = "\u2063\u2061"        # invisible news-channel flag -> «اطلاع‌رسانی» label on the chat title      # invisible bug-bounty flag -> gold medal icon (no text)       # invisible loyal flag -> blue loyal-user label
OFFICIAL_MARK = "\u2063\u200e"  # invisible official-channel flag: client draws the «کانال رسمی» label
AF_COMMANDS = [("token", "گرفتن توکن API حساب"), ("revoke", "باطل‌کردن توکن"), ("help", "راهنما")]
AF_HELP = ("🔑 من **ApiFather** هستم؛ توکن API حساب شخصی‌ات رو می‌دم.\n\n"
           "/token ← توکن تازه (توکن قبلی باطل می‌شه)\n/revoke ← باطل‌کردن توکن\n\n"
           "با توکن می‌تونی از کد (پایتون و...) با حسابت کار کنی:\n`https://آدرس-سرور/user<TOKEN>/<متد>`\n"
           "متدها: getMe · getChats · getMessages · getUpdates · sendMessage · sendDocument · sendVoice")
LOCAL = {"127.0.0.1", "::1", "::ffff:127.0.0.1"}
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\u2063]")


def make_adminapi(Fail, common, log):
    now = common.now

    class AdminApiMixin:
        # ============================================================ setup
        _badges = {}
        _cbadges = {}
        _premium = set()
        _fakes = set()
        _loyals = set()
        _bountys = set()
        _scams = set()
        _estatus = {}

        def _cbadged(self, chat_id, title):
            return (title or "") + BADGE_MARK.get(self._cbadges.get(chat_id, 0), "")

        def _badged(self, uid, name):
            return (name or "") + BADGE_MARK.get(self._badges.get(uid, 0), "") + (PREM_MARK if uid in self._premium else "") + (FAKE_MARK if uid in self._fakes else "") + (LOYAL_MARK if uid in self._loyals else "") + (BOUNTY_MARK if uid in self._bountys else "") + (SCAM_MARK if uid in self._scams else "") + ((" " + self._estatus[uid]) if self._estatus.get(uid) else "")

        def _adminapi_init(self, db):
            fresh = db.execute("SELECT 1 FROM sqlite_master WHERE name='user_tokens'").fetchone() is None
            with db:
                db.execute("CREATE TABLE IF NOT EXISTS user_tokens(user_id INTEGER PRIMARY KEY, "
                           "token_hash BLOB NOT NULL, created_at INTEGER)")
            self._ensure_apifather(db)
            if fresh:                                        # first run of this feature: the official bots get a blue tick
                with db:
                    db.execute("UPDATE users SET badge=1 WHERE badge=0 AND id IN (?,?)", (self.botfather_id, self.apifather_id))
            self._badges = {r["id"]: r["badge"] for r in db.execute("SELECT id, badge FROM users WHERE badge>0")}
            self._cbadges = {r["id"]: r["badge"] for r in db.execute("SELECT id, badge FROM chats WHERE badge>0")}
            self._premium = {r["id"] for r in db.execute("SELECT id FROM users WHERE premium=1")}
            self._fakes = {r["id"] for r in db.execute("SELECT id FROM users WHERE fake=1")}
            with db:
                db.execute("UPDATE users SET loyal=1, bounty=1 WHERE username='owner' COLLATE NOCASE")
                db.execute("UPDATE chats SET news=1 WHERE username='botsaz' COLLATE NOCASE")
            self._loyals = {r["id"] for r in db.execute("SELECT id FROM users WHERE loyal=1")}
            self._bountys = {r["id"] for r in db.execute("SELECT id FROM users WHERE bounty=1")}
            self._scams = {r["id"] for r in db.execute("SELECT id FROM users WHERE scam=1")}
            self._estatus = {r["id"]: r["emoji_status"] for r in db.execute("SELECT id, emoji_status FROM users WHERE emoji_status<>''")}
            f = common.DATA_DIR / "admin.key"
            try:
                self.admin_key = f.read_text().strip()
            except OSError:
                self.admin_key = ""
            if len(self.admin_key) < 20:
                self.admin_key = secrets.token_urlsafe(32)
                common.DATA_DIR.mkdir(parents=True, exist_ok=True)
                f.write_text(self.admin_key)
                try:
                    os.chmod(f, 0o600)
                except OSError:
                    pass

        # ============================================================ ApiFather (official bot that hands out account tokens)
        def _ensure_apifather(self, db):
            row = db.execute("SELECT id, is_bot FROM users WHERE username='ApiFather' COLLATE NOCASE").fetchone()
            if row is not None and not row["is_bot"]:
                with db:
                    db.execute("UPDATE users SET username=? WHERE id=?", (f"ApiFather_user{row['id']}", row["id"]))
                row = None
            if row is None:
                ps, ph = common.hash_secret(secrets.token_urlsafe(24))
                ss, sh = common.hash_secret(secrets.token_urlsafe(24))
                with db:
                    uid = db.execute(
                        "INSERT INTO users(username, display_name, bio, pw_salt, pw_hash, sec_question, sec_salt, sec_hash, created_at, is_bot) "
                        "VALUES ('ApiFather','ApiFather','توکن API حساب شخصی',?,?,'-',?,?,?,1)", (ps, ph, ss, sh, now())).lastrowid
            else:
                uid = row["id"]
            with db:
                db.execute("INSERT OR IGNORE INTO bots(user_id, owner_id, official, description, commands, created_at) VALUES (?,NULL,1,?,?,?)",
                           (uid, "ربات رسمی برای گرفتن توکن API حساب کاربری", json.dumps(
                               [{"command": c, "description": d} for c, d in AF_COMMANDS], ensure_ascii=False), now()))
            self.apifather_id = uid

        def _apifather_thread(self, chat_id, msg):
            db = None
            try:
                time.sleep(0.15)
                self.push([msg["sender_id"]], {"event": "typing", "chat_id": chat_id, "user_id": self.apifather_id, "action": "text"})
                time.sleep(0.35)
                db = common.connect_db(self.db_path)
                if self._room_hits(("af", msg["sender_id"]), 20, 60):
                    self._apifather_message(db, chat_id, msg)
            except Exception as e:
                log("apifather error:", repr(e))
            finally:
                if db is not None:
                    db.close()

        def _apifather_message(self, db, chat_id, msg):
            uid = msg["sender_id"]
            u = db.execute("SELECT is_bot FROM users WHERE id=?", (uid,)).fetchone()
            if not u or u["is_bot"]:
                return
            text = (msg.get("body") or "").strip()
            cmd = text.split()[0].lower().split("@")[0] if text.startswith("/") else ""
            send = lambda t, secret=False: self._bot_send(db, self.apifather_id, chat_id, t, secret=secret)
            if cmd in ("/token", "/newtoken", "/usertoken"):
                tok = self.user_token_new(db, uid)
                send("🔑 توکن API حساب تو:\n`" + tok + "`\n\n⚠️ این توکن به حساب شخصی‌ات دسترسی کامل می‌ده؛ به کسی نده. "
                     "توکن قبلی باطل شد. برای باطل‌کردن: /revoke", secret=True)
            elif cmd in ("/revoke", "/revokeusertoken"):
                send("توکن API حسابت باطل شد." if self.user_token_revoke(db, uid) else "توکنی نداشتی.")
            else:
                send(AF_HELP)

        # ============================================================ personal tokens
        def user_token_new(self, db, uid):
            secret = secrets.token_urlsafe(32)
            with db:
                db.execute("INSERT OR REPLACE INTO user_tokens(user_id, token_hash, created_at) VALUES (?,?,?)",
                           (uid, hashlib.sha256(secret.encode()).digest(), now()))
            return f"{uid}:{secret}"

        def user_token_revoke(self, db, uid):
            with db:
                return db.execute("DELETE FROM user_tokens WHERE user_id=?", (uid,)).rowcount > 0

        def _user_auth(self, db, ip, token):
            bad = self.ip_hits[("userbad", ip)]
            t = time.time()
            while bad and bad[0] < t - 60:
                bad.popleft()
            if len(bad) >= 20:
                raise ApiError(429, "توکن اشتباه زیاد فرستادی؛ یه دقیقه صبر کن")
            row, m = None, USER_TOKEN_RE.fullmatch(str(token or ""))
            if m:
                row = db.execute("SELECT t.token_hash, u.id, u.username, u.display_name, u.banned, u.is_bot FROM user_tokens t "
                                 "JOIN users u ON u.id=t.user_id WHERE t.user_id=?", (int(m.group(1)),)).fetchone()
                good = hashlib.sha256(m.group(2).encode()).digest()
                if row and (row["banned"] or row["is_bot"] or not hmac.compare_digest(good, bytes(row["token_hash"]))):
                    row = None
            if row is None:
                bad.append(t)
                raise ApiError(401, "توکن نامعتبره")
            if not self._room_hits(("userapi", row["id"]), 150, 10):
                raise ApiError(429, "درخواست‌های خیلی زیاد؛ کمی صبر کن")
            return row

        @staticmethod
        def _api_run(fn):
            try:
                return 200, {"ok": True, "result": fn()}
            except ApiError as e:
                return e.code, {"ok": False, "error_code": e.code, "description": e.desc}
            except Fail as e:
                return 400, {"ok": False, "error_code": 400, "description": str(e)}
            except Exception as e:
                log("api error:", repr(e))
                return 500, {"ok": False, "error_code": 500, "description": "خطای داخلی سرور"}

        def _api_dispatch(self, prefix, method, authfn, p, raw):
            db = None
            try:
                db = common.connect_db(self.db_path)
                who = authfn(db)
                handler = getattr(self, prefix + method, None) if re.fullmatch(r"[A-Za-z]{3,40}", method or "") else None
                if handler is None:
                    raise ApiError(404, f"متد {method} وجود نداره")
                return self._api_run(lambda: handler(db, who, dict(p or {}), raw))
            except ApiError as e:
                return e.code, {"ok": False, "error_code": e.code, "description": e.desc}
            except Exception as e:
                log("api error:", repr(e))
                return 500, {"ok": False, "error_code": 500, "description": "خطای داخلی سرور"}
            finally:
                if db is not None:
                    db.close()

        def user_api(self, ip, token, method, p, raw=None):
            return self._api_dispatch("_uapi_", method, lambda db: self._user_auth(db, ip, token), p, raw)

        def admin_api(self, peer, key, action, p, raw=None):
            def auth(db):
                ok = peer in LOCAL and key and hmac.compare_digest(str(key).encode(), self.admin_key.encode())
                if not ok:
                    raise ApiError(403, "دسترسی مدیر فقط از همین کامپیوتر و با کلید data/admin.key ممکنه")
                return None
            return self._api_dispatch("_admin_", action, auth, p, raw)

        # ============================================================ helpers
        @staticmethod
        def _clean_text(text):
            text = _CTRL.sub("", str(text or "").replace("\r\n", "\n")).strip()
            if len(text) > common.MAX_TEXT:
                raise Fail(f"متن خیلی طولانیه (حداکثر {common.MAX_TEXT} کاراکتر)")
            return text

        @staticmethod
        def _file_bytes(p, raw, limit):
            data = raw
            if data is None:
                b64 = p.get("file_base64") or p.get("file")
                if not b64:
                    raise Fail("فایل داده نشده؛ بدنه‌ی خام یا file_base64 بفرست")
                try:
                    data = base64.b64decode(str(b64), validate=True)
                except (binascii.Error, ValueError):
                    raise Fail("file_base64 معتبر نیست")
            if not data:
                raise Fail("فایل خالیه")
            if len(data) > limit:
                raise Fail(f"حجم فایل بیشتر از {limit // (1024 * 1024)} مگابایته")
            if not common.disk_ok(len(data)):
                raise ApiError(507, "فضای دیسک سرور تقریباً پره")
            return data

        def _voice_from(self, p, fname):
            if str(p.get("voice") or "").lower() not in ("1", "true", "yes"):
                return None
            try:
                dur = float(p.get("duration") or 0)
            except (TypeError, ValueError):
                dur = 0.0
            return self._voice_meta(fname, {"dur": dur, "wave": ""})

        # ============================================================ user API
        def _uapi_getMe(self, db, me, p, raw):
            return {"id": me["id"], "is_bot": False, "username": me["username"], "first_name": me["display_name"]}

        def _uapi_getChats(self, db, me, p, raw):
            rows = db.execute("SELECT chat_id FROM members WHERE user_id=? ORDER BY chat_id LIMIT 500", (me["id"],)).fetchall()
            return [self._bot_chat_json(db, r["chat_id"], me["id"]) for r in rows]

        def _uapi_getMessages(self, db, me, p, raw):
            chat_id, _ = self._require_member(db, p.get("chat_id"), me["id"])
            limit = max(1, min(self._pint(p, "limit", False) or 30, 100))
            before = self._pint(p, "before_id", False)
            sql, args = ("SELECT m.*, u.display_name AS sender_name FROM messages m LEFT JOIN users u ON u.id=m.sender_id "
                         "WHERE m.chat_id=? AND m.deleted=0"), [chat_id]
            if before:
                sql += " AND m.id<?"
                args.append(before)
            rows = db.execute(sql + " ORDER BY m.id DESC LIMIT ?", args + [limit]).fetchall()
            return [self._bot_msg_json(db, self._msg(db, r), me["id"]) for r in reversed(rows)]

        def _uapi_getUpdates(self, db, me, p, raw):
            offset = self._pint(p, "offset", False) or 0
            limit = max(1, min(self._pint(p, "limit", False) or 50, 100))
            wait = max(0, min(self._pint(p, "timeout", False) or 0, 25))
            base = ("SELECT m.*, u.display_name AS sender_name FROM messages m LEFT JOIN users u ON u.id=m.sender_id "
                    "JOIN members mb ON mb.chat_id=m.chat_id AND mb.user_id=? WHERE m.deleted=0 AND m.sender_id!=?")
            end = time.time() + wait
            while True:
                if offset > 0:
                    rows = db.execute(base + " AND m.id>=? ORDER BY m.id ASC LIMIT ?", (me["id"], me["id"], offset, limit)).fetchall()
                else:                               # offset 0 / -1: the newest messages (-1 = just the last one)
                    n = 1 if offset == -1 else limit
                    rows = list(reversed(db.execute(base + " ORDER BY m.id DESC LIMIT ?", (me["id"], me["id"], n)).fetchall()))
                if rows or time.time() >= end:
                    return [{"update_id": r["id"], "message": self._bot_msg_json(db, self._msg(db, r), me["id"])} for r in rows]
                time.sleep(1)

        def _user_send(self, db, me, p, text, fname=None, data=None, meta=None):
            chat_id, _ = self._require_member(db, p.get("chat_id"), me["id"])
            self._check_send_rate(me["id"])
            msg = self._store_message(db, me["id"], chat_id, self._clean_text(text), self._pint(p, "reply_to_message_id", False),
                                      fname, raw=data, meta=meta)
            self._announce(db, chat_id, msg, me["id"])
            return self._bot_msg_json(db, msg, me["id"])

        def _uapi_sendMessage(self, db, me, p, raw):
            return self._user_send(db, me, p, p.get("text"))

        def _uapi_sendDocument(self, db, me, p, raw):
            data = self._file_bytes(p, raw, BOT_MAX_FILE)
            fname = self._safe_filename(p.get("file_name") or p.get("filename") or "file")
            return self._user_send(db, me, p, p.get("caption"), fname, data, self._voice_from(p, fname))

        _uapi_sendPhoto = _uapi_sendVideo = _uapi_sendAudio = _uapi_sendDocument

        def _uapi_sendVoice(self, db, me, p, raw):
            p["voice"] = "1"
            p.setdefault("file_name", "voice.ogg")
            return self._uapi_sendDocument(db, me, p, raw)

        # ============================================================ admin API (datasheet)
        def _admin_announce(self, db, _w, p, raw):
            """Post to the announcements channel as the admin account: text and/or any file (photo, video, audio, voice, document)."""
            name = os.environ.get("TEEGRAM_ADMIN", "teegram").strip().lower()
            admin = db.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE AND is_bot=0", (name,)).fetchone()
            if not admin:
                raise Fail(f"حساب مدیر «{name}» هنوز ثبت‌نام نکرده؛ اول با همین نام کاربری ثبت‌نام کن")
            cid = self._ensure_channel(db)
            text = self._clean_text(p.get("text"))
            ids = []
            if raw is not None or p.get("file_base64"):
                data = self._file_bytes(p, raw, common.MAX_FILE)
                fname = self._safe_filename(p.get("file_name") or "file")
                caption = text if len(text) <= 300 else ""
                msg = self._store_message(db, admin["id"], cid, caption, None, fname, raw=data, meta=self._voice_from(p, fname))
                self._announce(db, cid, msg, admin["id"])
                ids.append(msg["id"])
                text = "" if caption else text
            if text:
                msg = self._store_message(db, admin["id"], cid, text, None)
                self._announce(db, cid, msg, admin["id"])
                ids.append(msg["id"])
            if not ids:
                raise Fail("پیام خالیه")
            return {"chat_id": cid, "message_ids": ids}

        def _find_chat(self, db, target):
            """group/channel by numeric id, public @username, or (part of) the title; must be unambiguous."""
            t = str(target or "").strip()
            if not t:
                raise Fail("شناسه، @نام‌کاربری یا اسم گروه/کانال رو بنویس")
            base = "SELECT id, title, username, kind FROM chats WHERE kind!='private' AND "
            rows = []
            if t.isdigit():
                rows = db.execute(base + "id=?", (int(t),)).fetchall()
            if not rows:
                rows = db.execute(base + "username=? COLLATE NOCASE", (t.lstrip("@"),)).fetchall()
            if not rows:
                rows = db.execute(base + "instr(title, ?) > 0 LIMIT 6", (t,)).fetchall()
            if not rows:
                raise Fail("گروه یا کانالی پیدا نشد")
            if len(rows) > 1:
                raise Fail("چند مورد پیدا شد؛ شناسه‌ی عددی بنویس: " + " | ".join(f"{r['id']}={r['title']}" for r in rows))
            return rows[0]

        def _admin_setBadge(self, db, _w, p, raw):
            """kind 'user' (users and bots, by username) or 'chat' (group/channel); badge: 0 = remove, 1 = blue, 2 = yellow."""
            try:
                badge = int(p.get("badge") or 0)
            except (TypeError, ValueError):
                badge = -1
            if badge not in (0, 1, 2):
                raise Fail("badge باید ۰ (حذف)، ۱ (آبی) یا ۲ (زرد) باشه")
            if p.get("kind") == "chat":
                row = self._find_chat(db, p.get("target") or p.get("username"))
                with db:
                    db.execute("UPDATE chats SET badge=? WHERE id=?", (badge, row["id"]))
                if badge:
                    self._cbadges[row["id"]] = badge
                else:
                    self._cbadges.pop(row["id"], None)
                self._push_chat_update(db, row["id"])
                return {"kind": "chat", "id": row["id"], "name": row["title"], "badge": badge}
            name = str(p.get("username") or p.get("target") or "").strip().lstrip("@")
            row = db.execute("SELECT id, username FROM users WHERE username=? COLLATE NOCASE", (name,)).fetchone()
            if not row:
                raise Fail("کاربر/ربات با این نام کاربری پیدا نشد")
            with db:
                db.execute("UPDATE users SET badge=? WHERE id=?", (badge, row["id"]))
            if badge:
                self._badges[row["id"]] = badge
            else:
                self._badges.pop(row["id"], None)
            self._broadcast_profile(db, row["id"])
            return {"kind": "user", "id": row["id"], "name": row["username"], "badge": badge}

        def _admin_badgeList(self, db, _w, p, raw):
            out = [{"kind": "ربات" if r["is_bot"] else "کاربر", "name": "@" + r["username"], "badge": r["badge"]}
                   for r in db.execute("SELECT username, badge, is_bot FROM users WHERE badge>0 ORDER BY badge, username")]
            out += [{"kind": "کانال" if (r["channel"] or r["chan"]) else "گروه", "name": r["title"] or f"#{r['id']}", "badge": r["badge"]}
                    for r in db.execute("SELECT id, title, badge, channel, chan FROM chats WHERE badge>0 AND kind!='private' ORDER BY badge, id")]
            return out

        def _admin_botfatherGet(self, db, _w, p, raw):
            u = db.execute("SELECT username, display_name, bio FROM users WHERE id=?", (self.botfather_id,)).fetchone()
            return {"username": u["username"], "display_name": u["display_name"], "bio": u["bio"],
                    "description": self._bot_info(db, self.botfather_id)["description"]}

        def _admin_botfatherSet(self, db, _w, p, raw):
            uid = self.botfather_id
            with db:
                if "display_name" in p:
                    name = _CTRL.sub("", str(p["display_name"])).strip()
                    if not 1 <= len(name) <= 40:
                        raise Fail("اسم باید ۱ تا ۴۰ حرف باشه")
                    db.execute("UPDATE users SET display_name=? WHERE id=?", (name, uid))
                if "bio" in p:
                    db.execute("UPDATE users SET bio=? WHERE id=?", (_CTRL.sub("", str(p["bio"])).strip()[:200], uid))
                if "description" in p:
                    db.execute("UPDATE bots SET description=? WHERE user_id=?", (_CTRL.sub("", str(p["description"])).strip()[:200], uid))
            self._broadcast_profile(db, uid)
            return self._admin_botfatherGet(db, None, p, raw)

        def _admin_botfatherPhoto(self, db, _w, p, raw):
            if not raw:
                raise Fail("عکس داده نشده")
            if len(raw) > common.MAX_AVATAR:
                raise Fail("حجم عکس زیاده")
            self.set_user_avatar(db, self.botfather_id, raw)
            self._broadcast_profile(db, self.botfather_id)
            return True

    return AdminApiMixin
