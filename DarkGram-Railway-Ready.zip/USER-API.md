# API حساب شخصی (User API)

مثل Bot API است، ولی با **حساب خودت** کار می‌کند (نه با یک ربات).

## گرفتن توکن
در برنامه به ربات رسمی **ApiFather** (`@ApiFather`) پیام بده: `/token` (توکن تازه؛ توکن قبلی باطل می‌شه) و برای باطل‌کردن: `/revoke`.
(همین کار از BotFather هم با `/usertoken` و `/revokeusertoken` ممکنه.)
توکن به حساب شخصی‌ات دسترسی کامل می‌ده؛ جایی منتشرش نکن.

## آدرس
`https://آدرس-سرور/user<TOKEN>/<متد>`   (TOKEN مثل `12:AbCd…` است)

درخواست `GET` یا `POST` (بدنه‌ی JSON، فرم، یا بدنه‌ی خام برای فایل). پاسخ: `{"ok":true,"result":…}`

| متد | پارامترها | نتیجه |
|---|---|---|
| `getMe` | — | مشخصات حساب |
| `getChats` | — | لیست چت‌های تو |
| `getMessages` | `chat_id` [`limit` ≤۱۰۰] [`before_id`] | پیام‌های چت (قدیمی → جدید) |
| `getUpdates` | [`offset`] [`limit`] [`timeout` ≤۲۵] | پیام‌های تازه‌ی دیگران؛ `offset=-1` فقط آخرین پیام؛ بعدش `offset = آخرین update_id + 1` |
| `sendMessage` | `chat_id` `text` [`reply_to_message_id`] | پیام فرستاده‌شده |
| `sendDocument` / `sendPhoto` / `sendVideo` / `sendAudio` | `chat_id` `file_name` [`caption`] + فایل (بدنه‌ی خام یا `file_base64`) | پیام |
| `sendVoice` | مثل بالا + [`duration`] | پیام صوتی |

حداکثر حجم فایل ۲۰ مگابایت. تو کانال اطلاعیه‌ها فقط مدیر می‌تونه بنویسه. حدود ۱۵۰ درخواست در ۱۰ ثانیه.

## نمونه
```python
import json, urllib.request
BASE = "https://آدرس-سرور/user12:TOKEN/"
def call(m, **p):
    r = urllib.request.Request(BASE + m, json.dumps(p).encode(), {"Content-Type": "application/json"})
    return json.load(urllib.request.urlopen(r, timeout=60))["result"]

print(call("getMe"))
for chat in call("getChats"):
    print(chat)
call("sendMessage", chat_id=5, text="سلام از API!")
```

# API مدیر (برای پنل دیتاشیت)
`/admin/<action>` فقط از **همین کامپیوتر** (127.0.0.1) و با هدر `X-Admin-Key` (محتوای `data/admin.key`) کار می‌کنه.
`announce` (متن و/یا فایل به کانال اطلاعیه‌ها) · `botfatherGet` · `botfatherSet` · `botfatherPhoto`.
کلید رو به کسی نده. پنل دیتاشیت دکمه‌ی «📣 اطلاعیه و BotFather» دارد که همین را صدا می‌زند.


# تیک آبی و زرد
در دیتاشیت: «📣 اطلاعیه و BotFather» ← تب «✔ تیک آبی/زرد»؛ نوع (کاربر/ربات یا گروه/کانال) و هدف رو بنویس و آبی، زرد یا حذف رو بزن.
هدف برای گروه/کانال: @نام‌کاربری عمومی، شناسه‌ی عددی، یا بخشی از اسم. BotFather و ApiFather به‌طور پیش‌فرض تیک آبی دارن.
API مدیر: `setBadge` (`kind`: user | chat، `target`، `badge`: ۰ حذف، ۱ آبی، ۲ زرد) و `badgeList`.
