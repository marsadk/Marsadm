# DarkGram Web — Railway deployment

This package contains the web server source from the supplied project. It excludes the original data directory and Android assets.

## Deploy
1. Upload the contents of this ZIP to the root of a GitHub repository.
2. In Railway choose New Project → Deploy from GitHub Repo and select that repository. Railway uses the included Dockerfile and railway.json.
3. In the Railway service add a Volume mounted at `/app/data`.
4. Add variables (choose your own unique usernames before anyone registers):
   - `TEEGRAM_ADMIN`: your admin username (default `teegram`)
   - `TEEGRAM_ADMINS`: comma-separated admin usernames (include the same admin username)
   - `TEEGRAM_OWNER`: owner badge username (default in source is `Reza_id_tell`; set this to your own username)
5. Generate a public domain in Settings → Networking.

The container listens on Railway's `$PORT` via the included Dockerfile. Railway terminates HTTPS; the app uses HTTP internally. Persistent user data is stored under `/app/data`, so the Volume is important.
