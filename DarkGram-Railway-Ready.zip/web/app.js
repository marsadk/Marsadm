'use strict';
/* Teegram web client. Safe DOM building only (no innerHTML with user data). */
const QUESTIONS=["یه کلمه یا جمله مخفی که فقط خودم می‌دونم","اسم اولین کتابی که یادمه و خوندمش؟","اسم کوچه یا جایی که برای من خاطره خاصی داره؟","یه عبارت شخصی که هیچ‌وقت جایی نگفتم؟"];
const RULES_DEFAULT=`قوانین و شرایط استفاده از دارک گرام

استفاده از دارک گرام به معنای پذیرش کامل این قوانین است. در صورت عدم موافقت با هر یک از مفاد زیر، لطفاً از این سرویس استفاده نکنید.

۱. کلیات
۱.۱. دارک گرام یک سرویس پیام‌رسان برای ارتباط میان کاربران است و استفاده از آن منوط به رعایت این قوانین است.
۱.۲. دارک گرام می‌تواند در هر زمان این قوانین را به‌روزرسانی کند؛ ادامه استفاده از سرویس پس از انتشار نسخه جدید، به معنای پذیرش آن خواهد بود.

۲. حساب کاربری
۲.۱. هر کاربر مسئول حفظ محرمانگی رمز عبور و پاسخ سؤال امنیتی حساب خویش است.
۲.۲. جعل هویت اشخاص دیگر یا استفاده از حساب کاربری دیگران ممنوع است.
۲.۳. مسئولیت تمامی فعالیت‌هایی که از طریق یک حساب کاربری انجام می‌شود، بر عهده صاحب آن حساب است.

۳. رفتار و محتوای ممنوع
۳.۱. توهین، تهدید، آزار و اذیت یا ایجاد مزاحمت برای سایر کاربران ممنوع است.
۳.۲. انتشار محتوای غیرقانونی، مستهجن یا خشونت‌آمیز و همچنین هرگونه محتوای فریبنده یا کلاهبرداری ممنوع است.
۳.۳. ارسال پیام‌های انبوه و تبلیغات ناخواسته (اسپم) برای کاربران ناآشنا ممنوع است.
۳.۴. انتشار اطلاعات شخصی دیگران بدون رضایت آنان ممنوع است.

۴. مسئولیت محتوا
۴.۱. مسئولیت کامل پیام‌ها، فایل‌ها و محتوایی که هر کاربر ارسال می‌کند، بر عهده خود اوست.
۴.۲. دارک گرام در قبال محتوای منتشرشده توسط کاربران، گروه‌ها و کانال‌ها مسئولیتی بر عهده ندارد.

۵. اقدامات اجرایی
۵.۱. دارک گرام حق دارد در صورت نقض این قوانین، بدون اطلاع قبلی، محتوای ناقض را حذف و دسترسی حساب، گروه یا کانال متخلف را محدود یا مسدود کند.
۵.۲. تصمیم دارک گرام در خصوص نحوه اجرای این قوانین قطعی است.

۶. امنیت حساب
۶.۱. رمز عبور و پاسخ سؤال امنیتی خود را با هیچ شخصی به اشتراک نگذارید؛ دارک گرام هرگز این اطلاعات را از شما درخواست نخواهد کرد.
۶.۲. در صورت فراموشی رمز عبور، بازیابی حساب تنها از طریق پاسخ سؤال امنیتی امکان‌پذیر است.`;
async function rulesText(){try{const r=await fetch('/rules.txt',{cache:'no-store'});if(r.ok){const t=(await r.text()).trim();if(t)return t}}catch{}return RULES_DEFAULT}
async function showRules(){const t=await rulesText();dialog('قوانین',h('div',{style:'white-space:pre-wrap;line-height:2;font-size:14px;max-height:60vh;overflow:auto'},t),h('button',{class:'btn',style:'display:block;margin-top:12px;width:100%',onclick:closeDialog},'متوجه شدم'))}
const EMOJIS=["😀","😁","😂","🤣","😊","😍","😘","😎","🤔","😢","😭","😡","👍","👎","👏","🙏","💪","🔥","❤️","💔","🎉","✨","🌹","☕","🍕","🎂","🎁","✅","❌","⭐","🚀","🌙","☀️","🌈","🐱","🐶","😴","🤝","👋","🙌","😉","😅","🥰","🤩","🥳","😇","😜","🤗","😏","😬","🙄","😤","🤯","😱","🥺","😋","🤪","🙈","💯","👀","🫶","🤞","✌️","💙","💜","🖤","💥","🎶","🍔","⚽","🏆","🌍","💡","📌","📎","🫠","🫡","🫢","🫣","🥹","🫥","🫤","😶‍🌫️","🥴","🤠","🦊","🐼","🐸","🦁","🐯","🐷","🐙","🦋","🌸","🌻","🍓","🍇","🍩","🍿","🧋","🎧","🎮","🏀","🚗","✈️","🏝️","🎸","🎬","📸","💎","👑","🔮","🧲","🎯","🏅","🍀","🌚","🪐","🍉","🥑","🍦","🎨","🛼","🐳","🦄","🍒","🥝","🔔","💸","📚","✏️","❤️‍🔥","💫","🫧"];
const STICKERS=["🔥", "❤️", "😂", "🥰", "😎", "🤯", "🥳", "👍", "👎", "💯", "⭐", "🌙", "🐻", "🦊", "🐸", "🍕", "⚽", "🎉", "🙏", "😴", "🤔", "😱", "👀", "💩", "🚀", "🎧", "🍓", "🐱"];
const REACTS=["👍", "❤️", "🔥", "🎉", "😂", "😮", "😢", "🙏", "👎", "💯", "🤔", "👏", "⭐", "🥰", "🤩", "🥳", "😍", "🤣", "👌", "🕊️", "😘", "😎", "🙌", "😁", "😅", "💙", "🤯", "🥺", "👀", "🫶"];
const COLORS=["#e17076","#7bc862","#e5ca77","#65aadd","#a695e7","#ee7aae","#6ec9cb","#faa774"];
const ACCENTS=["#3390ec","#7c4dff","#e91e63","#f4511e","#2e9e55","#00acc1","#8d6e63","#455a64"];
const USER_RE=/^(?=.*[A-Za-z0-9])[A-Za-z0-9_]{3,32}$/;
const $=(s,r=document)=>r.querySelector(s);

/* ---------- icons ---------- */
const IC={menu:"S:M4 6.5h16M4 12h16M4 17.5h16",search:"S:M11 5a6 6 0 1 0 0 12 6 6 0 0 0 0-12zM15.4 15.4L19.9 19.9",
pencil:"S:M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z",
send:"M21.9 4.6l-3.1 14.6c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.3.3-.5.5-1 .5l.4-4.9L18.9 6c.4-.3-.1-.5-.6-.2L7.2 12.7 2.4 11.2c-1-.3-1.1-1 .2-1.5l18.8-7.2c.9-.3 1.6.2 1.5 1.1z",mic:"S:M12 14.8a2.9 2.9 0 0 0 2.9-2.9V6.4a2.9 2.9 0 0 0-5.8 0v5.5A2.9 2.9 0 0 0 12 14.8zM6.1 11.3a5.9 5.9 0 0 0 11.8 0M12 17.9V21M8.9 21h6.2",
attach:"S:M20.9 11.9l-8.9 8.9a6.2 6.2 0 0 1-8.8-8.8l9-9a4.4 4.4 0 0 1 6.2 6.2l-8.8 8.8a3.1 3.1 0 0 1-4.4-4.4l8.3-8.3",
emoji:"S:M12 4.2a7.8 7.8 0 1 0 0 15.6 7.8 7.8 0 0 0 0-15.6zM8.7 14.1a4.8 4.8 0 0 0 6.6 0M9.2 9.9h.01M14.8 9.9h.01",
phone:"S:M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.08 4.18 2 2 0 0 1 4.06 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z",
more:"M12 5.4a1.9 1.9 0 1 0 0 3.8 1.9 1.9 0 0 0 0-3.8zM12 10.1a1.9 1.9 0 1 0 0 3.8 1.9 1.9 0 0 0 0-3.8zM12 14.8a1.9 1.9 0 1 0 0 3.8 1.9 1.9 0 0 0 0-3.8z",
back:"S:M4.5 12h15M13.3 5.8l6.2 6.2-6.2 6.2",close:"S:M6 6l12 12M18 6L6 18",
check:"S:M5 12.8l4.6 4.6L19 7.6",checkall:"S:M2.6 13.2l4 4L15 8.8M12.4 17.2l1.3 1.3 7.7-7.7M16.6 6.6l-4.8 4.8",
reply:"S:M9.2 14.8L3.6 9.2 9.2 3.6M3.6 9.2h11a5.8 5.8 0 0 1 5.8 5.8v5.4",forward:"S:M14.8 14.8l5.6-5.6-5.6-5.6M20.4 9.2h-11A5.8 5.8 0 0 0 3.6 15v5.4",
copy:"S:M15.5 8.2V5.7A2.2 2.2 0 0 0 13.3 3.5H5.7A2.2 2.2 0 0 0 3.5 5.7v7.6a2.2 2.2 0 0 0 2.2 2.2h2.5M10.7 8.5h7.6a2.2 2.2 0 0 1 2.2 2.2v7.6a2.2 2.2 0 0 1-2.2 2.2h-7.6a2.2 2.2 0 0 1-2.2-2.2v-7.6a2.2 2.2 0 0 1 2.2-2.2z",
delete:"S:M4.5 6.8h15M10 6.5V5.2A1.4 1.4 0 0 1 11.4 3.8h1.2A1.4 1.4 0 0 1 14 5.2v1.3M6.8 6.8l.8 11.4a2 2 0 0 0 2 1.9h4.8a2 2 0 0 0 2-1.9l.8-11.4M10.2 10.6v5.6M13.8 10.6v5.6",pin:"S:M8.5 4h7M9.8 4v4.6L7.6 12a.8.8 0 0 0 .7 1.2h7.4a.8.8 0 0 0 .7-1.2L14.2 8.6V4M12 13.2V20",
download:"S:M12 4v10.4M7.5 10.7L12 15.2l4.5-4.5M4.8 19.8h14.4",file:"S:M13.5 3.5H7A1.8 1.8 0 0 0 5.2 5.3v13.4A1.8 1.8 0 0 0 7 20.5h10a1.8 1.8 0 0 0 1.8-1.8V9.2zM13.5 3.5v5.7h5.3",
play:"M8.2 5.4v13.2c0 .9 1 1.5 1.8 1L20 13a1.2 1.2 0 0 0 0-2L10 4.4c-.8-.5-1.8.1-1.8 1z",pause:"M6.8 5h3.2a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H6.8a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm7.2 0h3.2a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H14a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z",
group:"S:M9.8 10.8a3.1 3.1 0 1 0 0-6.2 3.1 3.1 0 0 0 0 6.2zM3.4 19.4c.6-3 3-4.6 6.4-4.6s5.8 1.6 6.4 4.6M15.7 4.9a3.1 3.1 0 0 1 0 5.9M17.9 15.2c1.7.7 2.8 2 3.2 4.2",
person:"S:M12 11a3.6 3.6 0 1 0 0-7.2A3.6 3.6 0 0 0 12 11zM5.2 19.8c.7-3.3 3.4-5 6.8-5s6.1 1.7 6.8 5",
bookmark:"M7 3.5h10A1.5 1.5 0 0 1 18.5 5v15.5L12 16.2l-6.5 4.3V5A1.5 1.5 0 0 1 7 3.5z",
settings:"S:M9.09 4.98L10.23 4.61L10.76 2.78L13.24 2.78L13.77 4.61L14.91 4.98L15.97 5.52L17.64 4.61L19.39 6.36L18.48 8.03L19.02 9.09L19.39 10.23L21.22 10.76L21.22 13.24L19.39 13.77L19.02 14.91L18.48 15.97L19.39 17.64L17.64 19.39L15.97 18.48L14.91 19.02L13.77 19.39L13.24 21.22L10.76 21.22L10.23 19.39L9.09 19.02L8.03 18.48L6.36 19.39L4.61 17.64L5.52 15.97L4.98 14.91L4.61 13.77L2.78 13.24L2.78 10.76L4.61 10.23L4.98 9.09L5.52 8.03L4.61 6.36L6.36 4.61L8.03 5.52ZM12 15.3a3.3 3.3 0 1 0 0-6.6 3.3 3.3 0 0 0 0 6.6z",
moon:"M20.6 14.2A8.8 8.8 0 1 1 9.8 3.4a7.2 7.2 0 0 0 10.8 10.8z",
logout:"S:M13.5 4.2H7A1.7 1.7 0 0 0 5.3 5.9v12.2A1.7 1.7 0 0 0 7 19.8h6.5M10.8 12h9.7M17.3 8.4l3.6 3.6-3.6 3.6",
down:"S:M5.5 9.5L12 16l6.5-6.5",up:"S:M5.5 14.5L12 8l6.5 6.5",
bellx:"S:M6.4 16v-5a5.6 5.6 0 0 1 11.2 0v5l1.3 2.8H5.1L6.4 16zM10.2 20.6a2 2 0 0 0 3.6 0M16.9 3.3l3.7 3.7M20.6 3.3l-3.7 3.7",
bell:"S:M6.4 16v-5a5.6 5.6 0 0 1 11.2 0v5l1.3 2.8H5.1L6.4 16zM10.2 20.6a2 2 0 0 0 3.6 0",
star:"M12 2.6l2.95 6.18 6.8.86-4.98 4.7 1.28 6.72L12 17.77l-6.05 3.29 1.28-6.72-4.98-4.7 6.8-.86z",
info:"S:M12 3.8a8.2 8.2 0 1 0 0 16.4A8.2 8.2 0 0 0 12 3.8zM12 11.2V16M12 7.9h.01",
camera:"S:M3.5 8.2A1.8 1.8 0 0 1 5.3 6.4h1.9L9 4h6l1.8 2.4h1.9a1.8 1.8 0 0 1 1.8 1.8V17a1.8 1.8 0 0 1-1.8 1.8H5.3A1.8 1.8 0 0 1 3.5 17V8.2zM12 15.6a3.3 3.3 0 1 0 0-6.6 3.3 3.3 0 0 0 0 6.6z",
devices:"S:M3 5.2A1.2 1.2 0 0 1 4.2 4h11.6A1.2 1.2 0 0 1 17 5.2v7.3a1.2 1.2 0 0 1-1.2 1.2H4.2A1.2 1.2 0 0 1 3 12.5zM8.5 17.5h7M12 13.7v3.8M16.8 11.5h3A1.2 1.2 0 0 1 21 12.7v6.6a1.2 1.2 0 0 1-1.2 1.2h-3a1.2 1.2 0 0 1-1.2-1.2v-6.6a1.2 1.2 0 0 1 1.2-1.2z",
video:"S:M14.5 6H5.8A2.3 2.3 0 0 0 3.5 8.3v7.4A2.3 2.3 0 0 0 5.8 18h8.7a2.3 2.3 0 0 0 2.3-2.3V8.3A2.3 2.3 0 0 0 14.5 6zM16.8 10.6l3.7-2.3v7.4l-3.7-2.3",
lock:"S:M6.8 11h10.4A1.8 1.8 0 0 1 19 12.8V19a1.8 1.8 0 0 1-1.8 1.8H6.8A1.8 1.8 0 0 1 5 19v-6.2A1.8 1.8 0 0 1 6.8 11zM8.2 11V7.8a3.8 3.8 0 0 1 7.6 0V11M12 14.6v2.6",
add:"S:M12 5v14M5 12h14",stop:"M8.2 6.3h7.6A1.7 1.7 0 0 1 17.5 8v7.6a1.7 1.7 0 0 1-1.7 1.7H8.2A1.7 1.7 0 0 1 6.5 15.6V8a1.7 1.7 0 0 1 1.7-1.7z",
channel:"M18.6 4.8v14.4a.9.9 0 0 1-1.4.7l-7.3-4.4H6.4A1.9 1.9 0 0 1 4.5 13.6v-3.2a1.9 1.9 0 0 1 1.9-1.9h3.5l7.3-4.4a.9.9 0 0 1 1.4.7zM7.6 15.3l-.3 3.6a2 2 0 0 0 4 .5l-.8-4.1z",
headphones:"S:M4.2 15.8v-3a7.8 7.8 0 0 1 15.6 0v3M4.2 13.6a1.8 1.8 0 0 1 1.8 1.8v2.8a1.8 1.8 0 0 1-1.8 1.8A1.8 1.8 0 0 1 2.4 18.2v-2.8a1.8 1.8 0 0 1 1.8-1.8zm15.6 0a1.8 1.8 0 0 1 1.8 1.8v2.8a1.8 1.8 0 0 1-1.8 1.8 1.8 1.8 0 0 1-1.8-1.8v-2.8a1.8 1.8 0 0 1 1.8-1.8z",
speaker:"S:M4 9.4v5.2h3.6L12 19V5L7.6 9.4zM15.6 9.4a3.7 3.7 0 0 1 0 5.2M18.2 7a7.4 7.4 0 0 1 0 10",
image:"S:M5 3.5h14A1.5 1.5 0 0 1 20.5 5v14a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 19V5A1.5 1.5 0 0 1 5 3.5zM9.3 10.2a1.9 1.9 0 1 0 0-3.8 1.9 1.9 0 0 0 0 3.8zM3.8 17.8l4.7-4.7 3.2 3.2 4.3-4.3 4.2 4.2"};
IC.skipprev="S:M6 5.5v13M18.5 5.6L9.2 12l9.3 6.4z";IC.skipnext="S:M18 5.5v13M5.5 5.6L14.8 12l-9.3 6.4z";
IC.archive="S:M4 5.5h16M5.5 5.5v12.5A1.5 1.5 0 0 0 7 19.5h10a1.5 1.5 0 0 0 1.5-1.5V5.5M10 12.3l2 2 2-2M12 10v4.3M9.5 8.5h5";
IC.chatb="M12.5 2.8h6.7a3.3 3.3 0 0 1 3.3 3.3v4.7a3.3 3.3 0 0 1-3.3 3.3h-.9v3.4c0 .6-.7.9-1.1.5l-2.9-2.1c-.3-.2-.6-.3-1-.3h-.8a3.3 3.3 0 0 1-3.3-3.3V6.1a3.3 3.3 0 0 1 3.3-3.3zM4.3 8.6h10.2a3.3 3.3 0 0 1 3.3 3.3v4.7a3.3 3.3 0 0 1-3.3 3.3H9.6l-4.4 3.3c-.4.3-1 0-1-.5v-2.9a3.3 3.3 0 0 1-3.2-3.3V11.9a3.3 3.3 0 0 1 3.3-3.3z";
IC.personf="M12 11.6a4.3 4.3 0 1 0 0-8.6 4.3 4.3 0 0 0 0 8.6zM12 13.8c-5 0-8.8 2.7-8.8 6.1 0 .9.7 1.7 1.7 1.7h14.2c.9 0 1.7-.7 1.7-1.7 0-3.4-3.8-6.1-8.8-6.1z";
IC.settingsf="M19.24 10.06L21.59 10.57L21.59 13.43L19.24 13.94L18.50 15.75L19.80 17.77L17.77 19.80L15.75 18.50L13.94 19.24L13.43 21.59L10.57 21.59L10.06 19.24L8.25 18.50L6.23 19.80L4.20 17.77L5.50 15.75L4.76 13.94L2.41 13.43L2.41 10.57L4.76 10.06L5.50 8.25L4.20 6.23L6.23 4.20L8.25 5.50L10.06 4.76L10.57 2.41L13.43 2.41L13.94 4.76L15.75 5.50L17.77 4.20L19.80 6.23L18.50 8.25zM8.9 12a3.1 3.1 0 1 0 6.2 0a3.1 3.1 0 1 0-6.2 0z";
function ic(n,size){const s=document.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('viewBox','0 0 24 24');s.setAttribute('class','i');
  if(size){s.style.width=s.style.height=size+'px'}const p=document.createElementNS('http://www.w3.org/2000/svg','path');let d=IC[n]||'';
  if(d.startsWith('S:')){d=d.slice(2);p.setAttribute('fill','none');p.setAttribute('stroke','currentColor');p.setAttribute('stroke-width','2');p.setAttribute('stroke-linecap','round');p.setAttribute('stroke-linejoin','round')}
  p.setAttribute('d',d);s.append(p);return s}
function setIcon(el,n,size){el.replaceChildren(ic(n,size))}
function applyChrome(){if(LANG!=='en')return;
  const bn={me:'Profile',chats:'Chats',contacts:'Contacts',settings:'Settings'};
  document.querySelectorAll('#bnav button').forEach(b=>{const t=bn[b.dataset.t];if(!t)return;const w=document.createTreeWalker(b,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){if(n.textContent.trim()){n.textContent=t;break}}});
  const si=$('#search');if(si)si.placeholder='Search';
  const inp=$('#input');if(inp)inp.placeholder='Message...'}

/* ---------- tiny helpers ---------- */
function h(tag,props={},...kids){
  const e=document.createElement(tag);
  for(const [k,v] of Object.entries(props||{})){
    if(v==null||v===false)continue;
    if(k==='class')e.className=v;else if(k==='style')e.style.cssText=v;
    else if(k.startsWith('on'))e.addEventListener(k.slice(2),v);
    else if(k==='value')e.value=v;else e.setAttribute(k,v===true?'':v);
  }
  for(const kid of kids.flat(Infinity)){if(kid==null||kid===false)continue;e.append(kid.nodeType?kid:document.createTextNode(String(kid)))}
  return e}
let LANG='fa';try{LANG=localStorage.getItem('wd-lang')||'fa'}catch(e){}
const L=(f,e)=>LANG==='en'?e:f;
function setLang(l){try{localStorage.setItem('wd-lang',l)}catch(e){}location.reload()}
if(LANG==='en'){document.documentElement.lang='en';document.documentElement.dir='ltr'}
const fa=s=>LANG==='en'?String(s):String(s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const short=(t,n)=>{t=String(t).replace(/\s+/g,' ').trim();return t.length>n?t.slice(0,n-1)+'…':t};
const dkey=ts=>{const d=new Date(ts*1000);return d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate()};
const fmtTime=ts=>fa(new Date(ts*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}));
const jdate=(ts,y=true)=>new Intl.DateTimeFormat(LANG==='en'?'en-US':'fa-IR-u-ca-persian',{day:'numeric',month:'long',...(y?{year:'numeric'}:{})}).format(new Date(ts*1000));
function dayDiff(ts){const a=new Date(ts*1000),b=new Date();a.setHours(0,0,0,0);b.setHours(0,0,0,0);return Math.round((b-a)/864e5)}
function dayLabel(ts){const d=dayDiff(ts);return d===0?'امروز':d===1?'دیروز':jdate(ts)}
function listTime(ts){const d=dayDiff(ts);return d===0?fmtTime(ts):d===1?'دیروز':d<7?new Intl.DateTimeFormat(LANG==='en'?'en-US':'fa-IR',{weekday:'long'}).format(new Date(ts*1000)):jdate(ts,false)}
const seenText=p=>p.bot?'ربات':p.online?'آنلاین':p.seen_hidden?'آخرین بازدید: به‌تازگی':'آخرین بازدید: '+lastSeen(p.last_seen);
function lastSeen(ts){if(!ts)return'مدت‌ها پیش';const d=dayDiff(ts);return d<=1?(d?'دیروز ':'امروز ')+fmtTime(ts):jdate(ts)}
const fmtSize=n=>n<1024?fa(n)+' B':n<1048576?fa((n/1024).toFixed(1))+' KB':fa((n/1048576).toFixed(1))+' MB';
const fmtDur=s=>{s=Math.max(0,Math.round(s||0));return fa(Math.floor(s/60)+':'+String(s%60).padStart(2,'0'))};
function strength(pw){let s=0;if(pw.length>=8)s++;if(pw.length>=12)s++;if(/[a-z]/.test(pw)&&/[A-Z]/.test(pw))s++;if(/\d/.test(pw))s++;if(/[^A-Za-z0-9]/.test(pw))s++;return pw?Math.min(s,4):0}
function pwError(pw,user){if(pw.length<8)return'رمز باید حداقل ۸ کاراکتر باشه';if(user&&pw.toLowerCase().includes(user.toLowerCase()))return'رمز نباید شامل نام کاربری باشه';
  if(/^\d+$/.test(pw)||/^[A-Za-z]+$/.test(pw))return'رمز باید ترکیبی از حرف و عدد (یا نماد) باشه';return null}
const lsGet=(k,d=null)=>{try{const v=localStorage.getItem(k);return v==null?d:v}catch{return d}};
const lsSet=(k,v)=>{try{v==null?localStorage.removeItem(k):localStorage.setItem(k,v)}catch{}};

/* ---------- text rendering: **bold** __italic__ ~~strike~~ `code` ```block``` ||spoiler|| links @mentions ---------- */
const INLINE=/(`[^`\n]+`|\*\*[^*\n]+\*\*|__[^_\n]+__|~~[^~\n]+~~|\|\|[^|\n]+\|\||https?:\/\/[^\s<>"']+|@[A-Za-z0-9_]{3,32})/;
function inline(str,out){
  for(const part of str.split(INLINE)){
    if(!part)continue;
    if(part[0]==='`'&&part.length>2)out.append(h('code',{},part.slice(1,-1)));
    else if(part.startsWith('**')&&part.length>4)out.append(h('b',{},inline2(part.slice(2,-2))));
    else if(part.startsWith('__')&&part.length>4)out.append(h('i',{},inline2(part.slice(2,-2))));
    else if(part.startsWith('~~')&&part.length>4)out.append(h('s',{},part.slice(2,-2)));
    else if(part.startsWith('||')&&part.length>4)out.append(h('span',{class:'spoiler',onclick:e=>{e.stopPropagation();e.currentTarget.classList.toggle('open')}},part.slice(2,-2)));
    else if(/^https?:\/\//.test(part)){let u=part,tail='';const m=u.match(/[.,;:!?)»]+$/);if(m){tail=m[0];u=u.slice(0,-tail.length)}
      const jr=parseJoinRef(u),gr=jr?null:parseGiftRef(u);
      if(jr)out.append(h('a',{href:u,onclick:e=>{e.preventDefault();e.stopPropagation();lsSet('wd-join',jr);handleJoin()}},u),tail);
      else if(gr)out.append(h('a',{href:u,onclick:e=>{e.preventDefault();e.stopPropagation();openGiftLink(gr)}},u),tail);
      else out.append(h('a',{href:u,target:'_blank',rel:'noopener noreferrer',onclick:e=>e.stopPropagation()},u),tail)}
    else if(part[0]==='@'&&USER_RE.test(part.slice(1)))out.append(h('span',{class:'mention',title:'دیدن پروفایل '+part,onclick:e=>{e.stopPropagation();openMention(part)}},part));
    else out.append(part)}}
function inline2(s){const f=document.createDocumentFragment();inline(s,f);return f}
const EMO_ONLY=/^(?:\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic}|[\u{1F3FB}-\u{1F3FF}])*\s*){1,3}$/u;
/* animated emojis (Telegram-style): each emoji gets its own looping animation when sent on its own */
const ANIM_EMOJI={'❤':'beat','🧡':'beat','💛':'beat','💚':'beat','💙':'beat','💜':'beat','🖤':'beat','🤍':'beat','💖':'beat','💗':'beat','💓':'beat','💕':'beat','💞':'beat','🔥':'flick','⚡':'flick','👍':'thumb','👏':'clap','🙌':'clap','😂':'laugh','🤣':'laugh','😍':'pulse','🥰':'pulse','😘':'pulse','🫶':'pulse','🎉':'party','🥳':'party','🎊':'party','⭐':'spin','🌟':'spin','💫':'spin','☀️':'spin','✨':'sparkle','💎':'sparkle','👑':'sparkle','🦄':'sparkle','👋':'wave','⚽':'bounce','🏀':'bounce','🐶':'bounce','🐱':'bounce','🍕':'bounce','🎈':'floaty','🫧':'floaty','😱':'shake','🤯':'shake','💔':'shake','🙏':'rock','🌹':'rock','🌙':'rock','🚀':'launch','🥺':'plead','🐳':'swim','🐬':'swim','😴':'zzz','💯':'zoom','🔔':'ring','🎶':'note','🎵':'note','🦋':'flutter','😮':'zoom','😢':'plead','👎':'thumb','🤔':'rock','🤩':'sparkle','👌':'pop','🕊':'flutter','😎':'pop','😁':'laugh','😅':'laugh','👀':'swim'};
const PREM_EMOJIS=["💎","👑","🦄","🔮","🪩","🧿","🏆","🥇","💠","🌟","🫧","🦚","🍭","🧸","🛸","🪐","🦋","🎠","🍩","🪄","💍","🔱","🦢","🎩"];
const PREM_SET=new Set(PREM_EMOJIS);
function emoGraphemes(s){try{return [...new Intl.Segmenter('fa',{granularity:'grapheme'}).segment(s)].map(x=>x.segment)}catch(e){return [...s]}}
function emoAnim(g){const base=g.replace(/[\uFE0F]|\u200D[\s\S]*$/gu,'');return ANIM_EMOJI[g]||ANIM_EMOJI[base]||(PREM_SET.has(g)?'sparkle':'pop')}
function stickerEl(m){const s=m.sticker;
  if(typeof s==='string'&&s.startsWith('cherry:'))return h('div',{class:'sticker'},h('img',{class:'stkimg',src:'/static/ch'+(s.split(':')[1]||'1')+'.webp',alt:'🍒'}));
  if(typeof s==='string'&&s.startsWith('user:'))return h('div',{class:'sticker'},h('img',{class:'stkimg',src:'/ustk/'+(s.split(':')[1]||'')+'?k='+encodeURIComponent(S.mediaKey||''),alt:'🧩'}));
  return h('div',{class:'sticker'},h('span',{class:'aemo a-'+emoAnim(s)},s))}
function bodyEl(m){
  const t=m.body||'';
  if(!m.file&&EMO_ONLY.test(t.trim())){
    const gs=emoGraphemes(t.trim()).filter(x=>x.trim());
    const d=h('div',{class:'text bigemo',dir:'auto',title:'بزن تا دوباره حرکت کنه'});
    gs.forEach(g=>d.append(h('span',{class:'aemo a-'+emoAnim(g)},g)));
    if(gs.length&&gs.every(g=>PREM_SET.has(g)))d.classList.add('prem');
    if(/[❤♥💖💗💓💕]/u.test(t))d.classList.add('heartmsg');
    d.onclick=e=>{e.stopPropagation();d.classList.remove('pop');void d.offsetWidth;d.classList.add('pop')};d.classList.add('pop');
    return d}
  return h('div',{class:'text',dir:'auto'},renderText(t))}
function renderText(text){
  const f=document.createDocumentFragment();
  text.split(/(```[\s\S]*?```)/).forEach(seg=>{
    if(seg.startsWith('```')&&seg.endsWith('```')&&seg.length>6)f.append(h('pre',{},seg.slice(3,-3).replace(/^\n/,'')));
    else inline(seg,f)});
  return f}

/* ---------- appearance settings ---------- */
const PREF={get accent(){return lsGet('wd-accent',ACCENTS[0])},get sound(){return lsGet('wd-sound','1')==='1'},get notif(){return lsGet('wd-notif','1')==='1'},get size(){return +lsGet('wd-size','15')}};
function applyAccent(c){const r=document.documentElement.style;r.setProperty('--accent',c);r.setProperty('--accent-d',c);
  const n=parseInt(c.slice(1),16);r.setProperty('--accent-soft',`rgba(${n>>16},${(n>>8)&255},${n&255},.14)`);
  const m=document.querySelector('meta[name=theme-color]');if(m)m.content=c;lsSet('wd-accent',c)}
const THEME_VARS=['--bg','--bg2','--panel','--hdr','--hover','--text','--muted','--border','--in','--in-t','--out','--out-t','--out-meta','--wall1','--wall2','--link','--shadow'];
const THEMES=[
 {id:'midnight',name:'🌌 شب مشکی',en:'Midnight',base:'dark',accent:'#3390ec',v:{'--bg':'#0e1621','--bg2':'#0a121b','--panel':'#17212b','--hdr':'#17212b','--hover':'#1e2c3a','--text':'#ffffff','--muted':'#7f91a4','--border':'#0d1720','--in':'#182533','--in-t':'#ffffff','--out':'#2b5278','--out-t':'#ffffff','--out-meta':'#8db8dd','--wall1':'#0e1621','--wall2':'#0e1621','--link':'#5aa2e0','--shadow':'0 2px 12px rgba(0,0,0,.45)'}},
 {id:'sunset',name:'🌇 غروب',en:'Sunset',base:'dark',accent:'#ff7a45',v:{'--bg':'#241021','--bg2':'#1a0b18','--panel':'#33172c','--hdr':'#33172c','--hover':'#422037','--text':'#fff5f0','--muted':'#cf9db4','--border':'#1c0816','--in':'#3a1c31','--in-t':'#ffffff','--out':'#93395f','--out-t':'#ffffff','--out-meta':'#f2bcd2','--wall1':'#47143a','--wall2':'#180a20','--link':'#ffa07a','--shadow':'0 2px 12px rgba(0,0,0,.45)'}},
 {id:'ocean',name:'🌊 اقیانوس',en:'Ocean',base:'dark',accent:'#22b8cf',v:{'--bg':'#07222e','--bg2':'#051923','--panel':'#0b3040','--hdr':'#0b3040','--hover':'#0f3f53','--text':'#eefcff','--muted':'#90bccb','--border':'#041a24','--in':'#0d3648','--in-t':'#ffffff','--out':'#10677f','--out-t':'#ffffff','--out-meta':'#a9dfec','--wall1':'#083650','--wall2':'#031520','--link':'#4dd0e1','--shadow':'0 2px 12px rgba(0,0,0,.45)'}},
 {id:'emerald',name:'🌲 زمرد',en:'Emerald',base:'dark',accent:'#2fbf71',v:{'--bg':'#09231a','--bg2':'#061a12','--panel':'#0e3323','--hdr':'#0e3323','--hover':'#13452e','--text':'#f2fff8','--muted':'#97c2ab','--border':'#05170f','--in':'#113a26','--in-t':'#ffffff','--out':'#177245','--out-t':'#ffffff','--out-meta':'#abe3c3','--wall1':'#0b3d27','--wall2':'#04170e','--link':'#4ade80','--shadow':'0 2px 12px rgba(0,0,0,.45)'}},
 {id:'galaxy',name:'🔮 کهکشانی',en:'Galaxy',base:'dark',accent:'#a06bff',v:{'--bg':'#170d33','--bg2':'#110826','--panel':'#211347','--hdr':'#211347','--hover':'#2c1b5c','--text':'#f7f3ff','--muted':'#ac9ad9','--border':'#0e0621','--in':'#261751','--in-t':'#ffffff','--out':'#52308f','--out-t':'#ffffff','--out-meta':'#d2c2f7','--wall1':'#2a1258','--wall2':'#0e0621','--link':'#bda2ff','--shadow':'0 2px 12px rgba(0,0,0,.45)'}},
 {id:'rose',name:'🌹 رز',en:'Rose',base:'dark',accent:'#f2789f',v:{'--bg':'#2a0e15','--bg2':'#1f0a10','--panel':'#3a131e','--hdr':'#3a131e','--hover':'#4a1a28','--text':'#fff5f7','--muted':'#d6a3af','--border':'#1a060b','--in':'#421824','--in-t':'#ffffff','--out':'#8a2c44','--out-t':'#ffffff','--out-meta':'#f6c3cf','--wall1':'#471524','--wall2':'#180409','--link':'#ffa4bc','--shadow':'0 2px 12px rgba(0,0,0,.45)'}},
 {id:'arctic',name:'❄️ یخی',en:'Arctic',base:'light',accent:'#3390ec',v:{'--bg':'#e8f0f8','--bg2':'#dbe7f2','--panel':'#ffffff','--hdr':'#ffffff','--hover':'#edf3f9','--text':'#132a3d','--muted':'#5d7d90','--border':'#cfdfeb','--in':'#ffffff','--in-t':'#132a3d','--out':'#b9e7c6','--out-t':'#10301b','--out-meta':'#4f8262','--wall1':'#cfe7f8','--wall2':'#e8f6ec','--link':'#1f7ae0','--shadow':'0 2px 12px rgba(31,68,104,.16)'}},
 {id:'cream',name:'🍯 کرمی',en:'Cream',base:'light',accent:'#e8913a',v:{'--bg':'#f8efdb','--bg2':'#f2e5cb','--panel':'#fffaf0','--hdr':'#fffaf0','--hover':'#fbf2df','--text':'#3b2b16','--muted':'#9a825e','--border':'#ecdfc2','--in':'#ffffff','--in-t':'#3b2b16','--out':'#ffd9a1','--out-t':'#4d3008','--out-meta':'#9c742f','--wall1':'#fdeeda','--wall2':'#fdf6e0','--link':'#cf7a1c','--shadow':'0 2px 12px rgba(120,84,20,.15)'}}];
function applyTheme2(id){const t=THEMES.find(x=>x.id===id),r=document.documentElement.style;
  if(!t){THEME_VARS.forEach(k=>r.removeProperty(k));lsSet('wd-theme2','');return}
  Object.entries(t.v).forEach(([k,val])=>r.setProperty(k,val));
  document.documentElement.dataset.theme=t.base;lsSet('wd-theme',t.base);lsSet('wd-theme2',id);applyAccent(t.accent);syncBar()}
function clearTheme2(){applyTheme2('')}
function syncBar(){try{if(window.WD&&WD.setBar){const d=document.documentElement.dataset.theme==='dark';WD.setBar(d?'#181818':'#ffffff',d)}}catch{}}
function setTheme(t){const v=t==='light'?'light':'dark';document.documentElement.dataset.theme=v;lsSet('wd-theme',v);syncBar()}
function toggleTheme(){setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark')}
const WALLS=[['پیش‌فرض',''],['شب','linear-gradient(160deg,#0f2027,#203a43,#2c5364)'],['غروب','linear-gradient(160deg,#ff9966,#ff5e62 60%,#7b4397)'],['جنگل','linear-gradient(160deg,#134e5e,#71b280)'],['اقیانوس','linear-gradient(160deg,#2193b0,#6dd5ed)'],['بنفش','linear-gradient(160deg,#41295a,#2f0743 70%,#6a3093)'],['ساده روشن','#e9eef3'],['ساده تیره','#10151b']];
const wallUrl=(n,ver,small)=>'/wall/'+encodeURIComponent(n)+'?k='+encodeURIComponent(S.mediaKey||'')+'&v='+(ver||0)+(small?'&s=1':'');
const userWallUrl=(v,small)=>'/userwall?k='+encodeURIComponent(S.mediaKey||'')+'&v='+(v||0)+(small?'&s=1':'');
const wallSet=v=>{try{return JSON.parse(lsGet('wd-wallset','{}'))[v]||{}}catch{return{}}};     // size/fit of each own background (kept on this device)
const wallSetSave=(v,o)=>{try{const a=JSON.parse(lsGet('wd-wallset','{}'));if(o)a[v]=o;else delete a[v];lsSet('wd-wallset',JSON.stringify(a))}catch{}};
const WDIM={};
function paintMine(el,v,st){st=st||wallSet(v);const z=st.z||100,mode=st.mode||'cover';
  el.style.backgroundImage='url("'+userWallUrl(v)+'")';el.style.backgroundPosition='center';el.style.backgroundRepeat='no-repeat';
  if(z===100&&mode==='cover'){el.style.backgroundSize='cover';return}
  const d=WDIM[v];if(!d){el.style.backgroundSize='cover';const im=new Image();im.onload=()=>{WDIM[v]=[im.naturalWidth,im.naturalHeight];paintMine(el,v,st)};im.src=userWallUrl(v);return}
  const W=el.clientWidth,H=el.clientHeight;if(!W||!H){el.style.backgroundSize='cover';return}
  const k=(mode==='contain'?Math.min:Math.max)(W/d[0],H/d[1])*z/100;
  if(mode==='contain')el.style.backgroundColor='var(--bg2)';
  el.style.backgroundSize=Math.round(d[0]*k)+'px '+Math.round(d[1]*k)+'px'}
function dlgWallSize(v){
  const st=Object.assign({z:100,mode:'cover'},wallSet(v)),pv=h('div',{class:'wpv'});
  const paint=()=>{pv.style.backgroundColor='';paintMine(pv,v,st)};
  const zr=h('input',{type:'range',min:100,max:250,step:5,value:st.z,style:'padding:0;border:0',oninput:e=>{st.z=+e.target.value;zl.textContent=fa(st.z)+'٪';paint()}}),zl=h('span',{},fa(st.z)+'٪');
  const mb=(label,mode)=>h('button',{type:'button',class:'btn soft'+(st.mode===mode?' on':''),style:'flex:1',onclick:e=>{st.mode=mode;[...e.currentTarget.parentNode.children].forEach(x=>x.classList.remove('on'));e.currentTarget.classList.add('on');paint()}},label);
  dialog('اندازه پس‌زمینه',pv,h('label',{},'بزرگ‌نمایی ',zl),zr,h('div',{style:'display:flex;gap:8px;margin:10px 0'},mb('پر کردن صفحه','cover'),mb('کامل (بدون برش)','contain')),
    h('div',{style:'display:flex;gap:8px'},
      h('button',{class:'btn',style:'flex:1',onclick:()=>{if(st.z===100&&st.mode==='cover')wallSetSave(v,null);else wallSetSave(v,{z:st.z,mode:st.mode});lsSet('wd-wall','mine:'+v);applyWall();closeDialog()}},'ذخیره و استفاده'),
      h('button',{class:'btn soft',onclick:()=>{st.z=100;st.mode='cover';zr.value=100;zl.textContent=fa(100)+'٪';paint()}},'پیش‌فرض')));
  requestAnimationFrame(paint)}
function applyWall(){const w=$('#wall');if(!w)return;const v=lsGet('wd-wall','');
  w.style.backgroundImage='';w.style.backgroundColor='';w.style.backgroundSize='';w.classList.toggle('custom',!!v);
  if(v.startsWith('srv:')){if(!S.mediaKey)return;const[n,ver]=v.slice(4).split('|');w.style.backgroundImage='url("'+wallUrl(n,ver)+'")';w.style.backgroundSize='cover';w.style.backgroundPosition='center'}
  else if(v.startsWith('mine:')){if(!S.mediaKey)return;paintMine(w,v.slice(5))}
  else if(v.startsWith('img:')){w.style.backgroundImage='url("'+v.slice(4)+'")';w.style.backgroundSize='cover';w.style.backgroundPosition='center'}
  else if(v)w.style.background=v;else w.style.background=''}
function pickWallImage(file){
  if(!file)return;const url=URL.createObjectURL(file),im=new Image();
  im.onload=()=>{const k=Math.min(1,1280/Math.max(im.naturalWidth,im.naturalHeight)),c=document.createElement('canvas');c.width=Math.round(im.naturalWidth*k);c.height=Math.round(im.naturalHeight*k);
    c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(url);
    c.toBlob(async b=>{if(!b)return toast('عکس خیلی بزرگه');
      if(!S.mediaKey){try{lsSet('wd-wall','img:'+c.toDataURL('image/jpeg',.75));applyWall()}catch{toast('عکس خیلی بزرگه')}return}
      try{const r=await fetch('/userwall?k='+encodeURIComponent(S.mediaKey),{method:'POST',body:b}),j=await r.json();   // saved on the server, in YOUR folder
        if(!j.ok)return toast(j.error||'ذخیره نشد');S.wallV=j.v;S.walls=[j.v,...(S.walls||[]).filter(x=>x!==j.v)];lsSet('wd-wall','mine:'+j.v);applyWall();toast('پس‌زمینه ذخیره شد',false)}catch{toast('ذخیره نشد')}},'image/jpeg',.82)};
  im.onerror=()=>toast('عکس خونده نشد');im.src=url}
function applySize(n){document.body.style.fontSize=n+'px';lsSet('wd-size',n)}

/* ---------- network (auto-reconnect + persistent session; a call survives short drops) ---------- */
let ws=null,nextId=1,pingTimer=null,reconnecting=false,lastRx=Date.now(),netT=null,pingFails=0;const pending=new Map();
const getToken=()=>lsGet('wd-token'),setToken=t=>{lsSet('wd-token',t);try{window.WD&&WD.setToken&&WD.setToken(t||'')}catch{}};   // WD = bridge of the Android app (it keeps the token to poll for notifications)
if(window.WD&&WD.setToken){try{WD.setToken(lsGet('wd-token')||'')}catch{}}
const setNet=ok=>{clearTimeout(netT);const b=$('#netbar'),t=$('#apptitle');if(ok||!S.me){b.hidden=true;if(t){t.textContent='DARKGRAM — دارک گرام';t.classList.remove('wait')}}else netT=setTimeout(()=>{b.hidden=false;if(t){t.textContent='در حال اتصال…';t.classList.add('wait')}},1200)};
function connect(){
  return new Promise((res,rej)=>{
    if(ws&&ws.readyState===1)return res();
    const sock=new WebSocket((location.protocol==='https:'?'wss':'ws')+'://'+location.host+'/ws');ws=sock;
    sock.onopen=()=>{lastRx=Date.now();pingFails=0;clearInterval(pingTimer);pingTimer=setInterval(()=>keepAlive(sock),12000);res()};
    sock.onerror=()=>rej(new Error('وصل شدن به سرور ممکن نشد'));
    sock.onmessage=e=>{lastRx=Date.now();let m;try{m=JSON.parse(e.data)}catch{return}
      if(m.event)return onEvent(m);
      const p=pending.get(m.id);if(p){pending.delete(m.id);if(m.ok)p.res(m);else{const er=new Error(m.error||'خطا');er.server=true;p.rej(er)}}};
    sock.onclose=()=>sockDead(sock);
  })}
/* a link is only declared dead when NOTHING arrived for a long while and two pings in a row got no answer
   (a busy upload link answers slowly; that must never end a call) */
async function keepAlive(sock){
  if(ws!==sock)return;
  if(Date.now()-lastRx<10000){pingFails=0;return}
  try{await Promise.race([call('ping'),new Promise((_,r)=>setTimeout(()=>r(new Error('timeout')),C?25000:12000))]);pingFails=0}
  catch{if(ws===sock&&Date.now()-lastRx>(C?30000:15000)&&++pingFails>=2)sockDead(sock)}}
function sockDead(sock){
  if(ws!==sock)return;ws=null;clearInterval(pingTimer);
  for(const p of pending.values())p.rej(new Error('ارتباط با سرور قطع شد'));pending.clear();
  try{sock.close()}catch{}
  if(S.me){setNet(false);if(C&&C.state==='active'){C.reconnecting=true;showCallUI()}}
  if(getToken())reconnect()}
function call(op,data={}){
  return new Promise((res,rej)=>{
    if(!ws||ws.readyState!==1)return rej(new Error('به سرور وصل نیستی'));
    const id=nextId++;pending.set(id,{res,rej});ws.send(JSON.stringify({id,op,...data}))})}
async function hello(){
  try{const r=await call('hello',{caps:['call']});S.mediaKey=r.media_key;S.wallV=r.wall_v||0;S.walls=r.walls||(r.wall_v?[r.wall_v]:[]);applyWall();S.ice=r.ice_servers;S.maxUpload=r.max_upload;
    clearInterval(S.keyTimer);S.keyTimer=setInterval(()=>call('media_key').then(r=>{S.mediaKey=r.media_key}).catch(()=>{}),6*3600e3)}catch{}}
async function reconnect(){
  if(reconnecting)return;reconnecting=true;let delay=700;
  while(getToken()){
    try{
      await connect();const r=await call('resume',{token:getToken()});reconnecting=false;
      if(S.me){S.me=r.me;setNet(true);await afterReconnect()}else{$('#splash').hidden=true;await enter(r.me)}
      return;
    }catch(e){
      if(e.server){reconnecting=false;setToken(null);$('#splash').hidden=true;setNet(true);showAuth(e.message);return}
      if(S.me)setNet(false);
      await new Promise(r=>setTimeout(r,delay));delay=Math.min(delay*1.5,C?3000:6000)}}
  reconnecting=false}
async function afterReconnect(){
  await hello();buildDrawer();if(document.visibilityState!=='visible')call('visible',{v:false}).catch(()=>{});
  if(C){                                                    // back in the call that was running when the link dropped
    if(C.state==='active'){try{const r=await call('call_rejoin',{call_id:C.id});C.reconnecting=false;C.peerAway=!r.peer_online;C.next=0;showCallUI()}catch{endLocal('تماس تموم شده بود')}}
    else endLocal()}
  await refreshChats();S.readSent={};window.wdStories&&wdStories.load();
  const id=S.current,keep=id&&S.msgs[id];S.msgs={};
  if(id&&keep){try{const r=await call('history',{chat_id:id,limit:40});S.msgs[id]=r.messages;S.hasMore[id]=r.has_more;S.hasNewer[id]=false;if(S.current===id){softRender();markRead(id)}}catch{}}}
async function boot(){
  if(!getToken()){$('#splash').hidden=true;return showAuth()}
  try{const m=JSON.parse(lsGet('wd-me')||'null'),cc=JSON.parse(lsGet('wd-chats')||'null');   // open instantly from the saved copy, like Telegram
    if(m&&cc&&cc.u===m.id){S.me=m;S.chats=cc.c;if(window.WD&&!S.mediaKey)S.mediaKey='cached';$('#splash').hidden=true;$('#auth').hidden=true;$('#app').hidden=false;buildDrawer();renderList();setNet(false)}}catch{}
  maybePinLock();
  reconnect()}
let cacheT=null;
function saveCache(){clearTimeout(cacheT);cacheT=setTimeout(()=>{try{if(!S.me)return;const j=JSON.stringify({u:S.me.id,c:S.chats});if(j.length<600000){lsSet('wd-chats',j);lsSet('wd-me',JSON.stringify(S.me))}saveMsgs()}catch{}},1500)}
/* the last messages of recently opened chats are kept on the device too, so chats open with no internet (at most ~1.2 MB, oldest chats dropped first) */
function readMsgs(){try{const s=JSON.parse(lsGet('wd-msgs')||'null');if(s&&S.me&&s.u===S.me.id)return s}catch{}return{u:S.me&&S.me.id,o:[],m:{}}}
function saveMsgs(){
  if(!S.me)return;const st=readMsgs();
  for(const id of Object.keys(S.msgs)){const a=S.msgs[id];if(!a||!a.length||S.hasNewer[id]||!S.chats[id])continue;
    st.m[id]=a.slice(-40);st.o=st.o.filter(x=>x!==id);st.o.push(id)}
  st.o=st.o.filter(id=>S.chats[id]&&st.m[id]);
  for(const id of Object.keys(st.m))if(!st.o.includes(id))delete st.m[id];
  let j=JSON.stringify(st);while((j.length>1200000||st.o.length>30)&&st.o.length){delete st.m[st.o.shift()];j=JSON.stringify(st)}
  lsSet('wd-msgs',j)}

/* ---------- state ---------- */
const S={me:null,chats:{},msgs:{},hasMore:{},hasNewer:{},current:null,typing:{},drafts:(()=>{try{return JSON.parse(lsGet('wd-drafts')||'{}')}catch{return{}}})(),readSent:{},reply:null,editing:null,lastTyping:0,
  early:{},searchRes:[],searchGroups:[],searchJob:null,filter:'all',mediaKey:null,newBelow:0,users:{}};
function toast(t,err=true){if(err)sfx('error');const e=$('#toast');e.textContent=t;e.className=err?'err':'';e.hidden=false;clearTimeout(toast.j);toast.j=setTimeout(()=>e.hidden=true,3500)}
const at=n=>h('span',{dir:'ltr',class:'atcopy',title:'کپی آیدی',style:'unicode-bidi:isolate;display:inline-block;cursor:pointer',onclick:async e=>{e.stopPropagation();const t='@'+n;try{await navigator.clipboard.writeText(t)}catch(_){const ta=document.createElement('textarea');ta.value=t;document.body.append(ta);ta.select();try{document.execCommand('copy')}catch(__){}ta.remove()}toast(t+' کپی شد',false)}},'@'+n);
const initial=t=>([...(t||'?').trim()][0]||'?').toUpperCase();
/* avatar(kind 'u'|'c', id, name, avatar_at, size, online) — photo from /avatar/..., initials fallback */
function avatar(kind,id,name,at,size,online){
  const a=h('div',{class:'avatar',style:`width:${size}px;height:${size}px;font-size:${size/2.3}px;background:${COLORS[Math.abs(id||0)%COLORS.length]}`},initial(name));
  if(at&&S.mediaKey){const img=h('img',{alt:'',loading:'lazy',decoding:'async',src:`/avatar/${kind}${id}?k=${encodeURIComponent(S.mediaKey)}&v=${at}${size>64?'':'&s=1'}`,onerror:()=>img.remove()});a.append(img)}
  if(online)a.append(h('span',{class:'dot'}));return a}
const gav=(kind,id,name,at,size,online)=>{const a=avatar(kind,id,name,at,size,online);if(at){a.style.cursor='zoom-in';a.onclick=e=>{e.stopPropagation();openGallery(kind,id,name)}}return a};
const chatAvatar=(c,size,online)=>c.channel&&!c.avatar_at?h('div',{class:'avatar',style:`width:${size}px;height:${size}px;background:linear-gradient(135deg,#f4511e,#ff8a50)`},ic('channel',size*.55)):c.saved?(()=>{const a=h('div',{class:'avatar',style:`width:${size}px;height:${size}px;background:var(--accent)`},ic('bookmark',size*.55));return a})():
  c.peer?avatar('u',c.peer.id,c.peer.display_name,c.peer.avatar_at,size,online&&c.peer.online&&!c.peer.bot):avatar('c',c.id,c.title,c.avatar_at,size,false);

/* keep the app inside the visible area when the on-screen keyboard opens
   (otherwise the browser pans the fixed layout up and the chat header scrolls away) */
if(window.visualViewport){const vv=window.visualViewport,upd=()=>{const st=document.documentElement.style;
  if(vv.height<window.innerHeight-60){st.setProperty('--app-h',vv.height+'px');st.setProperty('--app-t',vv.offsetTop+'px');window.scrollTo(0,0)}
  else{st.removeProperty('--app-h');st.removeProperty('--app-t')}};
  vv.addEventListener('resize',upd);vv.addEventListener('scroll',upd);upd()}
/* ---------- auth ---------- */
let mode='login',resetStep=1;
function field(id,label,type='text',extra={}){return [h('label',{for:id},label),h('input',{id,type,...extra})]}
function buildAuth(m){
  mode=m;const f=$('#form');f.replaceChildren();$('#amsg').textContent='';
  $('#tab-login').classList.toggle('on',m!=='register');$('#tab-register').classList.toggle('on',m==='register');
  const btn=$('#abtn');btn.disabled=false;
  if(m==='login'){btn.textContent='ورود';
    f.append(...field('f-user','نام کاربری','text',{autocomplete:'username',autocapitalize:'none',value:lsGet('wd-user','')}),
      ...field('f-pw','رمز عبور','password',{autocomplete:'current-password'}),
      h('div',{class:'row-between'},h('button',{type:'button',class:'link',onclick:()=>buildAuth('reset')},'رمزم رو فراموش کردم'),
        h('label',{style:'margin:0;cursor:pointer'},h('input',{type:'checkbox',style:'width:auto;margin-inline-end:6px',onchange:e=>{$('#f-pw').type=e.target.checked?'text':'password'}}),'نمایش رمز')));
  }else if(m==='register'){btn.textContent='ساخت حساب';
    const meter=h('div',{class:'meter'},h('i'),h('i'),h('i'),h('i')),ml=h('div',{class:'muted',style:'font-size:11px;min-height:16px'});
    f.append(...field('f-user','نام کاربری (انگلیسی، ۳ تا ۳۲ کاراکتر)','text',{autocomplete:'username',autocapitalize:'none'}),
      ...field('f-name','نام نمایشی'),
      ...field('f-pw','رمز عبور (حداقل ۸ کاراکتر، حرف + عدد)','password',{autocomplete:'new-password',oninput:e=>{const s=strength(e.target.value);
        [...meter.children].forEach((x,i)=>x.style.background=i<s?(s<=1?'var(--danger)':s==2?'var(--warn)':'var(--ok)'):'var(--border)');
        ml.textContent=e.target.value?'قدرت رمز: '+['','ضعیف','متوسط','خوب','قوی'][s]:''}}),
      meter,ml,...field('f-pw2','تکرار رمز','password',{autocomplete:'new-password'}),
      h('label',{for:'f-q'},'سوال امنیتی (برای بازیابی رمز)'),
      h('input',{id:'f-q',list:'qs',placeholder:'یه سوال بنویس یا از لیست انتخاب کن',value:''}),h('datalist',{id:'qs'},QUESTIONS.map(q=>h('option',{value:q}))),
      ...field('f-ans','جواب سوال امنیتی'),
      h('div',{class:'muted',style:'font-size:11px;margin-top:4px'},'سوالی بنویس که فقط خودت جوابش رو بدونی (نه چیزی که دیگران حدس می‌زنن، مثل اسم مدرسه). جوابت رو یادت نگه دار؛ تنها راه بازیابی رمزه.'),
      h('label',{class:'rules',style:'display:flex;gap:8px;align-items:center;margin-top:12px;font-size:13px;cursor:pointer'},h('input',{type:'checkbox',id:'f-rules',style:'width:18px;height:18px;flex:none'}),h('span',{},'',h('a',{href:'#',style:'color:var(--accent);font-weight:700',onclick:e=>{e.preventDefault();e.stopPropagation();showRules()}},'قوانین'),' را خوانده‌ام و می‌پذیرم')));
  }else{btn.textContent='دریافت سوال امنیتی';resetStep=1;
    f.append(...field('f-user','نام کاربری','text',{autocapitalize:'none'}),h('div',{class:'row-between'},h('button',{type:'button',class:'link',onclick:()=>buildAuth('login')},'← بازگشت به ورود')))}
  const first=f.querySelector('input');if(first&&innerWidth>760)first.focus()}
function say(t,kind=''){const e=$('#amsg');e.textContent=t;e.className='msg '+kind}
const val=id=>$('#'+id).value;
async function withNet(fn){const b=$('#abtn');b.disabled=true;say('صبر کن…','info');
  try{await connect();await fn()}catch(e){say(e.message)}finally{b.disabled=false}}
const devName=()=>{const u=navigator.userAgent;const b=/Edg\//.test(u)?'Edge':/OPR\//.test(u)?'Opera':/Chrome\//.test(u)?'Chrome':/Firefox\//.test(u)?'Firefox':/Safari\//.test(u)?'Safari':'Browser';
  const o=/Windows/.test(u)?'Windows':/Android/.test(u)?'Android':/iPhone|iPad/.test(u)?'iOS':/Mac OS/.test(u)?'macOS':/Linux/.test(u)?'Linux':'';return b+(o?' · '+o:'')};
async function submitAuth(){
  if(mode==='login'){
    const u=val('f-user').trim(),p=val('f-pw');if(!u||!p)return say('نام کاربری و رمز رو وارد کن');
    await withNet(async()=>{const r=await call('login',{username:u,password:p,device:devName()});setToken(r.session);await enter(r.me)});
  }else if(mode==='register'){
    const u=val('f-user').trim(),p=val('f-pw'),q=val('f-q').trim(),a=val('f-ans');
    if(!USER_RE.test(u))return say('نام کاربری باید ۳ تا ۳۲ کاراکتر و فقط حرف انگلیسی، عدد یا _ باشه');
    const pe=pwError(p,u);if(pe)return say(pe);if(p!==val('f-pw2'))return say('تکرار رمز با رمز یکی نیست');
    if(q.length<5)return say('یه سوال امنیتی انتخاب کن یا بنویس');if(a.trim().length<4)return say('جواب سوال امنیتی رو بنویس (حداقل ۴ حرف)');
    if(!$('#f-rules').checked)return say('برای ساخت حساب باید قوانین رو بپذیری');
    await withNet(async()=>{const r=await call('register',{username:u,password:p,display_name:val('f-name').trim()||u,sec_question:q,sec_answer:a,device:devName()});setToken(r.session);await enter(r.me)});
  }else if(resetStep===1){
    const u=val('f-user').trim();if(!u)return say('نام کاربری رو بنویس');
    await withNet(async()=>{const r=await call('reset_question',{username:u});resetStep=2;
      $('#f-user').disabled=true;
      $('#form').append(h('div',{style:'margin-top:12px;color:var(--accent);font-weight:700'},r.question),...field('f-ans','جواب'),...field('f-pw','رمز جدید','password',{autocomplete:'new-password'}),...field('f-pw2','تکرار رمز جدید','password',{autocomplete:'new-password'}));
      $('#abtn').textContent='تغییر رمز';$('#f-ans').focus();say('')});
  }else{
    const u=val('f-user').trim(),p=val('f-pw'),pe=pwError(p,u);if(pe)return say(pe);if(p!==val('f-pw2'))return say('تکرار رمز با رمز یکی نیست');
    await withNet(async()=>{await call('reset_password',{username:u,answer:val('f-ans'),new_password:p});lsSet('wd-user',u);buildAuth('login');say('رمز عوض شد. حالا با رمز جدید وارد شو.','ok')})}}
function showAuth(notice){
  S.me=null;S.current=null;S.chats={};S.msgs={};lsSet('wd-me',null);lsSet('wd-chats',null);lsSet('wd-msgs',null);document.title='DarkGram';$('#app').hidden=true;$('#auth').hidden=false;buildAuth('login');if(notice)say(notice)}

/* ---------- entering the app ---------- */
async function enter(me){
  S.me=me;archLoad();lsSet('wd-user',me.username);try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch{}registerSW();
  $('#auth').hidden=true;$('#app').hidden=false;$('#app').classList.remove('show-chat');S.current=null;showChatView(false);
  await hello();await refreshChats();loadPrivacy();window.wdStories&&wdStories.load();buildDrawer();handleJoin();grabGiftFromUrl();dgArmBack();maybePinLock();if(window.wdShare)setTimeout(window.wdShare,300);
  if(PREF.notif&&'Notification' in window&&Notification.permission==='default')setTimeout(()=>Notification.requestPermission().then(()=>pushSync()).catch(()=>{}),4000)}
async function refreshChats(){
  try{const r=await call('chats');const nw={};r.chats.forEach(c=>nw[c.id]=c);
    if(S.current&&!nw[S.current]&&S.chats[S.current])nw[S.current]=S.chats[S.current];S.chats=nw;renderList();if(S.current)fillHeader()}catch(e){toast(e.message)}}
function saveDrafts(){try{lsSet('wd-drafts',JSON.stringify(Object.fromEntries(Object.entries(S.drafts).filter(([,v])=>v))))}catch{}}
const lastKey=c=>c.last?[c.last.created_at,c.last.id]:[c.created_at,0];
const sorted=()=>Object.values(S.chats).sort((a,b)=>{if(!!a.fav!==!!b.fav)return a.fav?-1:1;const ka=lastKey(a),kb=lastKey(b);return kb[0]-ka[0]||kb[1]-ka[1]});
function preview(c){
  const m=c.last;if(!m)return'هنوز پیامی نیست';if(m.kind==='system')return short(m.body,44);if(m.deleted)return'';
  let t;if(m.file)t=m.file.voice?'🎤 پیام صوتی '+fmtDur(m.file.dur):({image:'🖼 ',video:'🎬 ',audio:'🎵 '}[m.file.kind]||'📎 ')+(m.body||m.file.name);else t=m.sticker?'استیکر':m.body;
  const p=m.sender_id===S.me.id?'شما: ':(c.kind==='group'&&m.sender_name?short(m.sender_name,12)+': ':'');return short(p+t,48)}
const FILTERS=[['channel',L('📢 کانال‌ها','📢 Channels')],['group',L('👥 گروه‌ها','👥 Groups')],['private',L('💬 خصوصی','💬 Private')],['bots',L('🤖 ربات‌ها','🤖 Bots')],['unread',L('🔵 خوانده‌نشده','🔵 Unread')],['all',L('🗂️ همه گفتگوها','🗂️ All chats')]];
function renderFilters(){
  const el=$('#filters');el.replaceChildren(...FILTERS.map(([k,t])=>{
    const n=k==='unread'?Object.values(S.chats).filter(c=>c.unread&&!c.muted).length:0;
    return h('button',{class:S.filter===k?'on':'',onclick:()=>{S.filter=k;renderFilters();renderList();listAnim()}},t,n?h('span',{class:'cnt'},fa(n)):null)}))}
function chatRow(c){
  const tp=Object.entries(S.typing).filter(([k,x])=>k.startsWith(c.id+':')&&x.exp>Date.now()),typing=tp.length>0,tpText=tp.length&&tp[0][1].action==='voice'?'در حال ضبط ویس…':'در حال نوشتن…';
  return h('div',{class:'chat'+(c.id===S.current?' sel':'')+(c.peer&&c.peer.badge===3?' isowner':'')+(c.official?' isoff':''),onclick:()=>openChat(c.id),oncontextmenu:e=>{e.preventDefault();chatMenu(e.clientX,e.clientY,c)}},
    chatAvatar(c,52,true),
    h('div',{class:'ci'},
      h('div',{class:'ct'},h('span',{class:'name'},c.channel?ic('channel'):c.kind==='group'?ic('group'):null,c.title,c.peer&&c.peer.bot?h('span',{class:'botbadge'},'ربات'):null,c.muted?ic('bellx'):null),h('span',{class:'time'},(c.last&&c.last.sender_id===S.me.id&&!c.last.deleted&&c.last.kind!=='system')?h('span',{class:'tick'+(c.peer_read>=c.last.id?' read':'')},ic(c.peer_read>=c.last.id?'checkall':'check',16)):null,c.last?listTime(c.last.created_at):'')),
      h('div',{class:'cb'},h('span',{class:'prev'},typing?h('span',{class:'typing'},tpText):preview(c)),
        c.unread?h('span',{class:'badge'+(c.muted?' muted':'')},fa(c.unread>99?'99+':c.unread)):(c.fav?ic('pin',16):null))))}
let ARCH=new Set(),archView=false;
function archLoad(){try{ARCH=new Set(JSON.parse(lsGet('wd-arch-'+(S.me?S.me.id:0),'[]')))}catch(e){ARCH=new Set()}}
function archSave(){try{lsSet('wd-arch-'+(S.me?S.me.id:0),JSON.stringify([...ARCH]))}catch(e){}}
function setArchived(id,on){if(on)ARCH.add(id);else ARCH.delete(id);archSave();renderList();toast(on?L('بایگانی شد','Archived'):L('از بایگانی خارج شد','Unarchived'),false)}
function renderList(){
  renderFilters();
  const q=$('#search').value.trim().toLowerCase(),box=$('#list');box.replaceChildren();
  let chats=sorted();
  if(S.filter==='unread')chats=chats.filter(c=>c.unread);else if(S.filter==='channel')chats=chats.filter(c=>c.channel);
  else if(S.filter==='group')chats=chats.filter(c=>c.kind==='group'&&!c.channel);else if(S.filter==='private')chats=chats.filter(c=>c.kind==='private'&&!(c.peer&&c.peer.bot));
  else if(S.filter==='bots')chats=chats.filter(c=>c.kind==='private'&&c.peer&&c.peer.bot);
  if(q)chats=chats.filter(c=>c.title.toLowerCase().includes(q)||(c.peer&&c.peer.username.toLowerCase().includes(q)));
  if(archView)chats=chats.filter(c=>ARCH.has(c.id));else chats=chats.filter(c=>!ARCH.has(c.id));
  if(!q&&S.filter==='all'){
    if(archView)box.append(h('div',{class:'chat archrow',onclick:()=>{archView=false;renderList()}},h('div',{class:'avatar',style:'width:46px;height:46px;background:var(--hover)'},ic('back',22)),h('div',{class:'ci'},h('div',{class:'name'},L('همه گفتگوها','All chats')),h('div',{class:'prev'},L('برگرد به لیست اصلی','Back to the main list')))));
    else if(ARCH.size)box.append(h('div',{class:'chat archrow',onclick:()=>{archView=true;renderList()}},h('div',{class:'avatar',style:'width:46px;height:46px;background:var(--hover);color:var(--muted)'},ic('archive',24)),h('div',{class:'ci'},h('div',{class:'name'},L('بایگانی‌شده‌ها','Archived chats')),h('div',{class:'prev'},fa(ARCH.size)+' '+L('گفتگو','chats')))));
  }
  chats.forEach(c=>box.append(chatRow(c)));
  if(q&&S.searchRes.length){box.append(h('div',{class:'sect'},'کاربران'));
    S.searchRes.forEach(u=>box.append(h('div',{class:'chat',onclick:()=>openPrivate(u.username)},avatar('u',u.id,u.display_name,u.avatar_at,46,u.online&&!u.bot),
      h('div',{class:'ci'},h('div',{class:'name'},u.display_name),h('div',{class:'prev'},at(u.username))))))}
  if(archView&&!chats.length&&!q)box.append(h('div',{class:'hint'},L('📁 بایگانی خالیه','📁 Archive is empty')));
  if(!chats.length&&!q&&!archView)box.append(h('div',{class:'hint'},S.filter==='all'?['هنوز چتی نداری.',h('br'),'با دکمه مداد پایین، چت یا گروه جدید بساز.']:'چتی در این دسته نیست.'));
  if(q&&(S.searchGroups||[]).length){box.append(h('div',{class:'sect'},'گروه‌ها'));
    S.searchGroups.forEach(g=>box.append(h('div',{class:'chat',onclick:()=>{if(S.chats[g.id])openChat(g.id);else joinDialog({...g,member:false},{username:g.username})}},h('div',{class:'avatar',style:`width:46px;height:46px;background:${COLORS[g.id%COLORS.length]}`},ic('group',24)),
      h('div',{class:'ci'},h('div',{class:'name'},g.title),h('div',{class:'prev'},at(g.username),' · '+fa(g.member_count)+' عضو')))))}
  if(q&&(S.msgRes||[]).length){box.append(h('div',{class:'sect'},'پیام‌ها'));
    S.msgRes.forEach(r=>{const c=S.chats[r.chat_id];if(!c)return;box.append(h('div',{class:'chat',onclick:()=>{$('#search').value='';S.msgRes=[];renderList();openChat(r.chat_id,r.id)}},
      chatAvatar(c,46,true),
      h('div',{class:'ci'},h('div',{class:'name'},c.title),h('div',{class:'prev'},(r.sender?r.sender+': ':'')+r.text))))})}
  if(q&&!chats.length&&!S.searchRes.length&&!(S.searchGroups||[]).length&&!(S.msgRes||[]).length)box.append(h('div',{class:'hint'},'برای پیدا کردن کاربر جدید، نام کاربری کامل‌ش رو بنویس (مثلاً ali_123)'));
  const other=Object.values(S.chats).reduce((a,c)=>a+(c.id!==S.current&&!c.muted?c.unread:0),0),bb=$('#bb');if(bb){bb.hidden=!other;bb.textContent=fa(other>99?'99+':other)}
  saveCache();renderNav();
  const total=Object.values(S.chats).reduce((a,c)=>a+(c.muted?0:c.unread),0);document.title=total?`(${fa(total)}) DarkGram`:'DarkGram'}
/* bottom bar (phone / Android app): Chats · Contacts · Settings · Profile */
function renderNav(){
  const nav=$('#bnav');if(!nav||!S.me)return;
  nav.querySelectorAll('button').forEach(b=>{const t=b.dataset.t,bi=b.firstElementChild;
    if(!bi.firstChild||bi.dataset.me!==String(S.me.avatar_at||0)+t){
      if(t==='me'){bi.replaceChildren(avatar('u',S.me.id,S.me.display_name,S.me.avatar_at,26,false))}
      else bi.replaceChildren(ic({chats:'chatb',contacts:'personf',settings:'settingsf'}[t],27));
      bi.dataset.me=String(S.me.avatar_at||0)+t}
    b.classList.toggle('on',t==='chats'?S.filter!=='private':t==='contacts'?S.filter==='private':false)});
  const n=Object.values(S.chats).filter(c=>c.unread&&!c.muted).length;let e=nav.querySelector('.nb');
  if(!e){e=h('em',{class:'nb'});nav.querySelector('[data-t=chats] .bi').append(e)}e.hidden=!n;e.textContent=fa(n>99?'99+':n)}
const listAnim=()=>{const L=$('#list');if(!L)return;L.classList.remove('lv');void L.offsetWidth;L.classList.add('lv');clearTimeout(L._lvt);L._lvt=setTimeout(()=>L.classList.remove('lv'),520)};
function navGo(t){
  if(t==='chats'){S.filter='all';$('#list').scrollTop=0;renderList();listAnim()}
  else if(t==='contacts'){S.filter='private';$('#list').scrollTop=0;renderList();listAnim()}
  else if(t==='settings')dlgSettings();else if(t==='me')dlgProfile()}
/* Android back button: close the top-most thing; false = nothing left, app goes to background */
window.wdBack=()=>{
  if(document.getElementById('dshow')){closeDragonShow();return true}
  if(!$('#ctx').hidden){$('#ctx').hidden=true;return true}
  if(document.getElementById('psheet')){closeSheet();return true}
  if(!$('#modal').hidden){closeDialog();return true}
  if(!$('#lightbox').hidden){$('#lightbox').hidden=true;return true}
  if($('#drawer').classList.contains('on')){openDrawer(false);return true}
  if(!$('#emoji').hidden){$('#emoji').hidden=true;return true}
  if(!$('#schbar').hidden){closeSearch();return true}
  if(S.reply||S.editing){clearBar();autosize();return true}
  if($('#app').classList.contains('show-chat')){$('#back').click();return true}
  if(S.me&&S.filter!=='all'){S.filter='all';renderList();return true}
  return false};
/* Browser/Android back button: feed it through wdBack() (close dialog -> chat -> list)
   and always re-arm a guard entry, so back never leaves the app — like Telegram. */
let dgBackGuard=false;
function dgArmBack(){if(dgBackGuard)return;dgBackGuard=true;try{history.pushState({dg:1},'')}catch(e){}}
window.addEventListener('popstate',()=>{dgBackGuard=false;try{wdBack()}catch(e){}dgArmBack()});
async function openPrivate(username){
  try{const r=await call('open_private',{username});S.chats[r.chat.id]=S.chats[r.chat.id]||r.chat;$('#search').value='';S.searchRes=[];renderList();openChat(r.chat.id)}catch(e){toast(e.message)}}
function chatMenu(x,y,c){
  const items=[[ARCH.has(c.id)?L('خروج از بایگانی','Unarchive'):L('بایگانی','Archive'),'archive',()=>setArchived(c.id,!ARCH.has(c.id))],
    [c.fav?L('سنجاق‌شده رو بردار','Unpin'):L('سنجاق به بالای لیست','Pin to top'),'pin',()=>setChat(c.id,{fav:!c.fav})],
    [c.muted?L('فعال کردن اعلان','Unmute'):L('بی‌صدا کردن','Mute'),'bellx',()=>setChat(c.id,{muted:!c.muted})]];
  if(c.unread)items.push([L('علامت‌گذاری خوانده‌شده','Mark as read'),'check',()=>{call('read',{chat_id:c.id,up_to:(c.last&&c.last.id)||0}).catch(()=>{});c.unread=0;renderList()}]);
  const lg=c.kind==='group'&&(!c.channel||c.bcast),nm=c.bcast?L('کانال','channel'):L('گروه','group');
  if(lg&&!(c.bcast&&c.owner_id===S.me.id))items.push([L('ترک ','Leave ')+nm,'logout',()=>leaveGroup(c),true]);
  if(lg&&c.owner_id===S.me.id)items.push([L('حذف ','Delete ')+nm,'delete',()=>deleteGroup(c),true]);
  popMenu(x,y,items)}
async function setChat(id,patch){try{const r=await call('chat_settings',{chat_id:id,...patch});S.chats[id]=Object.assign(S.chats[id]||{},r.chat);renderList();if(S.current===id)fillHeader()}catch(e){toast(e.message)}}
async function leaveGroup(c){if(!confirm(c.bcast?'از کانال «'+c.title+'» خارج بشی؟':'از گروه «'+c.title+'» خارج بشی؟'))return;try{await call('leave',{chat_id:c.id});onEvent({event:'chat_removed',chat_id:c.id});closeDialog()}catch(e){toast(e.message)}}

async function deleteGroup(c){if(!confirm((c.bcast?'کانال «':'گروه «')+c.title+'» برای همه '+(c.bcast?'مشترک‌ها':'اعضا')+' حذف بشه؟ (فایل‌های آپلودشده روی سرور می‌مونن)'))return;
  try{await call('delete_group',{chat_id:c.id});onEvent({event:'chat_removed',chat_id:c.id});closeDialog()}catch(e){toast(e.message)}}

/* ---------- chat view ---------- */
function showChatView(on){$('#chatview').hidden=!on;$('#empty').hidden=on}
async function openChat(id,aroundId){
  if(!S.chats[id])return;
  if(S.current&&S.current!==id)S.drafts[S.current]=$('#input').value;saveDrafts();
  if(S.current!==id){cancelRec(true);closeSearch(true)}
  S.current=id;clearBar();showChatView(true);$('#app').classList.add('show-chat');S.newBelow=0;
  $('#input').value=S.drafts[id]||'';autosize();fillHeader();renderList();updateSendBtn();if(window.wdChat)window.wdChat.forEach(f=>f());
  const c=S.chats[id];S.unreadFrom=c.unread?c.my_read:null;
  if(aroundId){await loadAround(aroundId)}
  else if(S.msgs[id]&&!S.hasNewer[id]){renderMsgs();markRead(id)}
  else{$('#msgs').replaceChildren(h('div',{class:'hint'},'در حال بارگذاری…'));
    try{const r=await call('history',{chat_id:id,limit:40});S.msgs[id]=r.messages;S.hasMore[id]=r.has_more;S.hasNewer[id]=false;
      for(const m of (S.early[id]||[]))if(!S.msgs[id].some(x=>x.id===m.id))S.msgs[id].push(m);delete S.early[id];S.msgs[id].sort((a,b)=>a.id-b.id);
      if(S.current===id){renderMsgs();markRead(id)}}
    catch(e){const old=readMsgs().m[id];                       // no internet: show the copy saved on this device
      if(old&&old.length&&S.current===id){S.msgs[id]=old;S.hasMore[id]=false;S.hasNewer[id]=false;renderMsgs();toast('بدون اینترنت: پیام‌های ذخیره‌شده',false)}
      else toast(e.message)}}
  if(matchMedia('(min-width:761px)').matches)$('#input').focus()}
async function loadAround(mid){
  const id=S.current;
  try{const r=await call('history',{chat_id:id,around:mid,limit:40});S.msgs[id]=r.messages;S.hasMore[id]=r.has_more;S.hasNewer[id]=!!r.has_newer;
    if(S.current===id){renderMsgs(mid);flash(mid)}}catch(e){toast(e.message)}}
function subtitle(c){
  if(c.channel)return[fa(c.member_count)+' مشترک',false];
  const now=Date.now(),t=Object.entries(S.typing).filter(([k,x])=>k.startsWith(c.id+':')&&x.exp>now);
  if(t.length)return[t[0][1].action==='voice'?'در حال ضبط پیام صوتی…':'در حال نوشتن…',true];
  if(c.saved)return['فقط خودت می‌بینی',false];
  if(c.channel)return[fa(c.member_count)+' مشترک',false];
  if(c.kind==='group')return[fa(c.member_count)+' عضو',false];
  if(c.peer&&c.peer.bot)return['ربات',false];
  if(!c.peer)return['',false];return[seenText(c.peer),!!c.peer.online]}
function fillHeader(){
  const c=S.chats[S.current];if(!c)return;
  $('#hav').replaceChildren(chatAvatar(c,44,false));$('#hav').classList.toggle('ownerchat',!!(c.peer&&c.peer.badge===3));$('#hav').classList.toggle('offchat',!!c.official);$('#hname').textContent=c.title;
  $('#callbtn').hidden=$('#vcallbtn').hidden=!(c.kind==='private'&&c.peer&&!c.peer.bot);refreshSub();
  const pb=$('#pinbar');pb.hidden=!c.pin_msg;if(c.pin_msg){$('#pintxt').textContent=short((c.pin_msg.sender_name?c.pin_msg.sender_name+': ':'')+c.pin_msg.text,80)}
  const ro=!!(c.channel&&!c.can_post);$('#composer').hidden=ro;$('#ronly').hidden=!ro}
function refreshSub(){const c=S.chats[S.current];if(!c)return;const[t,live]=subtitle(c);const e=$('#hsub');e.textContent=t;e.className=live?'live':''}
function tickEl(m){const c=S.chats[m.chat_id],read=c&&c.peer_read>=m.id;const t=h('span',{class:'tick'+(read?' read':''),'data-mid':m.id},ic(read?'checkall':'check',16));return t}
const mediaUrl=(m,dl)=>'/media/'+m.id+'?k='+encodeURIComponent(S.mediaKey||'')+(dl?'&dl=1':'');
const thumbUrl=m=>'/thumb/'+m.id+'?k='+encodeURIComponent(S.mediaKey||'');
const msgRef=m=>(S.msgs[m.chat_id]||[]).find(x=>x.id===m.id)||m;
function fileCard(m){
  const ext=(m.file.name.includes('.')?m.file.name.split('.').pop():'').slice(0,4).toUpperCase();
  return h('div',{class:'file',onclick:()=>download(m)},h('span',{class:'ic'},ic('file'),ext?h('em',{},ext):null),
    h('div',{class:'fi'},h('b',{},short(m.file.name,34)),h('small',{},fmtSize(m.file.size))),h('span',{class:'dl'},ic('download',20)))}
/* one shared audio player for voice messages and music: one plays at a time, keeps playing when you change chat,
   shows a mini player bar (list + chat) and plays the next song / voice message by itself */
const VP={audio:null,mid:null,m:null,rate:1,uis:new Map()};
function markPlayed(m){
  const r=msgRef(m),f=r.file;if(!f||r.sender_id===S.me.id||(f.played||[]).includes(S.me.id))return;
  (f.played=f.played||[]).push(S.me.id);document.querySelectorAll(`[data-bid="${m.id}"] .vdot`).forEach(x=>x.remove());
  call('voice_played',{message_id:m.id}).catch(()=>{})}
/* every card of the playing message (the chat can be redrawn at any time) is kept in sync */
function regUi(m,ui){let s=VP.uis.get(m.id);if(!s){s=new Set();VP.uis.set(m.id,s)}s.add(ui);
  if(VP.mid===m.id&&VP.audio){const a=VP.audio;setIcon(ui.play,a.paused?'play':'pause');if(isFinite(a.duration)&&!ui.dur)ui.dur=a.duration;ui.paint(a.currentTime)}}
function eachUi(fn){const s=VP.uis.get(VP.mid);if(!s)return;for(const u of [...s]){if(!u.play.isConnected){s.delete(u);continue}try{fn(u)}catch{}}}
function playToggle(m,ui){
  if(VP.mid===m.id&&VP.audio){VP.audio.paused?VP.audio.play().catch(()=>{}):VP.audio.pause();return}
  startPlay(m,ui)}
function startPlay(m,ui){
  stopVoice();const a=new Audio(mediaUrl(m));a.preload='auto';a.playbackRate=(ui&&ui.rate)||VP.rate||1;
  VP.audio=a;VP.mid=m.id;VP.m=m;
  a.onplay=()=>{eachUi(u=>setIcon(u.play,'pause'));paintMini();mediaSess()};
  a.onpause=()=>{eachUi(u=>setIcon(u.play,'play'));paintMini()};
  a.onloadedmetadata=()=>{if(isFinite(a.duration))eachUi(u=>{if(!u.dur){u.dur=a.duration;u.reset&&u.reset()}})};
  a.ontimeupdate=()=>{eachUi(u=>u.paint(a.currentTime));paintMiniBar()};
  a.onended=()=>{const m0=VP.m;
    if(!m0.file.voice&&VP.repeat==='one'){a.currentTime=0;a.play().catch(()=>{});return}
    stopVoice();
    if(!playNext(m0,1)&&VP.repeat==='all'&&!m0.file.voice){const l=songsOf(m0.chat_id);if(l.length)startPlay(l[0],null)}};
  a.onerror=()=>{toast('پخش ممکن نشد');stopVoice()};
  a.play().catch(()=>{});
  if(m.file.voice)markPlayed(m);
  paintMini()}
function stopVoice(){
  const a=VP.audio;if(a){a.onplay=a.onpause=a.ontimeupdate=a.onended=a.onerror=a.onloadedmetadata=null;try{a.pause()}catch{}}
  eachUi(u=>{setIcon(u.play,'play');u.reset&&u.reset()});
  VP.audio=null;VP.mid=null;VP.m=null;paintMini();
  try{if('mediaSession' in navigator&&!C)navigator.mediaSession.metadata=null}catch{}}
/* next / previous song (or next unheard voice message) of the same chat */
function neighbour(m,dir){
  const l=(S.msgs[m.chat_id]||[]).filter(x=>!x.deleted&&x.file&&(m.file.voice?x.file.voice:(x.file.kind==='audio'&&!x.file.voice)));
  const i=l.findIndex(x=>x.id===m.id);if(i<0)return null;
  if(dir>0){for(let j=i+1;j<l.length;j++){if(!m.file.voice||(l[j].sender_id!==S.me.id&&!(l[j].file.played||[]).includes(S.me.id)))return l[j]}return null}
  return i>0&&!m.file.voice?l[i-1]:null}
function playNext(m,dir){const n=m&&neighbour(m,dir);if(n)startPlay(n,null);return !!n}
const songsOf=cid=>(S.msgs[cid]||[]).filter(x=>!x.deleted&&x.file&&x.file.kind==='audio'&&!x.file.voice);
function mediaSess(){
  if(!('mediaSession' in navigator)||!VP.m||C)return;
  const m=VP.m,f=m.file;
  try{navigator.mediaSession.metadata=new MediaMetadata({title:f.voice?'پیام صوتی':f.name.replace(/\.[^.]+$/,''),artist:m.sender_name||'',album:'DarkGram'});
    const set=(k,fn)=>{try{navigator.mediaSession.setActionHandler(k,fn)}catch{}};
    set('play',()=>VP.audio&&VP.audio.play().catch(()=>{}));set('pause',()=>VP.audio&&VP.audio.pause());
    set('previoustrack',()=>VP.m&&playNext(VP.m,-1));set('nexttrack',()=>VP.m&&playNext(VP.m,1));
    set('seekto',e=>{if(VP.audio&&isFinite(e.seekTime))VP.audio.currentTime=e.seekTime})}catch{}}
/* the mini player bar (like Telegram): play/pause · title · speed · close; tap the title to jump to the message */
function fillMini(el){
  const pb=h('button',{class:'iconbtn mp',type:'button',title:'پخش/توقف',onclick:e=>{e.stopPropagation();if(VP.audio)VP.audio.paused?VP.audio.play().catch(()=>{}):VP.audio.pause()}}),
    prev=h('button',{class:'iconbtn mprev',type:'button',title:'قبلی',onclick:e=>{e.stopPropagation();VP.m&&playNext(VP.m,-1)}}),
    next=h('button',{class:'iconbtn mnext',type:'button',title:'بعدی',onclick:e=>{e.stopPropagation();VP.m&&playNext(VP.m,1)}}),
    rate=h('button',{class:'mrate',type:'button',title:'سرعت',onclick:e=>{e.stopPropagation();if(!VP.audio)return;VP.rate=VP.rate===1?1.5:VP.rate===1.5?2:1;VP.audio.playbackRate=VP.rate;paintMini()}}),
    x=h('button',{class:'iconbtn mx',type:'button',title:'بستن',onclick:e=>{e.stopPropagation();stopVoice()}}),
    tt=h('b',{class:'mtt'}),ts=h('span',{class:'mts'}),bar=h('i',{class:'mbar'},h('b')),
    mid=h('div',{class:'mt',onclick:()=>{if(!VP.m)return;if(!VP.m.file.voice)return openPlayer();if(S.chats[VP.m.chat_id])openChat(VP.m.chat_id,VP.m.id)}},tt,ts);
  setIcon(prev,'skipprev',20);setIcon(next,'skipnext',20);setIcon(x,'close',20);
  el.replaceChildren(pb,mid,prev,next,rate,x,bar);el._m={pb,tt,ts,bar,rate,prev,next}}
function paintMini(){
  document.querySelectorAll('.mini').forEach(el=>{
    if(!el._m)fillMini(el);const q=el._m,m=VP.m,a=VP.audio;el.hidden=!a||!m;if(!a||!m)return;
    const f=m.file,c=S.chats[m.chat_id];
    q.tt.textContent=f.voice?'پیام صوتی':f.name.replace(/\.[^.]+$/,'');
    q.ts.textContent=(m.sender_id===S.me.id?'شما':(m.sender_name||''))+(c&&c.kind==='group'?' · '+c.title:'');
    setIcon(q.pb,a.paused?'play':'pause',22);
    q.rate.textContent='×'+fa(VP.rate);q.rate.hidden=!f.voice;
    q.prev.hidden=q.next.hidden=!!f.voice||!(neighbour(m,1)||neighbour(m,-1));
    paintMiniBar()});paintSheet()}
function paintMiniBar(){const a=VP.audio;paintSheetBar();document.querySelectorAll('.mini').forEach(el=>{if(el._m&&a)el._m.bar.firstChild.style.width=(isFinite(a.duration)&&a.duration?a.currentTime/a.duration*100:0)+'%'})}
function seekFrac(e,el,ui,m){const r=el.getBoundingClientRect(),frac=Math.min(1,Math.max(0,(e.clientX-r.left)/r.width));
  if(!(VP.mid===m.id&&VP.audio))playToggle(m,ui);const a=VP.audio;if(a&&ui.dur){try{a.currentTime=frac*ui.dur}catch{}}}
function voiceBlock(m){
  const f=m.file,bars=(f.wave&&f.wave.length?f.wave:Array.from({length:32},(_,i)=>6+((i*7)%14)));
  const unheard=m.sender_id!==S.me.id&&!(f.played||[]).includes(S.me.id);
  const play=h('button',{class:'play',type:'button'},ic('play')),vt=h('span',{class:'vt'},fmtDur(f.dur||0)),sp=h('button',{class:'sp',type:'button'},'×'+fa(VP.rate));
  const wv=h('div',{class:'wv'},bars.map(b=>h('i',{style:`height:${Math.max(3,Math.round((b+1)/32*28))}px`})));
  const ui={play,wv,dur:f.dur||0,m,rate:VP.rate};
  ui.paint=t=>{const n=wv.children.length,k=ui.dur?Math.floor(t/ui.dur*n):0;[...wv.children].forEach((b,i)=>b.classList.toggle('on',i<k));vt.textContent=fmtDur(t)};
  ui.reset=()=>{[...wv.children].forEach(b=>b.classList.remove('on'));vt.textContent=fmtDur(ui.dur)};
  play.onclick=e=>{e.stopPropagation();playToggle(m,ui)};
  wv.onclick=e=>{e.stopPropagation();seekFrac(e,wv,ui,m)};
  sp.onclick=e=>{e.stopPropagation();VP.rate=VP.rate===1?1.5:VP.rate===1.5?2:1;ui.rate=VP.rate;if(VP.audio)VP.audio.playbackRate=VP.rate;document.querySelectorAll('.voice .sp').forEach(x=>x.textContent='×'+fa(VP.rate));paintMini()};
  regUi(m,ui);
  return h('div',{class:'voice'},play,h('div',{style:'flex:1;min-width:0'},wv,h('div',{style:'display:flex;justify-content:space-between;align-items:center'},h('span',{style:'display:flex;align-items:center;gap:6px'},vt,unheard?h('i',{class:'vdot',title:'هنوز گوش ندادی'}):null),sp)))}
/* music / audio file: filled card with big play button, title, duration and size (like Telegram) */
function musicBlock(m){
  const f=m.file,title=f.name.replace(/\.[^.]+$/,''),play=h('button',{class:'play big',type:'button'},ic('play')),sub=h('div',{class:'msub'},fmtSize(f.size)),fill=h('i'),bar=h('div',{class:'mbar'},fill);
  const ui={play,dur:0,m,rate:1};
  ui.paint=t=>{fill.style.width=(ui.dur?t/ui.dur*100:0)+'%';sub.textContent=fmtDur(t)+' • '+fmtSize(f.size)};
  ui.reset=()=>{fill.style.width='0';sub.textContent=(ui.dur?fmtDur(ui.dur)+' • ':'')+fmtSize(f.size)};
  play.onclick=e=>{e.stopPropagation();playToggle(m,ui)};bar.onclick=e=>{e.stopPropagation();seekFrac(e,bar,ui,m)};
  regUi(m,ui);
  return h('div',{class:'music'},play,h('div',{class:'mi'},h('b',{},short(title,40)),sub,bar),
    h('button',{class:'iconbtn dl',type:'button',title:'ذخیره',onclick:e=>{e.stopPropagation();download(m)}},ic('download',20)))}
/* image / video preview: a small thumbnail made by the sender's browser; the real file is only fetched when you tap */
const thumbQ=[];let thumbBusy=false;
const thumbIO='IntersectionObserver' in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){thumbIO.unobserve(e.target);e.target._lz&&e.target._lz()}}),{rootMargin:'100px'}):null;
async function thumbPump(){if(thumbBusy)return;thumbBusy=true;
  while(thumbQ.length){const job=thumbQ.shift();try{await job()}catch{}}thumbBusy=false}
/* old videos without a preview: make one (one at a time, only when scrolled into view) and store it for everyone */
function lazyThumb(box,m){
  box._lz=()=>thumbQ.push(()=>new Promise(done=>{
    if(!S.mediaKey||!box.isConnected||box.classList.contains('playing'))return done();
    makeThumb(mediaUrl(m),'video').then(t=>{done();if(!t||!box.isConnected)return;
      box.prepend(h('img',{src:URL.createObjectURL(t.blob),alt:''}));box.classList.remove('nothumb');
      fetch('/thumb?'+new URLSearchParams({k:S.mediaKey,message_id:m.id,w:t.w,h:t.h}),{method:'POST',body:t.blob}).catch(()=>{})})}))&&thumbPump();
  if(thumbIO)thumbIO.observe(box)}
function mediaBox(m){
  const f=m.file,vid=f.kind==='video',fail=()=>box.replaceWith(fileCard(m));
  const ratio=f.tw&&f.th?f.tw/f.th:(vid?16/9:4/3),w=ratio<.9?'230px':'320px';
  const box=h('div',{class:'pv'+(f.thumb?'':' nothumb'),style:`aspect-ratio:${Math.max(.5,Math.min(2.2,ratio)).toFixed(3)};width:${w};max-width:100%`});
  if(f.thumb)box.append(h('img',{src:thumbUrl(m),alt:'',loading:'lazy',draggable:'false',onerror:e=>e.target.remove()}));
  if(vid&&!f.thumb)lazyThumb(box,m);
  if(vid){box.append(h('span',{class:'pbtn'},ic('play',30)),h('span',{class:'psz'},fmtSize(f.size)));
    box.onclick=e=>{e.stopPropagation();if(window.WD&&WD.playVideo){try{WD.playVideo(mediaUrl(m),f.name||'');return}catch{}}      // Android app: native full-screen player
      const v=h('video',{class:'media',src:mediaUrl(m),controls:true,autoplay:true,preload:'auto',playsinline:true,onerror:fail});box.replaceChildren(v);box.classList.add('playing');box.style.aspectRatio='auto';box.onclick=null}}
  else box.onclick=e=>{e.stopPropagation();lightbox(mediaUrl(m))};
  return box}
function fileBlock(m){
  const f=m.file,k=f.kind,fail=e=>e.target.replaceWith(fileCard(m));
  if(S.mediaKey){
    if(f.voice)return voiceBlock(m);
    if(k==='audio')return musicBlock(m);
    if(k==='image'&&f.thumb)return mediaBox(m);
    if(k==='image')return h('img',{class:'media',src:mediaUrl(m),loading:'lazy',alt:f.name,onclick:e=>{e.stopPropagation();lightbox(mediaUrl(m))},onerror:fail});
    if(k==='video')return mediaBox(m)}
  return fileCard(m)}
function lightbox(src){const l=$('#lightbox');l.replaceChildren(h('img',{src}),h('button',{class:'iconbtn x',style:'color:#fff'},ic('close')));l.hidden=false;l.onclick=()=>{l.hidden=true;l.replaceChildren()}}
/* profile photo gallery: swipe / arrows / dots through every kept photo (like Telegram) */
async function openGallery(kind,id,title){
  let pics=[];
  try{const r=await call('avatar_list',kind==='u'?{user_id:id}:{chat_id:id});pics=r.pics}catch(e){return toast(e.message)}
  if(!pics.length)return toast('عکسی نیست',false);
  const l=$('#lightbox');let i=0;
  const url=(n,small)=>`/avatar/${kind}${id}?k=${encodeURIComponent(S.mediaKey)}&pic=${encodeURIComponent(n)}${small?'&s=1':''}`;
  const img=h('img',{class:'gimg',draggable:'false'}),cnt=h('div',{class:'gcnt'}),dots=h('div',{class:'gdots'}),cap=h('div',{class:'gcap'},title||'');
  const show=n=>{i=(n+pics.length)%pics.length;img.src=url(pics[i]);cnt.textContent=fa(i+1)+' از '+fa(pics.length);
    dots.replaceChildren(...pics.map((_,k)=>h('i',{class:k===i?'on':''})));img.classList.remove('slide');void img.offsetWidth;img.classList.add('slide')};
  const close=()=>{l.hidden=true;l.replaceChildren();l.onclick=null;document.removeEventListener('keydown',key)};
  const key=e=>{if(e.key==='ArrowLeft')show(i+1);else if(e.key==='ArrowRight')show(i-1);else if(e.key==='Escape')close()};
  const nav=(cls,icn,fn)=>h('button',{class:'iconbtn gnav '+cls,onclick:e=>{e.stopPropagation();fn()}},ic(icn));
  l.replaceChildren(img,cap,cnt,dots,h('button',{class:'iconbtn x',style:'color:#fff',onclick:e=>{e.stopPropagation();close()}},ic('close')),
    pics.length>1?nav('gl','back',()=>show(i+1)):null,pics.length>1?nav('gr','back',()=>show(i-1)):null);
  let x0=null;l.ontouchstart=e=>{x0=e.touches[0].clientX};
  l.ontouchend=e=>{if(x0==null)return;const dx=e.changedTouches[0].clientX-x0;x0=null;if(Math.abs(dx)>40&&pics.length>1){show(dx<0?i+1:i-1)}};
  l.onclick=e=>{if(e.target===l)close()};document.addEventListener('keydown',key);l.hidden=false;show(0)}
function uAv(id,size){
  if(id===S.me.id)return avatar('u',id,S.me.display_name,S.me.avatar_at,size,false);
  const c=Object.values(S.chats).find(x=>x.peer&&x.peer.id===id);
  return c?avatar('u',id,c.peer.display_name,c.peer.avatar_at,size,false):avatar('u',id,userName(id),S.users['a'+id]||0,size,false)}
function reactBar(m){
  const kids=[];
  if(m.stars&&m.stars.total>0){const mineS=(m.stars.amounts||[]).find(a=>a.id===S.me.id);
    kids.push(h('span',{class:'react starreact'+(mineS?' me':''),title:'ری‌اکشن ستاره‌ای ⭐',onclick:e=>{e.stopPropagation();dlgStarReact(m)}},h('span',{class:'re'},'⭐'),h('b',{},fa(m.stars.total))))}
  if(m.reactions&&m.reactions.length)kids.push(...m.reactions.map(r=>h('span',{class:'react'+(r.users.includes(S.me.id)?' me':'')+(r.e==='❤️'?' heart':''),title:r.users.map(u=>userName(u)).join('، '),onclick:e=>{e.stopPropagation();react(m,r.e)}},
    h('span',{class:'re aemo a-'+emoAnim(r.e)},r.e),r.users.length<=3?h('span',{class:'ravs'},r.users.map(u=>uAv(u,22))):h('small',{},fa(r.users.length)))));
  return kids.length?h('div',{class:'reacts'},kids):null}
function userName(id){if(id===S.me.id)return'شما';for(const c of Object.values(S.chats))if(c.peer&&c.peer.id===id)return c.peer.display_name;return S.users[id]||'کاربر'}
async function react(m,emoji){if(emoji==='⭐'){dlgStarReact(m);return}try{const r=await call('react',{message_id:m.id,emoji});applyUpdate(r.message);
    const mine=(r.message.reactions||[]).find(x=>x.e===emoji);if(mine&&mine.users.includes(S.me.id)){rxBurst(m.id,emoji);sfx('pop')}}catch(e){toast(e.message)}}
async function dlgStarReact(m){
  let balN=null,unlim=false;
  try{const r=await call('stars_me');unlim=!!r.unlimited;balN=unlim?Infinity:(r.stars|0)}catch{}
  const maxS=unlim?1000:Math.max(1,Math.min(1000,balN||0));
  let amt=Math.min(10,maxS);
  const amtLbl=h('b',{style:'font-size:30px'},'⭐ '+fa(amt));
  const slider=h('input',{type:'range',class:'starslider',min:'1',max:String(maxS),step:'1',value:String(amt)});
  const custom=h('input',{type:'number',min:'1',max:'100000',placeholder:'مبلغ دلخواه…',style:'width:130px;text-align:center'});
  const setAmt=(v,src)=>{v=Math.max(1,Math.min(100000,Math.round(v||1)));amt=v;amtLbl.textContent='⭐ '+fa(amt);if(src!==slider)slider.value=String(Math.min(v,maxS));if(src!==custom)custom.value=v>maxS?String(v):''};
  slider.addEventListener('input',()=>setAmt(+slider.value,slider));
  custom.addEventListener('input',()=>{const v=parseInt(custom.value);if(v>0)setAmt(v,custom)});
  const step=d=>()=>setAmt(amt+(amt<10?d:d*5));
  const balTxt=unlim?'♾️ نامحدود':(balN==null?'…':fa(balN));
  const sendBtn=h('button',{class:'btn goldbtn',onclick:async e=>{if(balN!=null&&!unlim&&amt>balN){toast('موجودی ستاره کافی نیست ⭐');return}e.target.disabled=true;try{const r=await call('star_react',{message_id:m.id,amount:amt});applyUpdate(r.message);closeDialog();toast('⭐ '+fa(amt)+' ستاره برای فرستنده ارسال شد')}catch(err){toast(err.message);e.target.disabled=false}}},'ارسال ⭐');
  dialog('⭐ ری‌اکشن ستاره‌ای',
    h('p',{class:'muted',style:'line-height:2'},'نوار رو بکش یا با − و + مبلغ رو انتخاب کن؛ ستاره‌ها از موجودیت کم میشه و مستقیم به فرستندهٔ پیام می‌رسه، توی هر چتی.'),
    h('p',{},'موجودی شما: ',h('b',{},balTxt)),
    h('div',{style:'text-align:center;margin:6px 0'},amtLbl),
    h('div',{class:'starctl'},h('button',{type:'button',class:'starstep',onclick:step(-1)},'−'),slider,h('button',{type:'button',class:'starstep',onclick:step(1)},'+')),
    h('div',{style:'text-align:center'},custom),
    (balN===0&&!unlim)?h('p',{class:'muted',style:'text-align:center;margin-top:8px'},'موجودیت صفره؛ از بخش «🎁 گیفت و ستاره‌ها» روزانه ۲۵ ستارهٔ رایگان بگیر.'):null,
    h('div',{class:'row',style:'margin-top:14px'},sendBtn,h('button',{class:'btn ghost',onclick:()=>closeDialog()},'لغو')))}
function rxBurst(mid,emoji){try{const b=document.querySelector('.mrow[data-id="'+mid+'"] .bubble');if(!b)return;const sp=h('span',{class:'rxburst'},h('span',{class:'aemo a-'+emoAnim(emoji)},emoji));b.append(sp);setTimeout(()=>sp.remove(),980)}catch{}}
function bubble(m,pos){
  const mine=m.sender_id===S.me.id,c=S.chats[m.chat_id]||{};
  const mediaOnly=!m.deleted&&m.file&&!m.body&&!m.reply&&!m.fwd&&!m.file.voice&&(m.file.kind==='image'||m.file.kind==='video')&&!(c.kind==='group'&&!mine&&pos.first);
  const b=h('div',{class:'bubble'+(mediaOnly?' media-only':''),'data-bid':m.id});
  if(c.kind==='group'&&!mine&&m.sender_name&&pos.first)b.append(h('div',{class:'sender',style:'color:'+COLORS[(m.sender_id||0)%COLORS.length]},m.sender_name,m.sender_tag?h('span',{class:'gtag'},m.sender_tag):null));
  if(m.fwd)b.append(h('div',{class:'fwd'},'فوروارد از '+(m.fwd.name||m.fwd.sender_name||m.fwd)));
  if(m.reply&&!m.deleted)b.append(h('div',{class:'quote',onclick:e=>{e.stopPropagation();jumpTo(m.reply.id)}},h('b',{},m.reply.sender_name||''),h('span',{},short(m.reply.text,70))));
  if(m.deleted)b.append(h('div',{class:'deleted'},'این پیام حذف شد'));
  else{if(m.file)b.append(fileBlock(m));if(m.gift){b.append(giftEl(m))}else if(m.sticker){b.classList.add('stk');b.append(stickerEl(m))}else if(m.body)b.append(bodyEl(m));if(window.wdBubble)window.wdBubble.forEach(f=>{try{f(b,m)}catch{}})}
  const meta=h('div',{class:'meta'});if(m.edited_at&&!m.deleted)meta.append(h('span',{},'ویرایش‌شده'));
  if(mine&&m.file&&m.file.voice&&(m.file.played||[]).length)meta.append(h('span',{class:'vheard',title:'پیام صوتی شنیده شد'},ic('headphones',13),c.kind==='group'?fa(m.file.played.length):'شنیده شد'));
  meta.append(h('span',{},fmtTime(m.created_at)));if(mine&&!m.deleted)meta.append(tickEl(m));b.append(meta);
  const rb=reactBar(m);if(rb)b.append(rb);
  attachMenu(b,m);
  const row=h('div',{class:'mrow '+(mine?'mine':'theirs')+(pos.first?' first gap':'')+(pos.last?' last':'')+(Date.now()-(window.__live||0)<400?' new':''),'data-id':m.id},b);
  if(!mine&&c.kind==='group'){const av=h('div',{class:'av'});if(pos.last&&m.sender_id){const u=h('div',{onclick:()=>showUser(m.sender_id,m.sender_name)});u.append(avatar('u',m.sender_id,m.sender_name,(S.users['a'+m.sender_id])||0,34,false));av.append(u)}row.append(av)}
  return row}
function attachMenu(b,m){
  b.addEventListener('contextmenu',e=>{if(m.deleted||e.target.closest('a,.spoiler'))return;e.preventDefault();msgMenu(e.clientX,e.clientY,m)});
  let t=null,sx=0,sy=0;
  b.addEventListener('touchstart',e=>{if(m.deleted)return;const p=e.touches[0];sx=p.clientX;sy=p.clientY;t=setTimeout(()=>{t=null;msgMenu(sx,sy,m)},480)},{passive:true});
  const cancel=()=>{clearTimeout(t);t=null};b.addEventListener('touchend',cancel);b.addEventListener('touchmove',e=>{const p=e.touches[0];if(Math.abs(p.clientX-sx)>10||Math.abs(p.clientY-sy)>10)cancel()},{passive:true});
  b.addEventListener('dblclick',e=>{if(!m.deleted&&!e.target.closest('video,audio,a'))react(m,'👍')});
  // swipe the message to the LEFT → reply (like Telegram); the bubble follows the finger
  const row=b.closest('.mrow')||b;let gx=0,gy=0,mode=0,dx=0,hint=null;
  const skip=e=>!!e.target.closest('audio,video,input,textarea,.spoiler');
  const reset=(anim)=>{if(hint){hint.remove();hint=null}row.style.transition=anim?'transform .18s':'';row.style.transform='';mode=0;dx=0;if(anim)setTimeout(()=>{row.style.transition=''},200)};
  b.addEventListener('touchstart',e=>{mode=0;dx=0;if(m.deleted||m.kind==='system'||e.touches.length!==1||skip(e))return;const p=e.touches[0];gx=p.clientX;gy=p.clientY;mode=1},{passive:true});
  b.addEventListener('touchmove',e=>{if(!mode)return;const p=e.touches[0],x=p.clientX-gx,y=p.clientY-gy;
    if(mode===1){if(Math.abs(y)>10&&Math.abs(y)>Math.abs(x)){mode=0;return}if(x<-12&&Math.abs(x)>Math.abs(y)*1.5){mode=2;cancel();
      if(!hint){hint=h('div',{class:'swr'});const s=document.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('viewBox','0 0 24 24');const pa=document.createElementNS('http://www.w3.org/2000/svg','path');pa.setAttribute('d',IC.reply);s.append(pa);hint.append(s);row.append(hint)}}else return}
    dx=Math.max(-90,Math.min(0,x));row.style.transition='';row.style.transform='translateX('+dx+'px)';
    if(hint){const k=Math.min(1,-dx/60);hint.style.opacity=k;hint.style.transform='translateY(-50%) scale('+(.5+.5*k)+')'}
    if(e.cancelable)e.preventDefault()},{passive:false});
  const fin=e=>{if(mode===2){const ok=-dx>=60;reset(true);if(ok){try{navigator.vibrate&&navigator.vibrate(12)}catch{}const cc=S.chats[m.chat_id];if(!(cc&&cc.channel&&!cc.can_post))startReply(m)}}else mode=0};
  b.addEventListener('touchend',fin);b.addEventListener('touchcancel',()=>reset(true))}
function samePos(a,b){return a&&b&&a.kind!=='system'&&b.kind!=='system'&&a.sender_id===b.sender_id&&dkey(a.created_at)===dkey(b.created_at)&&Math.abs(a.created_at-b.created_at)<300}
function addRows(list,startIdx,box,state){
  for(let i=startIdx;i<list.length;i++){
    const m=list[i];if(m.deleted)continue;                        // deleted messages vanish, like Telegram
    const k=dkey(m.created_at);
    if(k!==state.day){box.append(h('div',{class:'day'},h('span',{},dayLabel(m.created_at))));state.day=k}
    if(S.unreadFrom!=null&&!state.divDone&&m.id>S.unreadFrom&&m.sender_id!==S.me.id&&m.kind!=='system'){box.append(h('div',{class:'unread-div',id:'udiv'},'پیام‌های خوانده‌نشده'));state.divDone=true;state.divPos=state.rows||0}
    if(m.kind==='system'){state.rows=(state.rows||0)+1;box.append(h('div',{class:'sys','data-id':m.id},h('span',{},m.body)));continue}
    state.rows=(state.rows||0)+1;box.append(bubble(m,{first:!samePos(list[i-1],m),last:!samePos(m,list[i+1])}))}}
function renderMsgs(anchor){
  saveCache();
  const box=$('#msgs'),id=S.current;box.replaceChildren();const list=S.msgs[id]||[];
  box.append(h('div',{class:'spacer'}));
  if(S.hasMore[id])box.append(h('div',{class:'older'},h('button',{class:'btn soft',onclick:loadOlder},'پیام‌های قدیمی‌تر…')));
  const st={day:null,rows:0,divPos:0};addRows(list,0,box,st);S.state=st;
  if(window.wdChat)setTimeout(()=>window.wdChat.forEach(f=>f()),0);
  if(!list.length)box.append(h('div',{class:'hint',style:'position:relative;color:#fff'},S.chats[id]&&S.chats[id].saved?'اینجا هر چیزی رو برای خودت ذخیره کن':'هنوز پیامی نیست؛ سلام بده 👋'));
  const a=anchor&&box.querySelector(`[data-id="${anchor}"]`),ud=!anchor&&$('#udiv');
  const jump=T=>{box.style.scrollBehavior='auto';box.scrollTop=T;box.style.scrollBehavior=''};
  const place=()=>{
    if(a){a.scrollIntoView({block:'center',behavior:'instant'});return}
    if(ud&&st.divPos>1){jump(box.scrollTop+ud.getBoundingClientRect().top-box.getBoundingClientRect().top-6);return}
    jump(box.scrollHeight)};
  place();
  requestAnimationFrame(()=>{place();const y=box.scrollTop;
    setTimeout(()=>{if(Math.abs(box.scrollTop-y)<=2)place()},380)});
  updateDown()}
function flash(mid){const b=$(`#msgs [data-bid="${mid}"]`);if(!b)return;b.classList.add('flash');setTimeout(()=>b.classList.remove('flash'),1600)}
async function loadOlder(){
  const id=S.current,first=S.msgs[id]&&S.msgs[id][0];if(!first)return;
  try{const r=await call('history',{chat_id:id,before_id:first.id,limit:40});S.msgs[id]=r.messages.concat(S.msgs[id]);S.hasMore[id]=r.has_more;if(S.current===id)renderMsgs(first.id)}catch(e){toast(e.message)}}
async function jumpTo(mid){
  const e=$(`#msgs [data-bid="${mid}"]`);
  if(e){e.scrollIntoView({block:'center',behavior:'smooth'});flash(mid)}else await loadAround(mid)}
const nearBottom=()=>{const b=$('#msgs');return b.scrollHeight-b.scrollTop-b.clientHeight<140};
function updateDown(){const far=!nearBottom()||S.hasNewer[S.current];$('#down').hidden=!far;
  const d=$('#down');d.replaceChildren(ic('down'),...(S.newBelow?[h('span',{class:'badge'},fa(S.newBelow))]:[]))}
async function scrollBottom(){
  const id=S.current;
  if(S.hasNewer[id]){try{const r=await call('history',{chat_id:id,limit:40});S.msgs[id]=r.messages;S.hasMore[id]=r.has_more;S.hasNewer[id]=false;S.unreadFrom=null;renderMsgs()}catch(e){toast(e.message)}}
  $('#msgs').scrollTo({top:$('#msgs').scrollHeight,behavior:'smooth'});S.newBelow=0;markRead(id)}
function markRead(id){
  const c=S.chats[id];if(!c||document.visibilityState!=='visible'||S.hasNewer[id])return;
  const l=S.msgs[id],last=l&&l.length?l[l.length-1].id:(c.last?c.last.id:0);
  if(last&&last>(S.readSent[id]||0)){S.readSent[id]=last;call('read',{chat_id:id,up_to:last}).catch(()=>{})}
  if(c.unread){c.unread=0;renderList()}}
function ingest(m){
  const id=m.chat_id,c=S.chats[id];if(!c)return refreshChats();
  const l=S.msgs[id];
  if(!l)(S.early[id]=S.early[id]||[]).push(m);          // history still loading: merge when it arrives
  if(l&&!S.hasNewer[id]){if(l.some(x=>x.id===m.id))return;l.push(m);l.sort((a,b)=>a.id-b.id)}
  c.last=m;if(m.sender_id!==S.me.id&&ARCH.has(id)){ARCH.delete(id);archSave()}
  const mine=m.sender_id===S.me.id,viewing=id===S.current&&document.visibilityState==='visible';
  if(!mine&&m.kind!=='system'&&!viewing)c.unread++;
  if(id===S.current&&l&&!S.hasNewer[id]){
    const stick=mine||nearBottom(),box=$('#msgs');box.querySelectorAll('.hint').forEach(x=>x.remove());
    const prev=l[l.length-2];
    if(prev&&samePos(prev,m)){const pr=box.querySelector(`[data-id="${prev.id}"]`);if(pr)pr.classList.remove('last')}
    addRows(l,l.length-1,box,S.state||{day:null});
    if(stick){box.scrollTop=box.scrollHeight;S.newBelow=0}else if(!mine)S.newBelow++;
    updateDown();if(!mine&&viewing&&stick)markRead(id)}
  if(!mine&&m.kind!=='system')notify(c,m);
  renderList();if(id===S.current&&window.wdChat)window.wdChat.forEach(f=>f())}
const heartsOf=m=>{const r=(m&&m.reactions||[]).find(x=>x.e==='❤️'||x.e==='❤');return r?r.users.length:0};
/* a ❤️ reaction: hearts float up from the message and the bubble beats */
function heartBurst(el){
  if(!el||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  el.classList.remove('heartbeat');void el.offsetWidth;el.classList.add('heartbeat');setTimeout(()=>el.classList.remove('heartbeat'),1000);
  const box=h('div',{class:'hearts'});for(let i=0;i<9;i++){const s=h('span',{style:`left:${10+Math.random()*80}%;animation-delay:${Math.random()*.35}s;font-size:${14+Math.random()*16}px`},'❤️');box.append(s)}
  el.append(box);setTimeout(()=>box.remove(),1800);try{navigator.vibrate&&navigator.vibrate([25,40,25])}catch{}}
function applyUpdate(m){
  const l=S.msgs[m.chat_id];const prev=l&&l.find(x=>x.id===m.id);const gotHeart=heartsOf(m)>heartsOf(prev);if(l){const i=l.findIndex(x=>x.id===m.id);if(i>=0)l[i]=m}
  const c=S.chats[m.chat_id];if(c&&c.last&&c.last.id===m.id)c.last=m;
  if(m.chat_id===S.current&&l){const old=$(`#msgs [data-id="${m.id}"]`);if(old){const i=l.findIndex(x=>x.id===m.id);
    if(m.deleted){const r=old.closest('.mrow')||old;r.style.maxHeight=r.offsetHeight+'px';void r.offsetHeight;r.classList.add('gone');setTimeout(()=>r.remove(),240);renderList();return}
    const nw=m.kind==='system'?old:bubble(m,{first:old.classList.contains('first'),last:old.classList.contains('last')});if(nw!==old)old.replaceWith(nw);if(gotHeart)heartBurst((nw.querySelector&&nw.querySelector('.bubble'))||nw)}}
  renderList()}

/* ---------- notifications ---------- */
let ac=null;
function beep(freq=880,len=.12,vol=.05){try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();ac.resume&&ac.resume();const o=ac.createOscillator(),g=ac.createGain();o.frequency.value=freq;g.gain.value=vol;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+len)}catch{}}
/* synthesized sounds (no files needed): send / message in the open chat / notification */
/* Eternal Dragon cinematic show: real video of the dragon flying + breathing fire */
function dragonShow(bdId){ if(document.getElementById('dshow'))return;
  const v=h('video',{class:'dshow-v',src:'/static/dragon.mp4',poster:'/static/dragon.jpg',loop:'',playsinline:'',preload:'auto'});
  v.autoplay=true;
  const ov=h('div',{id:'dshow'},v,h('div',{class:'dshow-cap'},'🐉 اژدهای جاودان — تنها نسخهٔ جهان'),h('button',{class:'dshow-x'},'✕'));
  if(bdId&&typeof NFT_BD!=='undefined'&&NFT_BD[bdId])ov.style.background=NFT_BD[bdId].g;
  ov.querySelector('.dshow-x').onclick=e=>{e.stopPropagation();closeDragonShow()};
  ov.onclick=()=>closeDragonShow();
  v.addEventListener('error',()=>{v.replaceWith(h('img',{class:'dshow-fly',src:'/static/dragon.jpg',alt:'🐉'}))},{once:true});
  document.body.appendChild(ov);
  try{const p=v.play();if(p&&p.catch)p.catch(()=>{v.muted=true;try{v.play()}catch(e){}})}catch(e){}}
function closeDragonShow(){const o=document.getElementById('dshow');if(o){const v=o.querySelector('video');if(v)try{v.pause()}catch(e){} o.remove()}}
let _roarEl=null;
function dragonRoarReal(){try{ if(!_roarEl){_roarEl=new Audio('/static/dragon-roar.mp3');_roarEl.preload='auto'} _roarEl.currentTime=0; const p=_roarEl.play(); if(p&&p.catch)p.catch(()=>dragonRoar()); }catch(e){dragonRoar()}}
function dragonRoar(){try{
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  window._rac=window._rac||new AC();const ac=window._rac,t=ac.currentTime;if(ac.state==='suspended')ac.resume();
  const out=ac.createGain();out.gain.value=.5;out.connect(ac.destination);
  const shaper=ac.createWaveShaper();const curve=new Float32Array(256);for(let i=0;i<256;i++){const x=i/128-1;curve[i]=Math.tanh(2.6*x)}shaper.curve=curve;
  const lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(900,t);lp.frequency.exponentialRampToValueAtTime(220,t+1.1);lp.Q.value=2;
  const g=ac.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.9,t+.09);g.gain.setValueAtTime(.9,t+.55);g.gain.exponentialRampToValueAtTime(.001,t+1.25);
  shaper.connect(lp);lp.connect(g);g.connect(out);
  const lfo=ac.createOscillator();lfo.frequency.value=27;const lg=ac.createGain();lg.gain.value=.28;lfo.connect(lg);lg.connect(g.gain);lfo.start(t);lfo.stop(t+1.3);
  [82,110.5,55].forEach((f,i)=>{const o=ac.createOscillator();o.type=i===2?'sine':'sawtooth';o.frequency.setValueAtTime(f*1.35,t);o.frequency.exponentialRampToValueAtTime(f*.72,t+1.05);o.connect(shaper);o.start(t);o.stop(t+1.3)});
  const len=Math.floor(ac.sampleRate*1.2),buf=ac.createBuffer(1,len,ac.sampleRate),d=buf.getChannelData(0);for(let i=0;i<len;i++)d[i]=Math.random()*2-1;
  const ns=ac.createBufferSource();ns.buffer=buf;const bp=ac.createBiquadFilter();bp.type='bandpass';bp.frequency.setValueAtTime(620,t);bp.frequency.exponentialRampToValueAtTime(180,t+1.1);bp.Q.value=.8;
  const ng=ac.createGain();ng.gain.setValueAtTime(0,t);ng.gain.linearRampToValueAtTime(.34,t+.12);ng.gain.exponentialRampToValueAtTime(.001,t+1.15);
  ns.connect(bp);bp.connect(ng);ng.connect(out);ns.start(t);ns.stop(t+1.25);
}catch(e){}}
function sfx(kind){
  if(!PREF.sound)return;
  try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state==='suspended')ac.resume();const t=ac.currentTime;
    const tone=(f,st,d,v=.07,f2,type='sine')=>{const o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.setValueAtTime(f,t+st);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+st+d);
      g.gain.setValueAtTime(.0001,t+st);g.gain.exponentialRampToValueAtTime(v,t+st+.012);g.gain.exponentialRampToValueAtTime(.0001,t+st+d);
      o.connect(g);g.connect(ac.destination);o.start(t+st);o.stop(t+st+d+.03)};
    if(kind==='send'){tone(520,0,.12,.08,880);tone(1040,.02,.1,.028,1560)}
    else if(kind==='recv'){tone(1175,0,.09,.045);tone(1568,.07,.15,.04)}
    else if(kind==='pop'){tone(660,0,.06,.055);tone(990,.045,.09,.045)}
    else if(kind==='tap'){tone(840,0,.045,.026,760,'triangle')}
    else if(kind==='open'){tone(590,0,.07,.033,830,'triangle')}
    else if(kind==='toggle'){tone(740,0,.05,.038,980)}
    else if(kind==='error'){tone(220,0,.16,.055,185,'triangle')}
    else if(kind==='success'){tone(784,0,.1,.05);tone(1046,.09,.12,.05);tone(1319,.18,.22,.055)}
    else if(kind==='lock'){tone(980,0,.08,.04,660)}
    else{tone(784,0,.13);tone(988,.11,.13);tone(1319,.22,.26,.07)}}catch{}}
document.addEventListener('pointerdown',e=>{try{
  if(e.target.closest('#bnav button'))return sfx('tap');
  if(e.target.closest('#filters .chip'))return sfx('tap');
  if(e.target.closest('.dlg .seg button'))return sfx('tap');
  if(e.target.closest('.pact'))return sfx('tap');
  if(e.target.closest('.tog'))return sfx('toggle');
}catch{}},{passive:true});
let swReg=null;
async function registerSW(){
  if(swReg||window.WD||!('serviceWorker' in navigator))return;      // the Android app has its own notifications and its own cache
  try{swReg=await navigator.serviceWorker.register('/sw.js',{scope:'/'});setTimeout(pushSync,1500)}catch{swReg=null}}   // fails on an untrusted self-signed certificate: we fall back to plain Notification
/* ---- Web Push: wake-up notifications while the app is closed ---- */
const u8key=s=>{const p='='.repeat((4-s.length%4)%4),b=atob((s+p).replace(/-/g,'+').replace(/_/g,'/')),o=new Uint8Array(b.length);for(let i=0;i<b.length;i++)o[i]=b.charCodeAt(i);return o};
async function pushSync(){
  try{
    if(!PREF.notif||!swReg||!swReg.pushManager||!('Notification' in window)||Notification.permission!=='granted')return;
    let sub=await swReg.pushManager.getSubscription();
    if(!sub){const k=await call('push_key');sub=await swReg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:u8key(k.key)})}
    await call('push_subscribe',{endpoint:sub.endpoint})}catch{}}
async function pushDiag(delay){
  const L=[],add=(ok,t)=>L.push([ok,t]);
  add(window.isSecureContext,'اتصال امن (HTTPS معتبر) '+(window.isSecureContext?'':'— گواهی روی این گوشی معتبر نیست'));
  if(!('serviceWorker' in navigator)){add(false,'مرورگر سرویس‌ورکر نداره');return L}
  if(!swReg){try{swReg=await navigator.serviceWorker.register('/sw.js',{scope:'/'})}catch(e){add(false,'ثبت سرویس‌ورکر نشد: '+(e.message||e)+' — معمولاً یعنی گواهی معتبر نیست');return L}}
  add(true,'سرویس‌ورکر ثبت شده');
  if(!('Notification' in window)){add(false,'مرورگر اعلان نداره');return L}
  if(Notification.permission==='default'){try{await Notification.requestPermission()}catch{}}
  add(Notification.permission==='granted','اجازه اعلان: '+({granted:'داده شده',denied:'رد شده (تنظیمات سایت تو کروم رو چک کن)',default:'جواب داده نشد'})[Notification.permission]);
  if(Notification.permission!=='granted')return L;
  if(!PREF.notif){lsSet('wd-notif','1');PREF.notif=true}
  if(!swReg.pushManager){add(false,'این مرورگر Push نداره');return L}
  try{let sub=await swReg.pushManager.getSubscription();if(!sub){const k=await call('push_key');sub=await swReg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:u8key(k.key)})}
    await call('push_subscribe',{endpoint:sub.endpoint});add(true,'اشتراک اعلان ثبت شد')}
  catch(e){add(false,'ثبت اشتراک ناموفق: '+(e.message||e)+' — معمولاً یعنی گوشی به سرویس اعلان گوگل (FCM) وصل نمی‌شه');return L}
  try{const r=await call('push_test',{delay:!!delay});
    const ok=r.codes.length&&r.codes.every(c=>c>=200&&c<300);
    add(!!ok,'سرور → سرویس اعلان: '+(r.codes.join('، ')||'اشتراکی نیست')+(ok?' (قبول شد)':r.codes.includes(-1)?' — سرور نمی‌تونه به سرویس اعلان گوگل وصل بشه (اینترنت بین‌الملل سرور؟)':r.codes.includes(0)?' — آدرس رد شد':' — سرویس اعلان درخواست رو رد کرد'))}
  catch(e){add(false,'آزمایش سرور: '+e.message)}
  return L}
function dlgPushTest(){
  const box=h('div',{style:'line-height:2'},'در حال بررسی…');
  dialog('بررسی اعلان',box,h('div',{class:'muted',style:'font-size:13px;line-height:1.8'},'بعد از بررسی، تا ۱۰ ثانیه برنامه رو ببند یا صفحه گوشی رو قفل کن؛ باید اعلان «پیام جدید داری» بیاد.'));
  pushDiag(true).then(L=>box.replaceChildren(...L.map(([ok,t])=>h('div',{},(ok?'✅ ':'❌ ')+t))))}
async function pushOff(){try{const sub=swReg&&swReg.pushManager&&await swReg.pushManager.getSubscription();if(sub){await call('push_unsubscribe',{endpoint:sub.endpoint}).catch(()=>{});await sub.unsubscribe()}}catch{}}
setInterval(()=>{if(document.visibilityState==='visible'&&ws&&ws.readyState===1&&S.me)call('visible',{v:true}).catch(()=>{})},20000);   // heartbeat: a phone that froze the page stops sending it, so the server knows to push
document.addEventListener('visibilitychange',()=>{if(ws&&ws.readyState===1&&S.me)call('visible',{v:document.visibilityState==='visible'}).catch(()=>{})});
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{if(e.data&&e.data.resub)pushSync()});
function showNote(title,body,tag,cid){
  const open=()=>{window.focus();openChat(cid)};
  if(swReg&&swReg.showNotification){swReg.showNotification(title,{body,tag,icon:'/static/icon.svg',badge:'/static/icon.svg',data:{cid},renotify:true,dir:'rtl',lang:'fa'}).catch(()=>plainNote(title,body,tag,open));return}
  plainNote(title,body,tag,open)}
function plainNote(title,body,tag,open){try{const n=new Notification(title,{body,tag,icon:'/static/icon.svg'});n.onclick=()=>{open();n.close()}}catch{}}
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{if(e.data&&e.data.cid&&S.chats[e.data.cid]){window.focus();openChat(e.data.cid)}});
function notify(c,m){
  if(c.muted)return;const viewing=c.id===S.current&&document.visibilityState==='visible';
  if(viewing){sfx('recv');return}
  sfx('notif');
  if(PREF.notif&&'Notification' in window&&Notification.permission==='granted'&&document.visibilityState!=='visible'){
    const t=m.secret?'🔑 پیام محرمانه':m.file?(m.file.voice?'🎤 پیام صوتی':'📎 '+m.file.name):m.body;
    showNote(c.title,short((c.kind==='group'&&m.sender_name?m.sender_name+': ':'')+t,100),'c'+c.id,c.id)}}

/* ---------- events ---------- */
function onEvent(e){
  const k=e.event;
  if(k==='message'){window.__live=Date.now();ingest(e.message)}
  else if(k==='message_updated')applyUpdate(e.message);
  else if(k==='read'){const c=S.chats[e.chat_id];if(c&&e.user_id!==S.me.id){c.peer_read=Math.max(c.peer_read||0,e.up_to);
    document.querySelectorAll('.tick[data-mid]').forEach(t=>{if(+t.dataset.mid<=e.up_to&&!t.classList.contains('read')){t.classList.add('read');t.replaceChildren(ic('checkall',16))}})}}
  else if(k==='typing'){S.typing[e.chat_id+':'+e.user_id]={exp:Date.now()+4000,action:e.action};if(e.chat_id===S.current)refreshSub();renderList();setTimeout(()=>{refreshSub();renderList()},4300)}
  else if(k==='presence'){Object.values(S.chats).forEach(c=>{if(c.peer&&c.peer.id===e.user_id){c.peer.online=e.online;c.peer.last_seen=e.last_seen;c.peer.seen_hidden=!!e.seen_hidden}});renderList();refreshSub()}
  else if(k==='profile'){const u=e.user;S.users[u.id]=u.display_name;S.users['a'+u.id]=u.avatar_at;if(u.id===S.me.id){Object.assign(S.me,u);buildDrawer()}
    Object.values(S.chats).forEach(c=>{if(c.peer&&c.peer.id===u.id){c.peer=u;if(c.kind==='private')c.title=u.display_name}});renderList();if(S.current)fillHeader();if(S.current)renderMsgs&&softRender()}
  else if(k==='chat_added'){S.chats[e.chat.id]=e.chat;renderList()}
  else if(k==='chat_updated'){const old=S.chats[e.chat.id]||{};S.chats[e.chat.id]=Object.assign(old,e.chat);renderList();if(S.current===e.chat.id)fillHeader()}
  else if(k==='voice_played'){const l=S.msgs[e.chat_id],m=l&&l.find(x=>x.id===e.message_id);if(m&&m.file){m.file.played=m.file.played||[];if(!m.file.played.includes(e.user_id))m.file.played.push(e.user_id);if(e.user_id!==S.me.id)applyUpdate(m)}}
  else if(k==='call_peer'){if(C&&C.id===e.call_id){C.peerAway=e.state==='reconnecting';showCallUI()}}
  else if(k==='chat_removed'){delete S.chats[e.chat_id];delete S.msgs[e.chat_id];if(S.current===e.chat_id){S.current=null;showChatView(false);$('#app').classList.remove('show-chat')}renderList()}
  else if(k==='members_changed'){refreshChats();if(window.__group&&window.__group.id===e.chat_id)window.__group.reload()}
  else if(k==='call_incoming')onIncoming(e);else if(k==='call_accepted')onAccepted(e);else if(k==='call_audio')onCallAudio(e);else if(k==='call_video')onCallVideo(e);else if(k==='call_signal')onSignal(e);
  else if(k==='call_ended'){if(C&&C.id===e.call_id)endLocal(callText[e.reason]||'')}
  else if(k==='session_ended'){setToken(null);logout(true);showAuth('این نشست از دستگاه دیگه بسته شد.')}
  else if(k==='banned'){alert('حساب تو مسدود شد.');setToken(null);logout()}
  else if(window.wdEvents){for(const f of window.wdEvents)if(f(e))break}}
function softRender(){const y=$('#msgs').scrollTop,nb=nearBottom();renderMsgs();$('#msgs').scrollTop=nb?$('#msgs').scrollHeight:y}

/* ---------- composer ---------- */
function autosize(){const t=$('#input');t.style.height='auto';t.style.height=Math.min(140,t.scrollHeight)+'px'}
function showBar(t,x,icn){$('#bar-t').textContent=t;$('#bar-x').textContent=short(x,90);setIcon($('#bar-ic'),icn||'reply');$('#bar').hidden=false}
function clearBar(){S.reply=S.editing=null;$('#bar').hidden=true;updateSendBtn()}
function startReply(m){clearBar();S.reply=m;showBar('پاسخ به '+(m.sender_name||''),m.body||(m.file?(m.file.voice?'پیام صوتی':'📎 '+m.file.name):''));$('#input').focus()}
function startEdit(m){clearBar();S.editing=m;showBar('ویرایش پیام',m.body,'pencil');$('#input').value=m.body;autosize();updateSendBtn();$('#input').focus()}
function updateSendBtn(){
  const has=$('#input').value.trim().length>0||S.editing,b=$('#sendbtn');
  if(REC.on)setIcon(b,'send');else setIcon(b,has?'send':'mic');b.title=has||REC.on?'ارسال':'ضبط پیام صوتی'}
async function sendCurrent(){
  if(REC.on)return finishRec();
  const t=$('#input'),text=t.value.trim();
  if(!S.current)return;if(!text&&!S.editing)return startRec();
  if(S.editing){const m=S.editing;clearBar();t.value='';autosize();updateSendBtn();
    try{const r=await call('edit',{message_id:m.id,text});applyUpdate(r.message)}catch(e){toast(e.message)}return}
  const id=S.current,reply=S.reply?S.reply.id:null;t.value='';delete S.drafts[id];saveDrafts();clearBar();autosize();updateSendBtn();
  try{const r=await call('send',{chat_id:id,text,reply_to:reply});sfx('send');window.__live=Date.now();ingest(r.message);$('#msgs').scrollTop=$('#msgs').scrollHeight}catch(e){toast(e.message);if(!t.value)t.value=text;autosize();updateSendBtn()}}
/* upload with progress (raw body -> /upload; voice params make it a voice message) */
function uploadBlob(blob,name,opts={}){
  if(!S.current)return;const max=S.maxUpload||5*1048576;
  if(blob.size>max)return toast('حجم فایل بیشتر از '+fa(Math.round(max/1048576))+' مگابایته');
  if(!S.mediaKey)return toast('هنوز به سرور وصل نیستی');
  const cc=S.chats[S.current];if(cc&&cc.channel&&!cc.can_post)return toast('فقط مدیر می‌تونه تو کانال پیام بذاره');
  const th=(!opts.voice&&/^(image|video)\//.test(blob.type||''))?makeThumb(blob,blob.type.split('/')[0]):null;
  const id=S.current,q=new URLSearchParams({k:S.mediaKey,chat_id:id,name});
  if(opts.caption)q.set('text',opts.caption);if(opts.reply)q.set('reply_to',opts.reply);
  if(opts.voice){q.set('voice','1');q.set('dur',String(opts.dur||0));q.set('wave',(opts.wave||[]).join(','))}
  /* Telegram-style outgoing bubble: round button with a progress ring and an X (tap = cancel), name, "sent / total" */
  const R=21,CIRC=2*Math.PI*R,ring=document.createElementNS('http://www.w3.org/2000/svg','circle');
  ring.setAttribute('cx',24);ring.setAttribute('cy',24);ring.setAttribute('r',R);ring.setAttribute('class','ring');ring.style.strokeDasharray=CIRC;ring.style.strokeDashoffset=CIRC*.85;
  const rsvg=document.createElementNS('http://www.w3.org/2000/svg','svg');rsvg.setAttribute('viewBox','0 0 48 48');rsvg.setAttribute('class','ringsvg');rsvg.append(ring);
  const ext=(name.includes('.')?name.split('.').pop():'').slice(0,4).toUpperCase(),sz=h('small',{},fmtSize(blob.size)+(ext?' '+ext:''));
  const cancel=h('button',{class:'ucancel',type:'button',title:'لغو ارسال'},ic('close',22),rsvg);
  const box=h('div',{class:'mrow mine last upl2'},h('div',{class:'bubble'},h('div',{class:'file'},cancel,h('div',{class:'fi'},h('b',{},short(name,34)),sz)),
    h('div',{class:'meta'},h('span',{},fmtTime(Math.floor(Date.now()/1000))),h('span',{class:'tick'},ic('clock',15)))));
  $('#msgs').append(box);$('#msgs').scrollTop=$('#msgs').scrollHeight;
  const x=new XMLHttpRequest();x.open('POST','/upload?'+q);
  cancel.onclick=e=>{e.stopPropagation();x.abort();box.remove()};
  x.upload.onprogress=e=>{if(e.lengthComputable){ring.style.strokeDashoffset=CIRC*(1-Math.max(.06,e.loaded/e.total));sz.textContent=fmtSize(e.loaded)+' / '+fmtSize(e.total)}};
  x.onload=()=>{box.remove();let r={};try{r=JSON.parse(x.responseText)}catch{}if(x.status===200&&r.ok){sfx('send');ingest(r.message);if(th)th.then(t=>{if(t)fetch('/thumb?'+new URLSearchParams({k:S.mediaKey,message_id:r.message.id,w:t.w,h:t.h}),{method:'POST',body:t.blob}).catch(()=>{})});$('#msgs').scrollTop=$('#msgs').scrollHeight}else toast(r.error||'ارسال فایل ناموفق بود')};
  x.onerror=()=>{box.remove();toast('ارسال فایل ناموفق بود')};x.send(blob)}
/* preview picture (first frame / scaled image), made here and uploaded after the message exists */
function makeThumb(file,kind){
  return new Promise(res=>{
    if(kind==='image'&&typeof file!=='string'&&(/gif$/i.test(file.type)||file.size>60*1048576))return res(null);
    const own=typeof file!=='string',url=own?URL.createObjectURL(file):file;let fin=false;const done=v=>{if(fin)return;fin=true;if(own)URL.revokeObjectURL(url);res(v)};
    const draw=(el,w,hh)=>{if(!w||!hh)return done(null);const k=Math.min(1,320/Math.max(w,hh)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*k));c.height=Math.max(1,Math.round(hh*k));
      try{c.getContext('2d').drawImage(el,0,0,c.width,c.height);c.toBlob(b=>done(b?{blob:b,w,h:hh}:null),'image/jpeg',.7)}catch{done(null)}};
    if(kind==='image'){const im=new Image();im.onload=()=>draw(im,im.naturalWidth,im.naturalHeight);im.onerror=()=>done(null);im.src=url}
    else{const v=document.createElement('video');v.muted=true;v.preload='metadata';v.playsInline=true;const t=setTimeout(()=>done(null),9000);
      v.onloadedmetadata=()=>{try{v.currentTime=Math.min(1,(v.duration||2)/4)}catch{}};
      v.onseeked=()=>{clearTimeout(t);draw(v,v.videoWidth,v.videoHeight)};v.onerror=()=>{clearTimeout(t);done(null)};v.src=url}})}
function sendFiles(files){
  const list=[...files];if(!list.length)return;
  const caption=$('#input').value.trim(),reply=S.reply?S.reply.id:null;
  if(caption){$('#input').value='';autosize();updateSendBtn()}clearBar();
  list.forEach((f,i)=>uploadBlob(f,f.name||'file',{caption:i===0?caption:'',reply:i===0?reply:null}))}
/* ---------- files/text shared INTO the app from other apps (Android) ---------- */
window.wdShare=function(){
  try{const raw=window.WD&&WD.takeShare&&WD.takeShare();if(raw)window.__share=JSON.parse(raw)}catch{}
  if(window.__share&&S.me)runShare()};
function runShare(){
  const sh=window.__share;if(!sh)return;window.__share=null;
  const files=sh.files||[],text=(sh.text||'').trim();
  const sum=files.length?fa(files.length)+' فایل'+(text?' + متن':''):'متن';
  const pick=async c=>{
    closeDialog();await openChat(c.id);
    try{
      if(!files.length){if(text){const r=await call('send',{chat_id:c.id,text});sfx('send');ingest(r.message)}return}
      for(let i=0;i<files.length;i++){const f=files[i],r=await fetch('/__wd/share/'+f.i),b=await r.blob();
        uploadBlob(new File([b],f.name,{type:f.mime||b.type}),f.name,{caption:i===0?text:''})}
    }catch(e){toast('ارسال نشد: '+e.message)}};
  const list=h('div',{class:'ulist',style:'max-height:360px'}),q=h('input',{placeholder:'جستجو…',autocomplete:'off'});
  const draw=()=>{const t=q.value.trim().toLowerCase();
    list.replaceChildren(...sorted().filter(c=>!(c.channel&&!c.can_post)&&(!t||(c.title||'').toLowerCase().includes(t))).map(c=>
      h('div',{class:'srow',onclick:()=>pick(c)},chatAvatar(c,40,false),h('div',{class:'grow'},h('b',{},c.saved?'پیام‌های ذخیره‌شده':c.title)))))};
  q.addEventListener('input',draw);draw();
  dialog('ارسال '+sum+' به…',q,list)}

/* ---------- storage used by the Android app ---------- */
function dlgStorage(){
  let info;try{info=JSON.parse(WD.cacheInfo())}catch{return toast('این بخش فقط تو اپ اندروید هست')}
  const mb=b=>fa((b/1048576).toFixed(b<10485760?1:0))+' مگابایت';
  const use=h('div',{style:'font-size:15px;line-height:2'}),draw=()=>{try{info=JSON.parse(WD.cacheInfo())}catch{};use.replaceChildren(h('b',{},mb(info.bytes)),' — '+fa(info.count)+' فایل ذخیره‌شده تو اپ')};draw();
  const opts=[[200,'۲۰۰ مگابایت'],[500,'۵۰۰ مگابایت'],[1024,'۱ گیگابایت'],[2048,'۲ گیگابایت'],[5120,'۵ گیگابایت'],[10240,'۱۰ گیگابایت'],[0,'بدون محدودیت']];
  if(!opts.some(o=>o[0]===info.limit_mb))opts.push([info.limit_mb,mb(info.limit_mb*1048576)]);
  const sel=h('select',{onchange:e=>{try{WD.cacheLimit(+e.target.value)}catch{}draw()}},opts.map(o=>h('option',{value:o[0],selected:o[0]===info.limit_mb},o[1])));
  dialog('مدیریت حافظه',
    h('div',{class:'muted',style:'font-size:13px;line-height:1.9'},'عکس، ویدیو، آهنگ و فایل‌هایی که یک بار باز کردی تو خود اپ نگه داشته می‌شن تا بدون اینترنت هم باز بشن. وقتی از حد مجاز بیشتر بشه، قدیمی‌ترین‌ها خودکار پاک می‌شن.'),
    use,h('label',{},'حداکثر حافظه'),sel,
    h('button',{class:'btn danger',style:'display:block;margin-top:12px',onclick:()=>{if(!confirm('همه فایل‌های ذخیره‌شده پاک بشه؟ (پیام‌ها و فایل‌های روی سرور سر جاشون می‌مونن)'))return;try{WD.cacheClear()}catch{}draw();toast('پاک شد',false)}},'پاک کردن فایل‌های ذخیره‌شده'))}
const DL={big:150*1048576,chunk:8*1048576,blobMax:1024*1048576};
/* download progress line (top of the screen): same for the web page and for the Android app (the app reports through window.wdDl) */
const DLS={},DLN={};
function dlUi(id,name,got,total,state,cancel){
  let c=DLS[id];
  if(!c){const bar=h('i'),pct=h('span',{class:'pc'}),x=cancel?h('button',{class:'iconbtn',title:'لغو',onclick:()=>{const q=DLS[id];q&&q.cancel&&q.cancel()}},ic('close',16)):null;
    const el=h('div',{class:'dlc'},h('div',{class:'dt'},h('b',{},short(name||'فایل',30)),pct,x),h('div',{class:'bar'},bar));
    let box=document.getElementById('dlbox');if(!box){box=h('div',{id:'dlbox'});document.body.append(box)}box.append(el);c=DLS[id]={el,bar,pct,cancel}}
  if(cancel)c.cancel=cancel;
  const p=total>0?Math.min(100,Math.round(got/total*100)):0;
  c.bar.style.width=(state===1?100:p)+'%';c.el.classList.toggle('ok',state===1);c.el.classList.toggle('bad',state===2);
  c.pct.textContent=state===1?'ذخیره شد ✓':state===2?'ناموفق':(total>0?fa(p)+'٪ · '+fa(fmtSize(got))+' / '+fa(fmtSize(total)):fa(fmtSize(got)));
  clearTimeout(c.t);c.t=setTimeout(()=>{c.el.remove();delete DLS[id]},state===1?2500:state===2?4500:90000)}     // a bar that gets no news for 90 s goes away
window.wdDl=(id,got,total,state)=>dlUi('a'+id,DLN[id],got,total,state);
/* one piece of the file; a dropped connection retries that piece only (the server answers Range requests); onBytes = live progress */
async function dlPiece(url,a,b,onBytes,signal){
  for(let t=0;;t++){
    try{const r=await fetch(url,{headers:{Range:'bytes='+a+'-'+b},signal});if(r.status!==206&&!(r.status===200&&a===0))throw new Error('http '+r.status);
      if(!r.body||!r.body.getReader)return await r.blob();
      const rd=r.body.getReader(),parts=[];let n=0;for(;;){const{done,value}=await rd.read();if(done)break;parts.push(value);n+=value.length;onBytes&&onBytes(n)}
      return new Blob(parts)}
    catch(e){if(e&&e.name==='AbortError')throw e;if(t>=3)throw e;await new Promise(z=>setTimeout(z,1200*(t+1)))}}}
async function download(m){
  if(!S.mediaKey&&!window.WD)return toast('هنوز به سرور وصل نیستی');
  if(window.WD&&WD.saveFile){try{DLN[m.id]=m.file.name;dlUi('a'+m.id,m.file.name,0,m.file.size||0,0);WD.saveFile(location.origin+'/media/'+m.id+'?k='+encodeURIComponent(S.mediaKey||'')+'&dl=1',m.file.name);return}catch{}}
  const url=mediaUrl(m,true),name=m.file.name,size=m.file.size||0;
  const direct=()=>{const l=h('a',{href:url,download:name});document.body.append(l);l.click();l.remove()};
  /* Chrome refuses (pauses) a DIRECT download from a site with a self-signed certificate. The page itself is open and trusted by you, so the file
     is read through the page in pieces and saved: straight to disk where the browser allows it (desktop Chrome/Edge: any size), otherwise from memory. */
  if(!size)return direct();
  if(size>DL.big&&!confirm('این فایل '+fmtSize(size)+' هست و دانلودش طول می‌کشه. تا تموم نشده این صفحه رو نبند. ادامه بدم؟'))return;
  let handle=null;
  if(size>DL.big&&window.showSaveFilePicker){try{handle=await showSaveFilePicker({suggestedName:name})}catch(e){if(e&&e.name==='AbortError')return}}
  if(!handle&&size>DL.blobMax){toast('این فایل برای دانلود تو مرورگر خیلی بزرگه؛ با اپ اندروید یا کروم/اج کامپیوتر دانلودش کن',true);return}
  let w=null,got=0,last=0;const parts=[],ab=new AbortController(),id='w'+m.id+'_'+Date.now();
  try{
    if(handle)w=await handle.createWritable();
    dlUi(id,name,0,size,0,()=>ab.abort());
    for(let a=0;a<size;a+=DL.chunk){
      const b=Math.min(a+DL.chunk-1,size-1),base=got,blob=await dlPiece(url,a,b,n=>{if(Date.now()-last>200){last=Date.now();dlUi(id,name,base+n,size,0)}},ab.signal);
      if(w)await w.write(blob);else parts.push(blob);
      got+=blob.size;dlUi(id,name,got,size,0)}
    if(w){await w.close();dlUi(id,name,size,size,1);return}
    const u=URL.createObjectURL(new Blob(parts,{type:'application/octet-stream'})),a=h('a',{href:u,download:name});
    document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);dlUi(id,name,size,size,1)
  }catch(e){
    try{if(w)await w.abort()}catch{}
    const c=DLS[id];if(c){clearTimeout(c.t);c.el.remove();delete DLS[id]}
    if(e&&e.name==='AbortError')return toast('دانلود لغو شد',false);
    if(!got)return direct();
    toast('دانلود قطع شد؛ دوباره امتحان کن')}}

/* ---------- voice recording (MediaRecorder; needs https or localhost) ---------- */
const REC={on:false,rec:null,stream:null,chunks:[],t0:0,levels:[],timer:null,ctx:null,an:null,cancelled:false,mime:'',ext:''};
const MAX_REC=15*60;
function pickMime(){
  const c=[['audio/webm;codecs=opus','.weba'],['audio/webm','.weba'],['audio/ogg;codecs=opus','.ogg'],['audio/mp4','.m4a']];
  for(const [m,e] of c){try{if(MediaRecorder.isTypeSupported(m))return[m,e]}catch{}}return['','.weba']}
async function startRec(){
  if(REC.on||!S.current)return;const cc0=S.chats[S.current];if(cc0&&cc0.channel&&!cc0.can_post)return toast('فقط مدیر می‌تونه تو کانال پیام بذاره');
  if(!window.isSecureContext)return toast('ضبط صدا فقط روی https یا همین کامپیوتر (localhost) کار می‌کنه. با آدرس https باز کن.');
  if(!navigator.mediaDevices||!window.MediaRecorder)return toast('این مرورگر از ضبط صدا پشتیبانی نمی‌کنه');
  if(C)return toast('وسط تماس نمی‌شه ویس ضبط کرد');
  let stream;try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false})}
  catch(e){return toast(e&&e.name==='NotFoundError'?'میکروفونی پیدا نشد':'دسترسی به میکروفون داده نشد؛ از قفل کنار آدرس اجازه بده')}
  const [mime,ext]=pickMime();let rec;
  try{rec=new MediaRecorder(stream,mime?{mimeType:mime}:{})}catch{stream.getTracks().forEach(t=>t.stop());return toast('شروع ضبط ممکن نشد')}
  Object.assign(REC,{on:true,rec,stream,chunks:[],t0:Date.now(),levels:[],cancelled:false,mime:rec.mimeType||mime,ext,chat:S.current,reply:S.reply?S.reply.id:null});
  stopVoice();
  try{REC.ctx=new(window.AudioContext||window.webkitAudioContext)();const src=REC.ctx.createMediaStreamSource(stream);REC.an=REC.ctx.createAnalyser();REC.an.fftSize=512;src.connect(REC.an)}catch{REC.an=null}
  rec.ondataavailable=e=>{if(e.data&&e.data.size)REC.chunks.push(e.data)};
  rec.onstop=onRecStop;rec.start(250);
  $('#rec').hidden=false;$('#lvl').replaceChildren();updateSendBtn();
  let tick=0;REC.timer=setInterval(()=>{
    const s=(Date.now()-REC.t0)/1000;$('#rect').textContent=fmtDur(s);
    let lv=0;if(REC.an){const d=new Uint8Array(REC.an.fftSize);REC.an.getByteTimeDomainData(d);let sum=0;for(const v of d)sum+=((v-128)/128)**2;lv=Math.min(1,Math.sqrt(sum/d.length)*3.2)}
    REC.levels.push(lv);const lvl=$('#lvl');lvl.append(h('i',{style:`height:${Math.max(3,Math.round(lv*28))}px`}));while(lvl.children.length>60)lvl.firstChild.remove();
    if(++tick%30===0)call('typing',{chat_id:REC.chat,action:'voice'}).catch(()=>{});
    if(s>=MAX_REC)finishRec()},100);
  call('typing',{chat_id:REC.chat,action:'voice'}).catch(()=>{})}
function endRecResources(){
  clearInterval(REC.timer);if(REC.stream)REC.stream.getTracks().forEach(t=>t.stop());
  try{REC.ctx&&REC.ctx.close()}catch{}REC.ctx=null;REC.an=null;REC.on=false;$('#rec').hidden=true;updateSendBtn()}
function finishRec(){if(!REC.on)return;REC.cancelled=false;try{REC.rec.stop()}catch{onRecStop()}}
function cancelRec(silent){if(!REC.on)return;REC.cancelled=true;try{REC.rec.stop()}catch{onRecStop()}if(!silent)toast('ضبط لغو شد',false)}
function onRecStop(){
  const dur=(Date.now()-REC.t0)/1000,chunks=REC.chunks,levels=REC.levels,cancelled=REC.cancelled,chat=REC.chat,reply=REC.reply,type=REC.mime||'audio/webm',ext=REC.ext;
  endRecResources();if(cancelled)return;
  if(dur<.7||!chunks.length)return toast('ویس خیلی کوتاه بود');
  const blob=new Blob(chunks,{type});
  const N=40,wave=[];for(let i=0;i<N;i++){const a=Math.floor(i*levels.length/N),b=Math.max(a+1,Math.floor((i+1)*levels.length/N));let mx=0;for(let j=a;j<b&&j<levels.length;j++)mx=Math.max(mx,levels[j]);wave.push(Math.round(mx*31))}
  if(chat!==S.current)openChat(chat);
  if(S.reply)clearBar();
  const stamp=new Date().toISOString().replace(/[-:T]/g,'').slice(0,14);
  uploadBlob(blob,`voice-${stamp}${ext}`,{voice:true,dur:Math.round(dur*10)/10,wave,reply})}

/* ---------- context menus & forwarding ---------- */
function popMenu(x,y,items,top){
  const menu=$('#ctx');menu.replaceChildren();
  if(top)menu.append(top);
  items.forEach(it=>{if(!it)return;const[t,icn,fn,red]=it;menu.append(h('button',{class:red?'red':'',onclick:e=>{e.stopPropagation();menu.hidden=true;fn()}},ic(icn),t))});
  menu.hidden=false;menu.style.left=menu.style.top='0px';
  const w=menu.offsetWidth,hh=menu.offsetHeight;
  menu.style.left=Math.max(6,Math.min(x,innerWidth-w-8))+'px';menu.style.top=Math.max(6,Math.min(y,innerHeight-hh-8))+'px'}
function msgMenu(x,y,m){
  const c=S.chats[m.chat_id]||{},mine=m.sender_id===S.me.id,owner=c.kind==='group'&&(c.owner_id===S.me.id||c.my_role==='admin'),canPin=c.channel?!!c.can_post:(c.kind!=='group'||owner);
  const rx=h('div',{class:'rx'},[h('button',{class:'rxstarbtn',title:'ری‌اکشن ستاره‌ای ⭐',onclick:ev=>{ev.stopPropagation();$('#ctx').hidden=true;dlgStarReact(m)}},'⭐'),...REACTS.map(e=>h('button',{onclick:ev=>{ev.stopPropagation();$('#ctx').hidden=true;react(m,e)}},h('span',{class:'aemo a-'+emoAnim(e)},e)))]);
  const pinned=c.pin_msg&&c.pin_msg.id===m.id;
  popMenu(x,y,[[L('پاسخ','Reply'),'reply',()=>startReply(m)],
    m.body?[L('کپی متن','Copy text'),'copy',()=>navigator.clipboard?navigator.clipboard.writeText(m.body).then(()=>toast('کپی شد',false)).catch(()=>toast('کپی نشد')):toast('کپی نشد')]:null,
    [L('فوروارد','Forward'),'forward',()=>dlgForward(m)],
    canPin?[pinned?L('برداشتن سنجاق','Unpin'):L('سنجاق کردن','Pin'),'pin',()=>call('pin',{chat_id:m.chat_id,message_id:pinned?null:m.id}).catch(e=>toast(e.message))]:null,
    m.file?[L('ذخیره فایل','Save file'),'download',()=>download(m)]:null,
    m.file&&m.file.voice&&mine?[L('چه کسانی گوش دادن','Who listened'),'headphones',()=>toast((m.file.played||[]).length?'شنیده شده توسط: '+m.file.played.map(userName).join('، '):'هنوز کسی گوش نداده',false)]:null,
    mine&&m.body&&!m.file?[L('ویرایش','Edit'),'pencil',()=>startEdit(m)]:(mine&&m.file&&m.body?[L('ویرایش توضیح','Edit caption'),'pencil',()=>startEdit(m)]:null),
    !mine?[L('گزارش','Report'),'info',()=>dlgReport({message_id:m.id})]:null,
    (mine||owner)?[L('حذف','Delete'),'delete',async()=>{if(!confirm('این پیام برای همه حذف بشه؟'))return;try{const r=await call('delete',{message_id:m.id});applyUpdate(r.message)}catch(e){toast(e.message)}},true]:null],rx)}
function dialog(title,...body){
  const m=$('#modal');m.replaceChildren(h('div',{class:'dlg'},h('h3',{},h('span',{class:'grow'},title),h('button',{class:'iconbtn',onclick:closeDialog},ic('close'))),...body));m.hidden=false;
  sfx('open');
  m.onclick=e=>{if(e.target===m)closeDialog()};return m}
function closeDialog(){$('#modal').hidden=true;$('#modal').replaceChildren();window.__group=null}
function dlgForward(m){
  const sel=new Set(),list=h('div',{class:'ulist',style:'max-height:340px'}),btn=h('button',{class:'btn',disabled:true,onclick:async()=>{
    try{const r=await call('forward',{message_id:m.id,chat_ids:[...sel]});closeDialog();(r.messages||[]).forEach(ingest);sfx('send');toast('فوروارد شد',false)}catch(e){toast(e.message)}}},'ارسال');
  sorted().forEach(c=>{const row=h('div',{class:'srow'},chatAvatar(c,40,false),h('div',{class:'grow'},h('b',{},c.title)),h('span',{class:'sw2'}));
    row.onclick=()=>{sel.has(c.id)?sel.delete(c.id):sel.add(c.id);row.lastChild.classList.toggle('on',sel.has(c.id));btn.disabled=!sel.size};list.append(row)});
  dialog('فوروارد به…',list,btn)}

/* ---------- drawer, profile, settings ---------- */
function openDrawer(on){$('#drawer').classList.toggle('on',on);$('#scrim').classList.toggle('on',on)}
function buildDrawer(){
  const d=$('#drawer'),me=S.me;if(!me)return;const ma=$('#meav');if(ma){ma.replaceChildren(avatar('u',me.id,me.display_name,me.avatar_at,38,false));ma.onclick=dlgProfile}
  const item=(icn,t,fn)=>h('button',{class:'ditem',onclick:()=>{openDrawer(false);fn()}},ic(icn),t);
  d.replaceChildren(
    h('div',{class:'dhead',onclick:()=>{openDrawer(false);dlgProfile()}},avatar('u',me.id,me.display_name,me.avatar_at,64,false),
      h('button',{class:'iconbtn moon',onclick:e=>{e.stopPropagation();toggleTheme()},title:'تم'},ic('moon')),
      h('div',{class:'dn'},me.display_name),h('div',{class:'du'},at(me.username))),
    item('person','پروفایل من',dlgProfile),item('group','گروه جدید',()=>dlgNewGroup()),item('channel','کانال جدید',()=>dlgNewGroup(true)),item('pencil','چت جدید',dlgNewChat),item('film','اتاق تماشا',()=>typeof openRoomHub==='function'&&openRoomHub()),item('chatb','ربات‌ها (BotFather)',()=>openPrivate('BotFather')),item('chatb','ربات‌ساز',dlgBotForge),item('story','استوری جدید',()=>window.wdStories&&wdStories.composer()),
    item('bookmark','پیام‌های ذخیره‌شده',()=>openPrivate(me.username)),item('settings','تنظیمات',dlgSettings),item('star','گیفت و ستاره‌ها 🎁',dlgGifts),...(me.is_admin?[item('settings','پنل مدیریت 👑',dlgAdmin)]:[]),item('lock','حریم خصوصی',dlgPrivacy),
    item('devices','دستگاه‌های من',dlgSessions),item('logout','خروج',()=>logout()),
    h('div',{class:'dfoot'},'DarkGram'))}
/* crop the picked photo to a centered square (max 512px) in the browser, then upload */
function cropSquare(file,px=512){
  return new Promise((res,rej)=>{
    const url=URL.createObjectURL(file),img=new Image();
    img.onload=()=>{const s=Math.min(img.naturalWidth,img.naturalHeight),c=document.createElement('canvas');c.width=c.height=Math.min(px,s);
      c.getContext('2d').drawImage(img,(img.naturalWidth-s)/2,(img.naturalHeight-s)/2,s,s,0,0,c.width,c.height);URL.revokeObjectURL(url);
      c.toBlob(b=>b?res(b):rej(new Error('تبدیل عکس ناموفق بود')),'image/jpeg',.9)};
    img.onerror=()=>{URL.revokeObjectURL(url);rej(new Error('این فایل عکس معتبر نیست'))};img.src=url})}
async function postAvatar(file,target,chatId){
  const blob=await cropSquare(file);
  const q=new URLSearchParams({k:S.mediaKey,target});if(chatId)q.set('chat_id',chatId);
  const r=await fetch('/avatar?'+q,{method:'POST',body:blob});const j=await r.json().catch(()=>({}));
  if(!r.ok||!j.ok)throw new Error(j.error||'آپلود عکس ناموفق بود');return j.at}
function photoPicker(getAvatarEl,target,chatId,onDone){
  const inp=h('input',{type:'file',accept:'image/*',hidden:true,onchange:async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
    try{await postAvatar(f,target,chatId);toast('عکس ذخیره شد',false);onDone&&onDone()}catch(er){toast(er.message)}}});
  return[inp,()=>inp.click()]}
const STATUS_EMOJIS=["⭐","👑","💎","🔥","❤️","🚀","🌙","⚡","🎯","🏆","🦄","🐉","🍒","🌟","💜","🖤","✅","🎵","🎮","⚽","🍕","🐱","🦊","🌹","☀️","❄️","🌊","🍀","🎧","💯","🙏","😎","🥇","🛡️","🔮","🦋"];
function dlgEmojiStatus(){
  const grid=h('div',{class:'emogrid'});STATUS_EMOJIS.forEach(e=>grid.append(h('button',{type:'button',style:'font-size:26px;padding:8px',onclick:async()=>{try{await call('set_emoji_status',{emoji:e});S.me.emoji_status=e;closeDialog();toast('ایموجی وضعیت تنظیم شد '+e,false);refreshChats();dlgProfile()}catch(err){toast(err.message)}}},e)));
  dialog('ایموجی وضعیت ⭐',h('div',{class:'hint'},'این ایموجی کنار اسمت توی چت‌ها، پروفایل و پیام‌ها نمایش داده میشه — مثل تلگرام پریمیوم'),grid,
    h('button',{class:'btn soft',onclick:async()=>{try{await call('set_emoji_status',{emoji:''});S.me.emoji_status='';closeDialog();toast('ایموجی وضعیت حذف شد',false);refreshChats();dlgProfile()}catch(err){toast(err.message)}}},'حذف ایموجی وضعیت'))}
function dlgProfile(){
  const me=S.me,name=h('input',{value:me.display_name,maxlength:40}),bio=h('textarea',{rows:2,maxlength:300,style:'resize:none'},me.bio||''),msg=h('div',{class:'msg'});
  const big=h('div',{class:'pbig'});
  const draw=()=>{big.replaceChildren(gav('u',me.id,me.display_name,me.avatar_at,112,false),h('button',{class:'cam',onclick:pick,title:'تغییر عکس'},ic('camera',18)))};
  const[inp,pick]=photoPicker(null,'me',null,async()=>{try{const r=await call('me');Object.assign(S.me,r.me)}catch{}draw();buildDrawer()});
  draw();
  if(me.badge===3)big.classList.add('ownerprof');
  dialog('پروفایل',h('div',{class:'profhead',style:'--pc:'+COLORS[(me.id||0)%COLORS.length]},big,me.badge===3?h('div',{class:'ownerbanner'},'👑 مالک دارک گرام'):null,me.premium?h('div',{},h('span',{class:'premtag'},premStarEl(),' دارک گرام پریمیوم')):null),inp,
    (me.restricted_until*1000>Date.now())?h('div',{class:'msg'},'⏱ حساب شما محدود است و نمی‌تونید پیام بفرستید. برای بررسی به @Spam پیام بدید.'):null,
    h('div',{style:'text-align:center;margin-bottom:6px'},h('button',{class:'link',onclick:pick},'انتخاب عکس جدید'),
      me.avatar_at?h('span',{},'  ·  ',h('button',{class:'link',style:'color:var(--danger)',onclick:async()=>{try{await call('remove_avatar');S.me.avatar_at=0;draw();buildDrawer()}catch(e){toast(e.message)}}},'حذف عکس')):null),
    h('label',{},'نام نمایشی'),name,h('label',{},'درباره من'),bio,
    h('div',{class:'muted',style:'font-size:12px;margin-top:8px'},'نام کاربری: @'+me.username+' (قابل تغییر نیست)'),
    h('button',{class:'btn soft',style:'width:100%;margin-top:10px',onclick:()=>{if(S.me.premium)dlgEmojiStatus();else toast('ایموجی وضعیت فقط برای مشترکین پریمیومه ⭐')}},(S.me.premium?'':'🔒 ')+'ایموجی وضعیت'+(me.emoji_status?'： '+me.emoji_status:'')),
    h('button',{class:'btn',onclick:async()=>{try{const r=await call('update_profile',{display_name:name.value,bio:bio.value});Object.assign(S.me,r.me);buildDrawer();msg.className='msg ok';msg.textContent='ذخیره شد'}catch(e){msg.className='msg';msg.textContent=e.message}}},'ذخیره'),msg,h('hr'),h('b',{style:'display:block;margin-top:8px'},L('🎁 گیفت‌های من','🎁 My Gifts')),giftGridEl(me))}
/* "Install app" (PWA): Chrome offers it only when the page is trusted https (install the certificate first) */
let installEv=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installEv=e});window.addEventListener('appinstalled',()=>{installEv=null;toast('نصب شد 🎉',false)});
async function installApp(){
  if(window.matchMedia('(display-mode: standalone)').matches)return toast('برنامه همین الان نصبه',false);
  if(!installEv)return toast('کروم هنوز اجازه نصب نداده: اول گواهی رو نصب کن، کروم رو کامل ببند و دوباره باز کن؛ یا از منوی کروم (⋮) گزینه Install app / Add to Home screen رو بزن');
  installEv.prompt();try{await installEv.userChoice}catch{}installEv=null}
/* the certificate is fetched through the already-open page connection and saved from memory: nothing for Android's download manager to stall on */
async function dlCert(){
  try{const r=await fetch('/teegram.crt',{cache:'no-store'});if(!r.ok)throw 0;const b=await r.blob();
    const u=URL.createObjectURL(new Blob([b],{type:'application/x-x509-ca-cert'})),x=h('a',{href:u,download:'teegram.crt'});document.body.append(x);x.click();x.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);toast('گواهی ذخیره شد؛ از پوشه Downloads نصبش کن',false)}
  catch{toast('دانلود نشد؛ آدرس http زیر دکمه رو امتحان کن')}}
const REPORT_REASONS=[['spam','اسپم'],['violence','خشونت'],['porn','محتوای غیراخلاقی'],['child_abuse','کودک‌آزاری'],['scam','کلاهبرداری / جعلی'],['personal','اطلاعات شخصی'],['copyright','نقض کپی‌رایت'],['other','سایر موارد']];
function dlgReport(target){
  let reason=null;
  const rows=REPORT_REASONS.map(([k,t])=>{const b=h('button',{class:'srow',style:'width:100%',onclick:()=>{reason=k;rows.forEach(x=>x.classList.remove('on'));b.classList.add('on')}},h('span',{class:'grow'},t));return b});
  const cmt=h('textarea',{rows:2,maxlength:300,placeholder:'توضیح بیشتر (اختیاری)…',style:'resize:none'});
  dialog('🚨 گزارش',h('p',{class:'muted'},'دلیل گزارش رو انتخاب کن؛ گزارش مستقیم برای همهٔ ادمین‌ها و مالکان دارک گرام فرستاده می‌شه.'),
    ...rows,h('label',{},'توضیح'),cmt,
    h('button',{class:'btn danger',onclick:async e=>{if(!reason)return toast('اول دلیل رو انتخاب کن');e.target.disabled=true;try{await call('report',{...target,reason,comment:cmt.value.trim()});closeDialog();toast('🚨 گزارش شما برای مدیریت ارسال شد')}catch(err){toast(err.message);e.target.disabled=false}}},'ارسال گزارش'))}
function dlgAdmin(){
  let filter='all',users=[],stats=null;
  const canLabel=['reza','msmdjdjdj'].includes(((S.me||{}).username||'').toLowerCase());
  const statsBox=h('div',{class:'admstats'},h('div',{class:'hint'},'در حال بارگذاری…'));
  const actBox=h('div'),list=h('div');
  const inp=h('input',{placeholder:'🔍 جستجوی کاربر…',autocomplete:'off',autocapitalize:'none'});
  const chips=h('div',{class:'admchips'},...[['all','همه'],['premium','⭐ پریمیوم'],['admins','👑 ادمین‌ها'],['bots','🤖 ربات‌ها'],['banned','⛔ مسدود']].map(([k,t])=>h('button',{class:'admchip'+(k==='all'?' on':''),onclick:e=>{filter=k;[...chips.children].forEach(x=>x.classList.remove('on'));e.currentTarget.classList.add('on');drawList()}},t)));
  const bcInp=h('textarea',{rows:2,placeholder:'متن اطلاعیه — توی کانال اطلاع‌رسانی برای همه منتشر می‌شه…',style:'resize:none'});
  const bcBtn=h('button',{class:'btn',style:'width:auto;padding:8px 18px',onclick:async()=>{const t=bcInp.value.trim();if(!t)return toast('اول متن اطلاعیه رو بنویس');if(!confirm('این اطلاعیه برای همه کاربرها منتشر بشه؟'))return;try{await call('admin_broadcast',{text:t});bcInp.value='';toast('📣 اطلاعیه منتشر شد',false)}catch(e){toast(e.message)}}},'📣 انتشار اطلاعیه');
  const drawStats=()=>{if(!stats)return;const card=(n,l)=>h('div',{class:'admstat'},h('b',{},fa(n)),h('span',{},l));
    statsBox.replaceChildren(card(stats.users,'کاربر'),card(stats.online,'آنلاین'),card(stats.new24,'جدید ۲۴ ساعت'),card(stats.premium,'⭐ پریمیوم'),
            card(stats.messages,'پیام'),card(stats.groups,'گروه'),card(stats.channels,'کانال'),card(stats.gifts,'🎁 گیفت'),card(stats.nfts,'🖼 NFT'),card(stats.stars_total,'⭐ ستاره در گردش'),card(stats.bots,'ربات'))};
  const drawList=()=>{const F={all:()=>true,premium:u=>u.premium,admins:u=>u.is_admin,bots:u=>u.is_bot,banned:u=>u.banned}[filter];
    const rows=users.filter(F);
    list.replaceChildren(...(rows.length?rows.map(u=>{
      const badgeBtn=(b,label)=>h('button',{class:'admbdg'+(u.badge===b?' on':''),onclick:async()=>{try{await call('admin_set_badge',{user_id:u.id,badge:b});u.badge=b;drawList()}catch(e){toast(e.message)}}},label);
      const meta=['@'+u.username,u.is_bot?'ربات':'',u.banned?'⛔ مسدود':'',(u.restricted_until*1000>Date.now())?'⏱ محدود':'','⭐ '+fa(u.stars||0),'عضویت: '+jdate(u.created_at)].filter(Boolean).join(' • ');
      return h('div',{class:'member admrow'},avatar('u',u.id,u.display_name,0,44,u.online),
        h('div',{class:'grow'},h('b',{},u.display_name+(u.is_admin?' 👑':'')),h('div',{class:'muted',style:'font-size:12px'},meta),
          h('div',{class:'admacts'},
            badgeBtn(0,'بدون نشان'),badgeBtn(1,'🔵 آبی'),badgeBtn(2,'🟡 طلایی'),badgeBtn(3,'👑 مالک'),
            h('button',{class:'admbdg'+(u.premium?' on':''),onclick:async()=>{try{await call('admin_set_premium',{user_id:u.id,premium:!u.premium});u.premium=!u.premium;drawList()}catch(e){toast(e.message)}}},'⭐ پریمیوم'),
            h('button',{class:'admbdg',onclick:async()=>{const v=prompt('موجودی ستاره جدید برای @'+u.username+' (الان: '+(u.stars||0)+')');if(v==null)return;try{const r=await call('admin_set_stars',{user_id:u.id,stars:+v||0});u.stars=r.stars;drawList()}catch(e){toast(e.message)}}},'⭐ ستاره'),
            h('button',{class:'admbdg'+(u.loyal?' on':''),onclick:async()=>{try{await call('admin_set_loyal',{user_id:u.id,loyal:!u.loyal});u.loyal=!u.loyal;drawList()}catch(e){toast(e.message)}}},'💙 وفادار'),
            h('button',{class:'admbdg'+(u.bounty?' on':''),onclick:async()=>{try{await call('admin_set_bounty',{user_id:u.id,bounty:!u.bounty});u.bounty=!u.bounty;drawList()}catch(e){toast(e.message)}}},'🏅 باگ بانتی'),
            canLabel?h('button',{class:'admbdg danger'+(u.scam?' on':''),onclick:async()=>{try{await call('admin_set_scam',{user_id:u.id,scam:!u.scam});u.scam=!u.scam;drawList()}catch(e){toast(e.message)}}},'⚠ کلاهبرداری'):null,
            canLabel?h('button',{class:'admbdg danger'+(u.fake?' on':''),onclick:async()=>{try{await call('admin_set_fake',{user_id:u.id,fake:!u.fake});u.fake=!u.fake;drawList()}catch(e){toast(e.message)}}},'🎭 جعلی'):null,
            u.is_admin?null:h('button',{class:'admbdg',onclick:async()=>{const v=prompt('محدودیت چند دقیقه؟ (0 = برداشتن محدودیت)','5');if(v==null)return;const m=parseInt(v);if(isNaN(m)||m<0)return toast('عدد درست وارد کن');try{await call('admin_restrict',{user_id:u.id,minutes:m});toast(m?('⏱ کاربر '+fa(m)+' دقیقه محدود شد'):'محدودیت برداشته شد');drawList()}catch(e){toast(e.message)}}},'⏱ محدودیت'),
            u.is_bot&&!u.bot_official?h('button',{class:'admbdg danger',onclick:async()=>{if(!confirm('این ربات کامل و برای همیشه از سرور حذف بشه؟'))return;try{await call('admin_delete_bot',{user_id:u.id});drawList()}catch(e){toast(e.message)}}},'🗑 حذف ربات'):null,
            u.is_admin?null:h('button',{class:'admbdg'+(u.banned?' on':''),onclick:async()=>{if(!confirm(u.banned?'این کاربر آزاد بشه؟':'این کاربر مسدود بشه؟ از همه دستگاه‌ها هم خارج می‌شه.'))return;try{await call('admin_set_ban',{user_id:u.id,banned:!u.banned});u.banned=!u.banned;drawList()}catch(e){toast(e.message)}}},u.banned?'آزاد کردن':'مسدود'))))
    }):[h('div',{class:'hint'},'کاربری پیدا نشد')]))};
  const repBox=h('div',{});
  const drawReports=async()=>{try{const r=await call('admin_reports');
    repBox.replaceChildren(h('div',{class:'admsec'},'🚨 گزارش‌ها'),
      ...(r.reports.length?r.reports.map(x=>h('div',{class:'srow'},h('div',{class:'grow'},h('b',{},x.reason_fa+' — '+(x.target_type==='message'?'پیام':x.target_type==='user'?'کاربر':'چت')),h('div',{class:'muted'},'از: '+x.reporter_name+(x.target_name?' • مورد: '+x.target_name:'')+(x.snapshot&&x.target_type==='message'?' • «'+x.snapshot+'»':'')+(x.comment?' • '+x.comment:''))),x.handled?h('span',{class:'muted'},'✓ رسیدگی شد'):h('button',{class:'admbdg',onclick:async()=>{try{await call('admin_report_handle',{id:x.id});drawReports()}catch(e){toast(e.message)}}},'✓ رسیدگی'))):[h('div',{class:'hint'},'گزارشی نیست')]))}catch{}};
  drawReports();
  const drawAct=async()=>{try{const a=await call('admin_activity');
    actBox.replaceChildren(
      h('div',{class:'admsec'},'🕐 آخرین عضویت‌ها'),
      ...(a.new_users||[]).map(u=>h('div',{class:'admline'},h('span',{},u.display_name),h('small',{class:'muted'},'@'+u.username+' • '+jdate(u.created_at)))),
      h('div',{class:'admsec'},'🎁 آخرین گیفت‌ها و NFTها'),
      ...((a.gifts||[]).length?a.gifts.map(g=>h('div',{class:'admline'},h('span',{},g.art+' '+g.name+(g.serial?' #'+fa(g.serial):'')),h('small',{class:'muted'},'@'+g.from+' ← @'+g.to))):[h('div',{class:'hint'},'هنوز گیفتی فرستاده نشده')]));
  }catch{}};
  const load=async q=>{try{const[s,r]=await Promise.all([call('admin_stats'),call('admin_users',{q:q||''})]);stats=s;users=r.users;drawStats();drawList()}catch(e){toast(e.message)}};
  let job;inp.addEventListener('input',()=>{clearTimeout(job);job=setTimeout(()=>load(inp.value),300)});
  dialog('پنل مدیریت 👑',statsBox,h('div',{class:'admsec'},'📣 اطلاعیه همگانی'),bcInp,h('div',{},bcBtn),h('div',{class:'admsec'},'👥 مدیریت کاربرها'),inp,chips,list,repBox,actBox);
  load('');drawAct()}
const SET_EN={'گروه جدید':'New Group','کانال جدید':'New Channel','چت جدید':'New Chat','اتاق تماشا':'Watch Room','ربات‌ها (BotFather)':'Bots (BotFather)','ربات‌ساز':'Bot Maker','استوری جدید':'New Story','پیام‌های ذخیره‌شده':'Saved Messages','گیفت و ستاره‌ها':'Gifts & Stars','پنل مدیریت':'Admin Panel','حریم خصوصی':'Privacy','دستگاه‌های من':'My Devices','خروج':'Log Out'};
function dlgSettings(){
  const sw=(label,on,fn)=>{const s=h('span',{class:'sw2'+(on?' on':'')});return h('div',{class:'tog',onclick:()=>{on=!on;s.classList.toggle('on',on);fn(on)}},h('span',{},label),s)};
  const old=h('input',{type:'password',autocomplete:'current-password'}),nw=h('input',{type:'password',autocomplete:'new-password'}),msg=h('div',{class:'msg'});
  const sws=h('div',{class:'sw'},ACCENTS.map(c=>h('button',{style:'background:'+c,class:PREF.accent===c?'on':'',onclick:e=>{applyAccent(c);[...sws.children].forEach(x=>x.classList.remove('on'));e.currentTarget.classList.add('on')}})));
  const srvWalls=h('div',{class:'walls srv'});
  call('wallpaper_list').then(r=>srvWalls.replaceChildren(...r.walls.map(w=>h('button',{type:'button',class:'wsw wphoto',title:w.name,style:'background-image:url("'+wallUrl(w.name,w.v,true)+'")',onclick:()=>{lsSet('wd-wall','srv:'+w.name+'|'+w.v);applyWall()}})))).catch(()=>{});
  const size=h('input',{type:'range',min:13,max:19,value:PREF.size,style:'padding:0;border:0',oninput:e=>applySize(+e.target.value)});
  const premCard=h('div',{style:'background:linear-gradient(135deg,#7b2ff7,#f107a3);color:#fff;border-radius:14px;padding:12px 14px;margin-bottom:12px;line-height:2'},
    h('b',{style:'font-size:15px'},S.me.premium?'⭐ DarkGram Premium برای تو فعاله':'⭐ DarkGram Premium'),
    h('div',{style:'font-size:12.5px;opacity:.95'},'ستاره ⭐ کنار اسمت در همه‌جا • فایل تا ۴ گیگابایت • پیام تا ۱۰٬۰۰۰ کاراکتر • تا ۳ ری‌اکشن روی هر پیام • بیو تا ۳۰۰ کاراکتر • استوری ویدیویی تا ۶۰ ثانیه • فوروارد هم‌زمان به ۲۰ چت • استیکر و ایموجی‌های پریمیوم و متحرک • ربات رسمی هوش مصنوعی @DarkGramAI'),
    S.me.premium?h('div',{style:'font-size:12.5px'},'✅ اشتراک پریمیوم داری • موجودی ستاره: ⭐ '+fa(S.me.stars||0)):h('button',{class:'btn',style:'background:#fff;color:#7b2ff7;font-weight:800;margin-top:6px;width:auto;padding:8px 18px',onclick:async()=>{try{const r=await call('premium_activate');S.me.premium=true;S.me.stars=r.stars;toast('⭐ پریمیوم فعال شد و '+fa(r.bonus||0)+' ستاره هدیه گرفتی!',false);closeDialog();dlgSettings()}catch(e){toast(e.message)}}},'فعال‌سازی رایگان پریمیوم ⭐'));
  const srow=(icn,t,fn,color)=>h('button',{class:'setrow',onclick:()=>{closeDialog();fn()}},h('span',{class:'sic',style:'background:'+color},ic(icn)),h('span',{class:'slb'},LANG==='en'?(SET_EN[t]||t):t),h('span',{class:'chev'},'\u2039'));
  const profRow=h('button',{class:'setprof',onclick:()=>{closeDialog();dlgProfile()}},avatar('u',S.me.id,S.me.display_name,S.me.avatar_at,54,false),h('span',{class:'spn'},h('b',{},S.me.display_name),h('small',{class:'muted'},at(S.me.username))));
  const secMain=h('div',{class:'setgroup'},srow('group','گروه جدید',()=>dlgNewGroup(),'#a06bff'),srow('channel','کانال جدید',()=>dlgNewGroup(true),'#5aa2e0'),srow('pencil','چت جدید',dlgNewChat,'#4fae4e'),srow('film','اتاق تماشا',()=>typeof openRoomHub==='function'&&openRoomHub(),'#f107a3'),srow('chatb','ربات‌ها (BotFather)',()=>openPrivate('BotFather'),'#e8a317'),srow('chatb','ربات‌ساز',dlgBotForge,'#7c4dff'),srow('story','استوری جدید',()=>window.wdStories&&wdStories.composer(),'#ff7a45'),srow('bookmark','پیام‌های ذخیره‌شده',()=>openPrivate(S.me.username),'#3390ec'),srow('star','گیفت و ستاره‌ها',dlgGifts,'#f5b301'));
  const secAcct=h('div',{class:'setgroup'},...(S.me.is_admin?[srow('settings','پنل مدیریت',dlgAdmin,'#766ac8')]:[]),srow('lock','حریم خصوصی',dlgPrivacy,'#707579'),srow('devices','دستگاه‌های من',dlgSessions,'#5aa2e0'),srow('logout','خروج',()=>logout(),'#e53935'));
  const langRow=h('div',{class:'setgroup'},h('div',{class:'setrow',style:'cursor:default'},h('span',{class:'sic',style:'background:#00acc1'},ic('info')),h('span',{class:'slb'},L('زبان برنامه','App Language')),h('span',{class:'langseg'},h('button',{class:LANG==='fa'?'on':'',onclick:()=>setLang('fa')},'فارسی'),h('button',{class:LANG==='en'?'on':'',onclick:()=>setLang('en')},'English'))));
  dialog(L('تنظیمات','Settings'),
    profRow,premCard,langRow,secMain,secAcct,
    h('label',{class:'switchrow'},L('🌙 حالت تاریک','🌙 Dark Mode'),h('input',{type:'checkbox',checked:document.documentElement.dataset.theme!=='light',onchange:e=>{clearTheme2();setTheme(e.target.checked?'dark':'light')}})),
    h('label',{},L('🎨 تم برنامه','🎨 Theme')),
    h('div',{class:'themecards'},...THEMES.map(t=>{const sv=lsGet('wd-theme2','');const cur=sv?sv===t.id:(t.id==='midnight'&&document.documentElement.dataset.theme!=='light');
      return h('button',{type:'button',class:'themecard'+(cur?' on':''),onclick:e=>{applyTheme2(t.id);[...e.currentTarget.parentNode.children].forEach(x=>x.classList.remove('on'));e.currentTarget.classList.add('on')}},
        h('span',{class:'tp',style:'background:linear-gradient(135deg,'+t.v['--wall1']+','+t.v['--wall2']+')'},h('i',{class:'tb1',style:'background:'+t.v['--panel']}),h('i',{class:'tb2',style:'background:'+t.v['--out']}),h('i',{class:'tb3',style:'background:'+t.accent})),
        h('span',{class:'tn'},LANG==='en'?t.en:t.name))})),
    h('label',{},L('رنگ اصلی','Accent Color')),sws,h('label',{},L('اندازه متن','Text Size')),size,
    h('label',{},L('پس‌زمینه چت','Chat Wallpaper')),srvWalls,h('div',{class:'walls'},WALLS.map(([n,v])=>h('button',{type:'button',class:'wsw',title:n,style:v?'background:'+v:'',onclick:()=>{lsSet('wd-wall',v);applyWall()}},v?'':'A')),
      ...(S.walls||[]).map(v=>{const del=async()=>{if(!confirm('این عکس پس‌زمینه حذف بشه؟'))return;try{const r=await call('userwall_remove',{v});S.walls=r.walls||[];S.wallV=r.wall_v||0;wallSetSave(v,null);if((lsGet('wd-wall','')||'')==='mine:'+v)lsSet('wd-wall','');applyWall();closeDialog();dlgSettings();toast('حذف شد',false)}catch(e){toast(e.message)}};
        const menu=(x,y)=>popMenu(x,y+34,[['استفاده','check',()=>{lsSet('wd-wall','mine:'+v);applyWall()}],['تنظیم اندازه','settings',()=>dlgWallSize(v)],['حذف','delete',del,true]]);
        let lt=null,lp=false;const b=h('button',{type:'button',class:'wsw wphoto',title:'نگه دار: حذف و تنظیم اندازه',style:'background-image:url("'+userWallUrl(v,true)+'")',onclick:e=>{if(lp){lp=false;e.stopPropagation();return}lsSet('wd-wall','mine:'+v);applyWall()}});
        b.addEventListener('contextmenu',e=>{e.preventDefault();lp=true;menu(e.clientX,e.clientY)});
        b.addEventListener('touchstart',e=>{const p=e.touches[0];lp=false;lt=setTimeout(()=>{lt=null;lp=true;menu(p.clientX,p.clientY)},500)},{passive:true});
        const cl=()=>{clearTimeout(lt);lt=null};b.addEventListener('touchend',cl);b.addEventListener('touchmove',cl,{passive:true});b.addEventListener('touchcancel',cl);
        return h('span',{class:'wph'},b,h('button',{type:'button',class:'wx',title:'حذف این عکس',onclick:del},'×'))}),
      h('button',{type:'button',class:'wsw wimg',title:'عکس خودت',onclick:()=>$('#wallfile').click()},ic('attach'))),
    sw(L('صدای پیام جدید','New Message Sound'),PREF.sound,on=>lsSet('wd-sound',on?'1':'0')),
    sw(L('اعلان مرورگر','Browser Notifications'),PREF.notif,on=>{lsSet('wd-notif',on?'1':'0');if(on&&'Notification' in window)Notification.requestPermission().catch(()=>{})}),
    h('button',{class:'btn soft',style:'display:block;margin-top:8px',onclick:()=>{closeDialog();dlgPrivacy()}},'🔒 حریم خصوصی و بلاک'),
    h('button',{class:'btn soft',style:'display:block;margin-top:8px',onclick:dlgPushTest},'🔔 بررسی و آزمایش اعلان'),
    window.WD&&WD.cacheInfo?h('button',{class:'btn soft',style:'display:block;margin-top:8px',onclick:()=>{closeDialog();dlgStorage()}},'💾 مدیریت حافظه'):null,
    window.WD&&WD.changeServer?h('button',{class:'btn soft',style:'display:block;margin-top:8px',onclick:()=>WD.changeServer()},'🌐 آدرس سرور (اپ اندروید)'):null,
    h('hr'),h('b',{},'نصب برنامه روی گوشی'),
    h('div',{class:'muted',style:'font-size:13px;line-height:1.8'},'اگه کنار آدرس هشدار قرمز می‌بینی یا «Install» کار نمی‌کنه، یک بار این گواهی رو نصب کن: دانلود کن → تنظیمات گوشی › امنیت › رمزگذاری و اعتبارنامه › نصب گواهی › گواهی CA. بعد کروم رو کامل ببند و دوباره باز کن؛ بعدش منوی کروم › Install app.'),
    h('button',{class:'btn',style:'display:block;margin-top:8px',onclick:installApp},'📲 نصب برنامه روی گوشی'),
    h('button',{class:'btn soft',style:'display:block;margin-top:8px',onclick:dlCert},'دانلود گواهی'),
    h('div',{class:'muted',style:'font-size:12px;line-height:1.8;margin-top:6px'},'اگه دانلود گیر کرد، این آدرس رو با http (نه https) تو کروم باز کن: ',h('span',{dir:'ltr',style:'user-select:all;word-break:break-all'},'http://'+location.host+'/teegram.crt')),
    h('hr'),h('b',{},'تغییر رمز'),h('label',{},'رمز فعلی'),old,h('label',{},'رمز جدید'),nw,
    h('button',{class:'btn soft',onclick:async()=>{try{await call('change_password',{old_password:old.value,new_password:nw.value});old.value=nw.value='';msg.className='msg ok';msg.textContent='رمز عوض شد'}catch(e){msg.className='msg';msg.textContent=e.message}}},'تغییر رمز'),msg)}
async function dlgSessions(){
  const list=h('div'),draw=async()=>{try{const r=await call('sessions');list.replaceChildren(...r.sessions.map(s=>
    h('div',{class:'member'},ic('devices'),h('div',{class:'grow'},h('b',{},s.device||'دستگاه'+(s.current?' (همین دستگاه)':'')),h('div',{class:'muted',style:'font-size:12px'},'آخرین فعالیت: '+lastSeen(s.last_used))),
      s.current?null:h('button',{class:'iconbtn',title:'خروج این دستگاه',onclick:async()=>{try{await call('terminate_session',{session_id:s.id});draw()}catch(e){toast(e.message)}}},ic('close')))))}catch(e){toast(e.message)}};
  dialog('دستگاه‌های من',list,h('button',{class:'btn danger',onclick:async()=>{if(!confirm('از همه دستگاه‌های دیگه خارج بشی؟'))return;try{await call('terminate_others');draw()}catch(e){toast(e.message)}}},'خروج از همه دستگاه‌های دیگه'));draw()}
function userSearch(onPick,multi){
  const input=h('input',{placeholder:'نام کاربری کامل (مثلاً ali_123)',autocomplete:'off',autocapitalize:'none'}),list=h('div',{class:'ulist'});let job;
  input.addEventListener('input',()=>{clearTimeout(job);const q=input.value.trim().replace(/^@/,'');if(!q){list.replaceChildren();return}
    if(!USER_RE.test(q)){list.replaceChildren(h('div',{class:'hint'},'نام کاربری رو کامل بنویس'));return}
    job=setTimeout(async()=>{try{const r=await call('search_users',{q});if(q!==input.value.trim().replace(/^@/,''))return;if(!r.users.length)return list.replaceChildren(h('div',{class:'hint'},'کاربری با این نام پیدا نشد'));list.replaceChildren(...r.users.map(u=>
      h('div',{class:'srow',onclick:()=>{onPick(u);if(multi){input.value='';list.replaceChildren();input.focus()}}},avatar('u',u.id,u.display_name,u.avatar_at,40,u.online),h('div',{class:'grow'},h('b',{},u.display_name),h('small',{},at(u.username))))))}catch{}},250)});
  return[input,list]}
function dlgNewChat(){const[i,l]=userSearch(u=>{closeDialog();openPrivate(u.username)});dialog('چت جدید',i,l);i.focus()}
function dlgNewGroup(isChan){
  const title=h('input',{placeholder:isChan?'اسم کانال':'اسم گروه',maxlength:40}),chosen=new Map(),chips=h('div',{class:'chips'}),err=h('div',{class:'msg'});
  const draw=()=>chips.replaceChildren(...[...chosen.values()].map(u=>h('span',{class:'chip',title:'حذف',onclick:()=>{chosen.delete(u.username);draw()}},u.display_name+' ✕')));
  const[i,l]=userSearch(u=>{chosen.set(u.username,u);draw()},true);
  i.placeholder=isChan?'افزودن مشترک (اختیاری؛ نام کاربری کامل)':i.placeholder;
  dialog(isChan?'کانال جدید':'گروه جدید',title,isChan?h('div',{class:'muted',style:'font-size:12.5px;margin:8px 2px;line-height:1.7'},'تو کانال فقط تو و ادمین‌ها پیام می‌ذارید و بقیه مشترک هستن. بعد از ساخت، لینک دعوت کانال تو اطلاعاتش هست.'):h('div',{style:'height:8px'}),i,chips,l,err,h('button',{class:'btn',onclick:async()=>{
    if(!title.value.trim())return err.textContent=isChan?'اسم کانال رو بنویس':'اسم گروه رو بنویس';
    try{const r=await call('create_group',{title:title.value,usernames:[...chosen.keys()],channel:!!isChan});S.chats[r.chat.id]=r.chat;closeDialog();openChat(r.chat.id)}catch(e){err.textContent=e.message}}},isChan?'ساخت کانال':'ساخت گروه'));title.focus()}

/* ---------- chat info (user / group) + shared media ---------- */
/* ---------- Telegram Stars & gifts (Premium only) ---------- */
const GIFT_ART={rose:'🌹',bear:'🧸',heart:'💝',cake:'🎂',rocket:'🚀',champ:'🍾',ring:'💍',trophy:'🏆',gem:'💎',crown:'👑',
  nft_bear:'🧸',nft_rocket:'🚀',nft_ring:'💍',nft_crown:'👑',nft_phoenix:'🦚',nft_gem:'💎',nft_unicorn:'🦄',nft_genesis:'🔮',nft_eternal:'🐉'};
const GIFT_NAME={rose:'رز قرمز',bear:'خرس عروسکی',heart:'قلب هدیه',cake:'کیک تولد',rocket:'موشک',champ:'شامپاین',ring:'انگشتر الماس',trophy:'جام قهرمانی',gem:'الماس',crown:'تاج طلایی',
  nft_bear:'خرس کلکسیونی',nft_rocket:'موشک طلایی',nft_ring:'حلقه کهکشانی',nft_crown:'تاج سلطنتی',nft_phoenix:'طاووس سلطنتی',nft_gem:'الماس ابدی',nft_unicorn:'تک‌شاخ افسانه‌ای',nft_genesis:'گوی جنسیس',nft_eternal:'اژدهای جاودان'};
const PREM_SVG_APP='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="url(#premGrad)" stroke="url(#premGrad)" stroke-width="1.5" stroke-linejoin="round" d="M12 2.6l2.95 6.18 6.8.86-4.98 4.7 1.28 6.72L12 17.77l-6.05 3.29 1.28-6.72-4.98-4.7 6.8-.86z"/></svg>';
const premStarEl=()=>{const s=h('span',{class:'premstar',title:'دارک گرام پریمیوم'});s.innerHTML=PREM_SVG_APP;return s};
function giftGridEl(p){const own=S.me&&S.me.id===p.id;let cols=[],cur=0,gd=null;
  const box=h('div',{},h('div',{class:'hint'},L('در حال بارگذاری…','Loading…')));
  const lat=n=>String(n);
  function cellMenu(x,y,key){const items=[];
    if(cur)items.push([L('جلوتر','Move forward'),'up',()=>api('gift_col_item_move',{col_id:cur,gkey:key,dir:-1})],
      [L('عقب‌تر','Move back'),'down',()=>api('gift_col_item_move',{col_id:cur,gkey:key,dir:1})],
      [L('حذف از این پوشه','Remove from folder'),'delete',()=>api('gift_col_remove',{col_id:cur,gkey:key}),true]);
    cols.forEach(c=>{const has=c.items.includes(key);
      items.push([(has?'✓ ':'')+c.name,'bookmark',()=>api(has?'gift_col_remove':'gift_col_add',{col_id:c.id,gkey:key})])});
    items.push([L('پوشه جدید…','New folder…'),'add',()=>newCol(key)]);
    popMenu(x,y,items)}
  function colMenu(x,y,c){popMenu(x,y,[
    [L('تغییر نام','Rename'),'pencil',()=>{const n=prompt(L('اسم جدید پوشه:','New folder name:'),c.name);if(n&&n.trim())api('gift_col_rename',{col_id:c.id,name:n.trim()})}],
    [L('جلوتر','Move forward'),'up',()=>api('gift_col_move',{col_id:c.id,dir:-1})],
    [L('عقب‌تر','Move back'),'down',()=>api('gift_col_move',{col_id:c.id,dir:1})],
    [L('حذف پوشه','Delete folder'),'delete',()=>{if(confirm(L('این پوشه حذف بشه؟ (گیفت‌ها سر جاشون می‌مونن)','Delete this folder? (the gifts stay)')))api('gift_col_delete',{col_id:c.id})},true]])}
  function newCol(key){const n=prompt(L('اسم پوشه جدید:','New folder name:'));if(!n||!n.trim())return;
    call('gift_col_create',{name:n.trim()}).then(r=>{cols.push(r.col);cur=r.col.id;
      if(key)return call('gift_col_add',{col_id:r.col.id,gkey:key}).then(()=>refresh());refresh()}).catch(e=>toast(e.message))}
  function api(op,args){call(op,args).then(()=>refresh()).catch(e=>toast(e.message))}
  function refresh(){Promise.all([call('gifts_of',{user_id:p.id}),call('gift_cols',{user_id:p.id})]).then(([g,c])=>{gd=g;cols=c.cols||[];if(cur&&!cols.find(x=>x.id===cur))cur=0;render()}).catch(()=>{})}
  function bindCell(cell,key){if(!own)return;
    cell.addEventListener('contextmenu',e=>{e.preventDefault();cellMenu(e.clientX,e.clientY,key)});
    let lt=null;cell.addEventListener('touchstart',e=>{lt=setTimeout(()=>{const t=e.touches[0];cellMenu(t.clientX,t.clientY,key)},520)},{passive:true});
    const cl=()=>clearTimeout(lt);cell.addEventListener('touchend',cl);cell.addEventListener('touchmove',cl,{passive:true});cell.addEventListener('touchcancel',cl)}
  function render(){if(!gd)return;
    const nfts=gd.nfts||[],regs=[...(gd.gifts||[])].sort((a,b)=>b.count-a.count),cellOf=new Map();
    nfts.forEach(x=>{const key='nft:'+x.gift+':'+x.serial;
      const cell=h('div',{class:'pgift nft'+(x.gift==='nft_eternal'?' uni1':'')},h('span',{class:'pgart aemo a-'+emoAnim(GIFT_ART[x.gift]||'🎁')},GIFT_ART[x.gift]||'🎁'),h('b',{},GIFT_NAME[x.gift]||x.gift),h('small',{class:'nftser'},'NFT #'+lat(x.serial)));if(x.gift==='nft_eternal'&&x.backdrop)cell.style.background=bdOf(x.backdrop).g;addTilt(cell,9);bindCell(cell,key);cell.addEventListener('click',()=>{const et=x.gift==='nft_eternal';if(et){dragonRoarReal();cell.classList.remove('roaring');void cell.offsetWidth;cell.classList.add('roaring')}if(!own||x.serial!=null)setTimeout(()=>nftInfoDialog(x,p.username),et?380:0)});cellOf.set(key,cell)});
    regs.forEach(x=>{const key='gift:'+x.gift;
      const cell=h('div',{class:'pgift'},h('span',{class:'pgart aemo a-'+emoAnim(GIFT_ART[x.gift]||'🎁')},GIFT_ART[x.gift]||'🎁'),h('b',{},GIFT_NAME[x.gift]||x.gift),x.count>1?h('span',{class:'gcount'},'×'+lat(x.count)):null);bindCell(cell,key);cellOf.set(key,cell)});
    let cells;if(cur){const col=cols.find(c=>c.id===cur);cells=col?col.items.map(k=>cellOf.get(k)).filter(Boolean):[]}else cells=[...cellOf.values()];
    const total=nfts.length+regs.reduce((a,x)=>a+x.count,0);
    const chips=h('div',{class:'gchips'},h('button',{class:'gchip'+(cur===0?' on':''),onclick:()=>{cur=0;render()}},L('همه','All')),
      ...cols.map(c=>{const b=h('button',{class:'gchip'+(cur===c.id?' on':''),onclick:()=>{cur=c.id;render()}},c.name);
        if(own){b.addEventListener('contextmenu',e=>{e.preventDefault();colMenu(e.clientX,e.clientY,c)});
          let lt=null;b.addEventListener('touchstart',e=>{lt=setTimeout(()=>{const t=e.touches[0];colMenu(t.clientX,t.clientY,c)},520)},{passive:true});
          const cl=()=>clearTimeout(lt);b.addEventListener('touchend',cl);b.addEventListener('touchmove',cl,{passive:true})}
        return b}),
      own?h('button',{class:'gchip add',onclick:()=>newCol()},L('+ پوشه جدید','+ New folder')):null);
    box.replaceChildren(
      h('div',{class:'pghead'},'🎁 ',h('bdi',{},lat(total)),' ',L('گیفت','gifts')+(nfts.length?' • NFT '+lat(nfts.length):'')),
      (cols.length||own)?chips:h('span',{hidden:''}),
      cells.length?h('div',{class:'pgifts'},...cells):h('div',{class:'hint'},cur?L('این پوشه خالیه — روی یه گیفت نگه دار و به این پوشه اضافه‌ش کن','This folder is empty — long-press a gift to add it here'):L('هنوز گیفتی نداره 🎁','No gifts yet 🎁')))}
  call('gifts_of',{user_id:p.id}).then(g=>{gd=g;return call('gift_cols',{user_id:p.id})}).then(c=>{cols=c.cols||[];render()}).catch(()=>box.replaceChildren(h('div',{class:'hint'},L('خطا در بارگذاری گیفت‌ها','Could not load gifts'))));
  return box}
const NFT_INFO={nft_eternal:{model:'Legendary',pct:'0.1%',backdrop:'Midnight Gold',backdropFa:'طلایی نیمه‌شب',sw:'linear-gradient(135deg,#3a2b00,#f5b301)',supply:1}};
const NFT_BD={midnight_gold:{fa:'طلایی نیمه‌شب',en:'Midnight Gold',pct:'30%',g:'linear-gradient(135deg,#3a2b00,#f5b301)'},inferno:{fa:'دوزخ آتشین',en:'Inferno',pct:'20%',g:'linear-gradient(135deg,#2b0600,#ff5a00)'},royal_violet:{fa:'بنفش سلطنتی',en:'Royal Violet',pct:'15%',g:'linear-gradient(135deg,#170b2e,#8a5cff)'},frost:{fa:'یخ ابدی',en:'Eternal Frost',pct:'12%',g:'linear-gradient(135deg,#06222e,#59c2ff)'},emerald:{fa:'زمرد عمیق',en:'Deep Emerald',pct:'10%',g:'linear-gradient(135deg,#02231a,#19c37d)'},crimson:{fa:'خون اژدها',en:'Dragon Blood',pct:'7%',g:'linear-gradient(135deg,#2b0000,#e02020)'},cosmic:{fa:'کیهان',en:'Cosmic Abyss',pct:'4%',g:'linear-gradient(135deg,#050510,#4a3aff)'},void:{fa:'خلأ ابدی',en:'Void Black',pct:'2%',g:'linear-gradient(135deg,#000,#3d3d3d)'}};
const bdOf=id=>NFT_BD[id]||NFT_BD.midnight_gold;
function nftInfoDialog(x,ownerName){
  const art=GIFT_ART[x.gift]||'🎁',name=GIFT_NAME[x.gift]||x.gift,info=NFT_INFO[x.gift],eternal=x.gift==='nft_eternal';
  const stage=h('div',{class:'nftstage'+(eternal?' uni1stage':'')},h('span',{class:'nfring'}),h('span',{class:eternal?'nftbig nft3d':'nftbig aemo a-'+emoAnim(art)},art));
  if(eternal){stage.style.background=bdOf(x.backdrop).g;stage.querySelector('.nftbig').replaceWith(h('img',{class:'dragonposter',src:'/static/dragon.jpg',alt:'🐉'}));stage.append(h('span',{class:'dplay'},'▶ نمایش زندهٔ اژدها'));stage.addEventListener('click',()=>dragonShow(x.backdrop))}
  const row=(l,v)=>h('div',{class:'pfrow'},h('div',{class:'pl'},l),h('div',{class:'pv'},h('bdi',{},v)));
  dialog('🖼 اطلاعات گیفت NFT',stage,
    h('div',{style:'text-align:center'},h('b',{style:'font-size:17px'},name),h('div',{},h('span',{class:'nftrare',style:'background:'+(eternal?'#ff5ea8':'#a06bff')},eternal?'افسانه‌ای | Legendary':'NFT'))),
    h('div',{class:'profinfo'},
      row('مدل | Model',info?info.model+' · '+info.pct:'—'),
      row('پس‌زمینه | Backdrop',eternal?h('span',{},h('span',{class:'bdot',style:'background:'+bdOf(x.backdrop).g}),bdOf(x.backdrop).fa+' · '+bdOf(x.backdrop).en+' · '+bdOf(x.backdrop).pct):(info?h('span',{},h('span',{class:'bdot',style:'background:'+info.sw}),info.backdropFa+' · '+info.backdrop+' · '+info.pct):'—')),
      row('نایابی | Rarity',info?info.pct:'—'),
      row('عرضه | Supply',info?'1 of 1':'—'),
      row('شماره سریال | Serial','#'+String(x.serial)),
      ownerName?row('مالک | Owner','@'+ownerName):null,
      row('لینک گیفت | Gift link',h('span',{style:'cursor:pointer;color:var(--accent)',title:'کپی لینک',onclick:async()=>{const u=location.origin+'/#gift='+x.gift+'-'+x.serial;try{await navigator.clipboard.writeText(u)}catch(_){}toast('لینک گیفت کپی شد',false)}},'#gift='+x.gift+'-'+x.serial))),
    eternal?h('div',{class:'muted',style:'text-align:center;font-size:12px'},'برای دیدن نمایش زندهٔ اژدها روی تصویرش بزن 🐉'):null,
    (eternal&&ownerName&&S.me&&ownerName.toLowerCase()===S.me.username.toLowerCase())?h('button',{class:'btn',style:'margin-top:10px',onclick:async ev=>{const b=ev.currentTarget;b.disabled=true;try{const r=await call('gift_upgrade',{gift:x.gift,serial:x.serial});x.backdrop=r.backdrop;dragonRoarReal();toast('⬆️ ارتقا انجام شد! پس‌زمینهٔ جدید: '+bdOf(r.backdrop).fa+' 🎉',false);closeDialog();nftInfoDialog(x,ownerName)}catch(e){toast(e.message);b.disabled=false}}},'⬆️ ارتقای گیفت — پس‌زمینهٔ تصادفی (رایگان)'):null)}
function giftEl(m){const g=m.gift||{};
  if(g.nft)return h('div',{class:'giftcard nft'+(g.supply===1?' uni1':''),style:'cursor:pointer',title:'دیدن اطلاعات گیفت',onclick:e=>{e.stopPropagation();nftInfoDialog({gift:g.id,serial:g.serial},null)}},h('span',{class:'gsp s1'},'✦'),h('span',{class:'gsp s2'},'✦'),h('span',{class:'gsp s3'},'⭐'),h('span',{class:'giftnfttag'},'🖼 NFT #'+fa(g.serial)+' از '+fa(g.supply)),h('span',{class:g.supply===1?'giftbig nft3d':'giftbig aemo a-'+emoAnim(g.art||'🎁')},g.art||'🎁'),h('b',{},g.name||'گیفت NFT'),h('div',{class:'muted',style:'font-size:12px'},'💵 $'+g.usd+' • ⭐ '+fa(g.price||0)));
  return h('div',{class:'giftcard'},h('span',{class:'giftbig aemo a-'+emoAnim(g.art||'🎁')},g.art||'🎁'),h('b',{},g.name||'گیفت'),h('div',{class:'muted',style:'font-size:12px'},'🎁 گیفت • ⭐ '+fa(g.price||0)))}
function giftBox(p){return giftGridEl(p)}
function giftSendFlow(g,isNft){
  const inp=h('input',{placeholder:'نام کاربری گیرنده، مثلاً Reza_id_tell',dir:'ltr',autocapitalize:'none'}),err=h('div',{class:'msg'});
  const priceLine=isNft?h('div',{class:'muted'},'💵 $'+g.usd+' • ⭐ '+fa(g.price_stars)+' ستاره • عرضه محدود: '+fa(g.supply)+' عدد'):h('div',{class:'muted'},'⭐ '+fa(g.price)+' ستاره');
  dialog(isNft?'خرید گیفت NFT':'ارسال گیفت',h('div',{style:'text-align:center;font-size:56px;line-height:1.2'},g.art),h('div',{style:'text-align:center'},h('b',{},g.name),priceLine),
    h('label',{},'گیرنده'),inp,err,
    h('button',{class:'btn',onclick:async()=>{const u=inp.value.trim().replace(/^@/,'');if(!u)return err.textContent='نام کاربری گیرنده رو بنویس';try{const r=await call(isNft?'nft_buy':'gift_send',{gift:g.id,username:u});S.me.stars=r.stars;closeDialog();toast('🎁 '+(isNft?'گیفت NFT خریده':'گیفت فرستاده')+' شد — موجودی: ⭐ '+fa(r.stars),false)}catch(e){err.textContent=e.message}}},isNft?'🖼 خرید NFT':'🎁 ارسال گیفت'))}
function nftRarity(g){return g.supply<=3?['افسانه‌ای','#ff5ea8']:g.supply<=10?['فوق‌العاده نادر','#a06bff']:g.supply<=25?['نادر','#4dc9ff']:g.supply<=50?['کمیاب','#2ee6a8']:['ویژه','#e8a13a']}
function addTilt(el,max){if(!el||matchMedia('(prefers-reduced-motion: reduce)').matches)return;max=max||10;
  el.addEventListener('pointermove',e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
    el.style.transform='perspective(600px) rotateX('+(-y*max).toFixed(1)+'deg) rotateY('+(x*max).toFixed(1)+'deg) scale(1.03)'});
  el.addEventListener('pointerleave',()=>{el.style.transform=''})}
function burst(host,n){if(!host)return;const CH=['✦','⭐','✨','💫','🌟'];
  for(let i=0;i<(n||14);i++){const s=h('span',{class:'spark'},CH[i%CH.length]),a=Math.random()*Math.PI*2,d=54+Math.random()*76;
    s.style.setProperty('--dx',Math.cos(a)*d+'px');s.style.setProperty('--dy',(Math.sin(a)*d-26)+'px');
    s.style.left='50%';s.style.top='40%';s.style.animationDelay=(Math.random()*.12)+'s';host.append(s);setTimeout(()=>s.remove(),1150)}}
function nftDetail(g,peerName){
  const[rar,rc]=nftRarity(g),left=g.supply-(g.minted||0),sold=left<=0,pct=g.supply?Math.round((g.minted||0)/g.supply*100):0;
  const stage=h('div',{class:'nftstage'+(g.id==='nft_eternal'?' uni1stage':'')},h('span',{class:'nfring'}),h('span',{class:g.id==='nft_eternal'?'nftbig nft3d':'nftbig aemo a-'+emoAnim(g.art)},g.art));
  const inp=h('input',{placeholder:'نام کاربری گیرنده، مثلاً Reza_id_tell',dir:'ltr',autocapitalize:'none'}),err=h('div',{class:'msg'});
  const buyBtn=h('button',{class:'btn nftbuy',onclick:async()=>{
    const u=peerName?peerName.replace(/^@/,''):inp.value.trim().replace(/^@/,'');
    if(!u)return err.textContent='نام کاربری گیرنده رو بنویس';
    buyBtn.disabled=true;buyBtn.textContent='در حال خرید…';
    try{const r=await call('nft_buy',{gift:g.id,username:u});S.me.stars=r.stars;
      stage.classList.add('won');burst(stage,18);
      err.className='msg ok';err.textContent='🎉 تبریک! NFT شماره '+fa(r.serial)+' برای @'+u+' ثبت شد';
      buyBtn.textContent='✅ خرید انجام شد — سریال #'+fa(r.serial);
      if(peerName){ingest(r.message);$('#msgs').scrollTop=$('#msgs').scrollHeight;setTimeout(closeDialog,1000)}
    }catch(e){err.textContent=e.message;buyBtn.disabled=false;buyBtn.textContent='🖼 خرید NFT — $'+g.usd}}},sold?'🏁 فروخته شده':'🖼 خرید NFT — $'+g.usd);
  if(sold)buyBtn.disabled=true;
  dialog('🖼 گیفت NFT',stage,
    h('div',{style:'text-align:center'},h('b',{style:'font-size:17px'},g.name),h('div',{},h('span',{class:'nftrare',style:'background:'+rc},rar))),
    h('div',{class:'nftprices'},h('span',{},'💵 $'+g.usd),h('span',{},'⭐ '+fa(g.price_stars)+' ستاره'),h('span',{},S.unlimited?'♾️ موجودی تو: نامحدود':'موجودی: ⭐ '+fa(S.me.stars||0))),
    h('div',{class:'nftbarwrap'},h('div',{class:'nftbar'},h('i',{style:'width:'+pct+'%'}))),
    h('div',{class:'muted',style:'font-size:12px;text-align:center'},'ضرب شده: '+fa(g.minted||0)+' از '+fa(g.supply)+' • باقی‌مانده: '+fa(Math.max(left,0))),
    peerName?h('div',{class:'muted',style:'text-align:center;margin-top:6px'},'گیرنده: '+peerName):h('label',{},'گیرنده'),peerName?null:inp,err,buyBtn);
  addTilt(stage,7);if(g.id==='nft_eternal'){const st=stage;st.querySelector('.nftbig').replaceWith(h('img',{class:'dragonposter',src:'/static/dragon.jpg',alt:'🐉'}));st.append(h('span',{class:'dplay'},'▶ نمایش زندهٔ اژدها'));st.addEventListener('click',()=>dragonShow())}setTimeout(()=>burst(stage,8),300)}
async function dlgGifts(){
  if(!S.me.premium){
    dialog('🎁 گیفت و تلگرام استارز',h('div',{style:'text-align:center;line-height:2.1'},h('div',{style:'font-size:46px'},'🔒'),
      h('div',{},'بخش گیفت و ستاره‌ها فقط برای مشترکین پریمیومه ⭐'),
      h('button',{class:'btn',style:'width:auto;padding:9px 22px',onclick:async()=>{try{const r=await call('premium_activate');S.me.premium=true;S.me.stars=r.stars;toast('⭐ پریمیوم فعال شد و '+fa(r.bonus||0)+' ستاره هدیه گرفتی!',false);closeDialog();dlgGifts()}catch(e){toast(e.message)}}},'فعال‌سازی پریمیوم ⭐')));return}
  const box=h('div',{},h('div',{class:'hint'},'در حال بارگذاری…'));dialog('🎁 گیفت و تلگرام استارز',box);
  const draw=async()=>{try{const r=await call('stars_me');S.me.stars=r.stars;S.unlimited=r.unlimited;
    const claimBtn=h('button',{class:'btn soft',style:(r.can_claim?'':'opacity:.55')+';margin-bottom:12px',onclick:async()=>{if(!r.can_claim)return toast('ستاره امروز رو گرفتی؛ فردا دوباره بیا ⭐');try{await call('stars_claim');toast('۲۵ ⭐ به موجودیت اضافه شد!',false);draw()}catch(e){toast(e.message)}}},r.can_claim?'🎁 گرفتن ۲۵ ستاره روزانه':'ستاره روزانه گرفته شد ✓');
    box.replaceChildren(
      h('div',{class:'starbal'},r.unlimited?'♾️ موجودی تو: نامحدود':'⭐ موجودی تو: '+fa(r.stars)+' ستاره'),
      claimBtn,
      h('b',{},'فروشگاه گیفت'),h('div',{class:'muted',style:'font-size:12px;margin-bottom:4px'},'برای ارسال، روی گیفت بزن و آیدی گیرنده رو بنویس'),
      h('div',{class:'giftgrid'},...r.catalog.map(g=>h('button',{class:'giftcell',onclick:()=>giftSendFlow(g)},h('span',{class:'giftart aemo a-'+emoAnim(g.art)},g.art),h('b',{},g.name),h('small',{},'⭐ '+fa(g.price))))),
      h('b',{},'🖼 گیفت‌های NFT — کلکسیونی و محدود'),h('div',{class:'muted',style:'font-size:12px;margin-bottom:4px'},'هر NFT شماره سریال یکتا داره و وقتی عرضه‌ش تموم شه دیگه تولید نمی‌شه. قیمت‌ها به دلاره و با ستاره پرداخت می‌شن (هر ۱ دلار = ۵۰ ستاره)'),
      h('div',{class:'giftgrid'},...(r.nft_catalog||[]).map(g=>{const left=g.supply-g.minted,sold=left<=0;
        const btn=h('button',{class:'giftcell nftcell'+(g.id==='nft_eternal'?' uni1':''),style:sold?'opacity:.5':'',onclick:()=>{if(sold)return toast('این NFT کاملاً فروخته شده 🏁');nftDetail(g)}},
          h('span',{class:'giftart aemo a-'+emoAnim(g.art)},g.art),h('b',{},g.name),h('small',{style:'color:#e8a13a'},'💵 $'+g.usd),h('small',{},'⭐ '+fa(g.price_stars)),h('small',{class:'muted'},sold?'فروخته شد 🏁':'مونده: '+fa(left)+' از '+fa(g.supply)));
        if(!sold)addTilt(btn,9);return btn})),
      h('b',{},'گیفت‌های من'),
      r.gifts.length?h('div',{class:'giftrow'},...r.gifts.map(x=>{const g=r.catalog.find(c=>c.id===x.gift)||{};return h('span',{class:'giftchip',title:'از طرف '+(x.from_name||'')},(g.art||'🎁')+' '+(g.name||x.gift))})):h('div',{class:'hint'},'هنوز گیفتی نگرفتی؛ شاید یکی به‌زودی برات بفرسته 🎁'));
  }catch(e){box.replaceChildren(h('div',{class:'hint'},e.message))}};
  draw()}
async function openMention(un){
  un=(un||'').replace(/^@/,'');if(!un)return;
  for(const c of Object.values(S.chats))if(c.peer&&c.peer.username&&c.peer.username.toLowerCase()===un.toLowerCase())return dlgUser(c.peer);
  for(const c of Object.values(S.chats))if(c.kind==='group'&&c.username&&c.username.toLowerCase()===un.toLowerCase())return openChat(c.id);
  try{const r=await call('search_users',{q:un});const u=(r.users||[]).find(x=>x.username&&x.username.toLowerCase()===un.toLowerCase());
    if(u)return dlgUser(u);
    const g=(r.groups||[]).find(x=>x.username&&x.username.toLowerCase()===un.toLowerCase());
    if(g)return joinDialog({...g,member:false},{username:un});
    toast('چیزی با آیدی @'+un+' پیدا نشد')}catch(e){toast(e.message)}}
function showUser(uid,name){
  for(const c of Object.values(S.chats))if(c.peer&&c.peer.id===uid)return dlgUser(c.peer);
  dialog(name||'کاربر',h('div',{class:'muted'},'برای دیدن مشخصات یا پیام دادن، نام کاربری رو جستجو کن.'))}
/* ---------- profile (latest Telegram layout) ---------- */
function profHead(p){
  const col=COLORS[(p.id||0)%COLORS.length];
  return h('div',{class:'profhead',style:'--pc:'+col},
    h('div',{class:'pbig'+(p.badge===3?' ownerprof':'')},gav('u',p.id,p.display_name,p.avatar_at,104,p.online)),
    h('div',{class:'profname'},p.display_name),
    p.badge===3?h('div',{class:'ownerbanner'},'👑 مالک دارک گرام'):null,
    p.premium?h('div',{},h('span',{class:'premtag'},premStarEl(),' دارک گرام پریمیوم')):null,
    h('div',{class:'profsub'},at(p.username)),
    h('div',{class:'profsub2'},p.bot?'ربات':seenText(p)),profShowcase(p))}
function profShowcase(p){
  const box=h('div',{class:'profshow'});
  call('gifts_of',{user_id:p.id}).then(g=>{
    const items=[];
    (g.nfts||[]).forEach(x=>items.push({art:GIFT_ART[x.gift]||'🎁',nft:true,et:x.gift==='nft_eternal',bd:x.backdrop,x}));
    [...(g.gifts||[])].sort((a,b)=>b.count-a.count).forEach(x=>items.push({art:GIFT_ART[x.gift]||'🎁',count:x.count,x}));
    if(!items.length)return;
    box.replaceChildren(...items.slice(0,6).map(it=>{const t=h('div',{class:'pshowtile'+(it.nft?' nft':'')+(it.et?' uni1':''),title:GIFT_NAME[it.x.gift]||'',onclick:()=>{if(it.nft)nftInfoDialog(it.x,p.username)}},h('span',{class:'aemo a-'+emoAnim(it.art)},it.art),it.count>1?h('small',{},'×'+it.count):null);if(it.et&&it.bd)t.style.background=bdOf(it.bd).g;return t}));
  }).catch(()=>{});
  return box}
function profInfo(p){
  const rows=[];
  const row=(l,v,fn,icn)=>h('div',{class:'pfrow',onclick:fn||null},h('span',{class:'pfric'},icn==='@'?h('b',{style:'font-size:17px'},'@'):ic(icn||'info',19)),h('div',{class:'pfmain'},h('div',{class:'pl'},l),h('div',{class:'pv',dir:'auto'},v)));
  if(p.bot&&p.bot.description)rows.push(row('درباره ربات',p.bot.description,null,'chatb'));
  if(p.bio)rows.push(row('بیو',p.bio,null,'info'));
  rows.push(row('نام کاربری','@'+p.username,()=>copyText('@'+p.username),'@'));
  return rows.length?h('div',{class:'profinfo'},...rows):null}
function profActions(p,chat,withMute=true){
  const act=(icon,label,fn)=>{const b=h('button',{class:'pact',onclick:fn},h('span',{class:'pacti'},ic(icon,21)),h('small',{},label));return b};
  const acts=[act('chatb','پیام',()=>{closeDialog();openPrivate(p.username)})];
  if(!p.bot&&p.id!==S.me.id){
    acts.push(act('phone','تماس',async()=>{closeDialog();await openPrivate(p.username);startCall(false)}));
    acts.push(act('video','ویدیو',async()=>{closeDialog();await openPrivate(p.username);startCall(true)}))}
  if(chat&&withMute){const ml=h('small',{},chat.muted?'باصدا':'بی‌صدا');
    acts.push(h('button',{class:'pact',onclick:async e=>{await setChat(chat.id,{muted:!chat.muted});ml.textContent=chat.muted?'باصدا':'بی‌صدا'}},h('span',{class:'pacti'},ic('bell',21)),ml))}
  return h('div',{class:'pacts'},...acts)}
function dlgUser(p){
  const chat=Object.values(S.chats).find(c=>c.kind==='private'&&c.peer&&c.peer.id===p.id);
  let storyRow=null;
  try{const sg=(typeof ST!=='undefined'&&ST.groups||[]).find(g=>g.user.id===p.id&&g.stories&&g.stories.length);
    if(sg)storyRow=h('button',{class:'btn soft',style:'margin:0 0 10px',onclick:()=>{closeDialog();window.wdStories&&wdStories.open(sg.stories[0].id)}},'📸 دیدن استوری فعال')}catch{}
  const about=h('div',{},storyRow,profInfo(p),p.id!==S.me.id?blockRow(p):null,p.id!==S.me.id?h('button',{class:'btn soft',style:'display:block;margin-top:8px',onclick:()=>dlgReport({user_id:p.id})},'🚨 گزارش این کاربر'):null);
  const gifts=giftGridEl(p);gifts.hidden=true;
  const panes=[['درباره',about],['🎁 گیفت‌ها',gifts]];let shared=null,sharedBuilt=false;
  if(chat){shared=h('div',{});shared.hidden=true;panes.push(['رسانه و فایل‌ها',shared])}
  const tabs=h('div',{class:'seg'},...panes.map(([t],i)=>h('button',{class:i===0?'on':'',onclick:()=>{panes.forEach(([,el],j)=>el.hidden=j!==i);[...tabs.children].forEach((x,j)=>x.classList.toggle('on',j===i));
    if(panes[i][0]==='رسانه و فایل‌ها'&&!sharedBuilt){sharedBuilt=true;shared.replaceChildren(...sharedSection(chat))}}},t)));
  dialog('',profHead(p),profActions(p,chat),tabs,...panes.map(x=>x[1]))}
async function sharedTab(box,chatId,kind){
  box.replaceChildren(h('div',{class:'hint'},'در حال بارگذاری…'));
  try{const r=await call('shared',{chat_id:chatId,kind});
    if(!r.messages.length)return box.replaceChildren(h('div',{class:'hint'},'چیزی نیست'));
    const jump=m=>{closeDialog();openChat(chatId,m.id)};
    if(kind==='media')box.replaceChildren(h('div',{class:'grid3'},r.messages.map(m=>{
      const v=m.file.kind==='video',cell=h('div',{class:'vthumb'+(v?' isv':'')},m.file.thumb?h('img',{src:thumbUrl(m),loading:'lazy',alt:''}):(!v?h('img',{src:mediaUrl(m),loading:'lazy',alt:''}):h('span',{class:'ph'},ic('video',26))));
      cell.onclick=()=>v?jump(m):lightbox(mediaUrl(m));return cell})));
    else box.replaceChildren(...r.messages.map(m=>{
      if(kind==='link'){const u=(m.body.match(/https?:\/\/[^\s<>"']+/)||[''])[0];const jr=parseJoinRef(u);return h('div',{class:'srow',onclick:()=>jump(m)},ic('file'),h('div',{class:'grow'},h('a',{href:u,target:jr?null:'_blank',rel:'noopener noreferrer',onclick:e=>{e.stopPropagation();if(jr){e.preventDefault();lsSet('wd-join',jr);closeDialog();handleJoin()}}},short(u,50)),h('small',{},short(m.body,60))))}
      return h('div',{class:'srow',onclick:()=>jump(m)},ic(m.file.voice?'mic':'file'),h('div',{class:'grow'},h('b',{},m.file.voice?'پیام صوتی '+fmtDur(m.file.dur):short(m.file.name,34)),h('small',{},(m.sender_name||'')+' · '+jdate(m.created_at)+' · '+fmtSize(m.file.size))),
        h('button',{class:'iconbtn',onclick:e=>{e.stopPropagation();download(m)}},ic('download')))}))
  }catch(e){box.replaceChildren(h('div',{class:'hint'},e.message))}}
function sharedSection(c){
  const box=h('div',{style:'min-height:80px'}),tabs=[['media','رسانه'],['file','فایل'],['voice','ویس'],['audio','موزیک'],['link','لینک']];
  const seg=h('div',{class:'seg'},tabs.map(([k,t])=>h('button',{class:k==='media'?'on':'',onclick:e=>{[...seg.children].forEach(x=>x.classList.remove('on'));e.currentTarget.classList.add('on');sharedTab(box,c.id,k)}},t)));
  sharedTab(box,c.id,'media');return[seg,box]}
/* ---------- privacy: last seen, read receipts, block ---------- */
S.priv={priv_seen:'all',read_receipts:true,blocked:[]};
async function loadPrivacy(){try{const r=await call('privacy_get');S.priv={priv_seen:r.priv_seen,read_receipts:r.read_receipts,blocked:r.blocked}}catch{}}
const isBlocked=id=>(S.priv.blocked||[]).some(u=>u.id===id);
function blockRow(p){
  const b=h('button',{class:'btn '+(isBlocked(p.id)?'soft':'danger'),style:'display:block;margin-top:8px'},isBlocked(p.id)?'خارج کردن از بلاک':'بلاک کردن این کاربر');
  b.onclick=async()=>{const on=!isBlocked(p.id);if(on&&!confirm('«'+p.display_name+'» بلاک بشه؟ نمی‌تونه بهت پیام بده یا زنگ بزنه و آخرین بازدیدت رو نمی‌بینه.'))return;
    try{const r=await call(on?'block':'unblock',{user_id:p.id});S.priv.blocked=r.blocked;b.textContent=on?'خارج کردن از بلاک':'بلاک کردن این کاربر';b.className='btn '+(on?'soft':'danger');toast(on?'بلاک شد':'از بلاک خارج شد',false)}catch(e){toast(e.message)}};
  return b}

const FORGE_FEATS={calc:'🧮 ماشین حساب',time:'🕐 ساعت و تاریخ',joke:'😂 جوک',password:'🔑 ساخت رمز',dice:'🎲 تاس و سکه'};
async function dlgBotForge(){
  const desc=h('textarea',{rows:6,maxlength:2000,placeholder:'مثال:\nیه ربات برای فروشگاهم می‌خوام. اسمش «ربات فروشگاه» باشه.\nپیام خوش‌آمد: سلام! به فروشگاه ما خوش اومدی 🌹\nاگه کاربر گفت قیمت، جواب بده: قیمت‌ها توی سایتمونه.\nاگه گفت ارسال، جواب بده: ارسال ۲ تا ۴ روز کاری طول می‌کشه.\nاگه نفهمید بگه: متوجه نشدم 🤔\nماشین حساب هم داشته باشه و جوک هم بگه.'});
  const err=h('div',{class:'msg'});
  dialog('ربات‌ساز 🤖',h('div',{},
    h('div',{class:'muted',style:'line-height:1.9;font-size:13px'},'ایده‌ت رو با زبون خودت توضیح بده؛ ربات‌ساز از روش اسم، پیام خوش‌آمد، سوال‌وجواب‌ها و قابلیت‌های ربات رو درمیاره و همون لحظه می‌سازدش.'),
    desc,err,
    h('button',{class:'btn',onclick:async()=>{const t=desc.value.trim();if(t.length<10){err.textContent='یکم بیشتر توضیح بده';return}err.textContent='';try{const r=await call('forge_parse',{description:t});forgeReview(r.config)}catch(e){err.textContent=e.message}}},'بررسی ایده ✨')))}
function forgeReview(cfg){
  const name=h('input',{value:cfg.name||'',maxlength:40});
  const user=h('input',{value:cfg.username||'',maxlength:32,dir:'ltr',style:'text-align:left'});
  const wel=h('textarea',{rows:3,maxlength:500},cfg.welcome||'');
  const fb=h('input',{value:cfg.fallback||'',maxlength:300});
  const err=h('div',{class:'msg'});
  const rules=(cfg.rules||[]).length?h('div',{},h('b',{},'سوال‌وجواب‌هایی که فهمیدم:'),...(cfg.rules||[]).map(r=>h('div',{class:'muted',style:'font-size:13px;line-height:1.9'},'• «'+r.k+'» ← '+r.a))):h('div',{class:'muted',style:'font-size:13px'},'سوال‌وجواب خاصی پیدا نکردم؛ توی توضیحت این‌جوری بنویس: «اگه گفت X جواب بده Y»');
  const feats=(cfg.features||[]).length?h('div',{style:'margin-top:6px'},h('b',{},'قابلیت‌ها: '),h('span',{class:'muted',style:'font-size:13px'},cfg.features.map(f=>FORGE_FEATS[f]||f).join('، '))):null;
  dialog('ربات‌ساز 🤖',h('div',{},
    h('label',{},'اسم ربات'),name,
    h('label',{},'آیدی ربات (لاتین)'),user,
    h('label',{},'پیام خوش‌آمد (شروع)'),wel,
    h('label',{},'جواب وقتی نفهمید'),fb,
    h('hr'),rules,feats,err,
    h('button',{class:'btn',onclick:async()=>{const un=user.value.trim();if(!USER_RE.test(un)){err.textContent='آیدی معتبر نیست (لاتین، ۳ تا ۳۲ کاراکتر)';return}err.textContent='';try{const r=await call('forge_create',{name:name.value.trim(),username:un,config:{...cfg,name:name.value.trim(),username:un,welcome:wel.value.trim(),fallback:fb.value.trim()}});forgeDone(r.bot)}catch(e){err.textContent=e.message}}},'ساخت ربات 🚀')))}
function forgeDone(bot){
  dialog('رباتت ساخته شد 🎉',h('div',{style:'text-align:center'},
    gav('u',bot.id,bot.display_name,0,84,false),
    h('div',{style:'margin-top:8px'},h('b',{style:'font-size:17px'},bot.display_name)),
    h('div',{class:'muted'},at(bot.username)),
    h('div',{class:'muted',style:'font-size:13px;line-height:1.9;margin-top:6px'},'رباتت آماده‌ست! باهاش چت کن؛ توی گروه‌ها هم می‌تونی اضافه‌ش کنی. روی آیدی بزنی کپی می‌شه.'),
    h('button',{class:'btn',style:'margin-top:10px',onclick:()=>{closeDialog();openPrivate(bot.username)}},'شروع گفتگو 💬')))}

async function dlgPrivacy(){
  await loadPrivacy();
  const seg=h('div',{class:'seg'}),modes=[['all','همه'],['contacts','مخاطب‌ها'],['nobody','هیچ‌کس']];
  const drawSeg=()=>seg.replaceChildren(...modes.map(([k,t])=>h('button',{class:S.priv.priv_seen===k?'on':'',type:'button',onclick:async()=>{
    try{const r=await call('privacy_set',{priv_seen:k});S.priv.priv_seen=r.priv_seen;drawSeg()}catch(e){toast(e.message)}}},t)));drawSeg();
  const rr=h('span',{class:'sw2'+(S.priv.read_receipts?' on':'')}),
    rrRow=h('div',{class:'tog',onclick:async()=>{const on=!S.priv.read_receipts;try{const r=await call('privacy_set',{read_receipts:on});S.priv.read_receipts=r.read_receipts;rr.classList.toggle('on',r.read_receipts)}catch(e){toast(e.message)}}},h('span',{},'تیک خوانده‌شدن (دو طرفه)'),rr);
  const list=h('div',{class:'ulist'});
  const drawList=()=>list.replaceChildren(...((S.priv.blocked||[]).length?S.priv.blocked.map(u=>h('div',{class:'member'},avatar('u',u.id,u.display_name,u.avatar_at,38,false),
    h('div',{class:'grow'},h('b',{},u.display_name),h('div',{class:'muted',style:'font-size:12px'},at(u.username))),
    h('button',{class:'btn soft',style:'width:auto;margin:0;padding:6px 12px',onclick:async()=>{try{const r=await call('unblock',{user_id:u.id});S.priv.blocked=r.blocked;drawList()}catch(e){toast(e.message)}}},'آزاد کردن'))):[h('div',{class:'hint'},'کسی رو بلاک نکردی')]));drawList();
  dialog('حریم خصوصی',h('b',{},'کی آخرین بازدید و آنلاین بودنم رو ببینه؟'),seg,
    h('div',{class:'muted',style:'font-size:12px;line-height:1.7'},'«مخاطب‌ها» یعنی کسایی که با هم پیام رد و بدل کردین. اگه مخفی کنی، بقیه به‌جاش «به‌تازگی» می‌بینن.'),
    h('hr'),rrRow,
    h('div',{class:'muted',style:'font-size:12px;line-height:1.7'},'اگه خاموشش کنی، نه تیک خوانده‌شدن پیام‌هات رو بقیه می‌بینن، نه تو مال اونا رو.'),
    h('hr'),h('b',{},'امنیت'),pinSettingsBlock(),
    h('hr'),h('b',{},'کاربران بلاک‌شده'),list)}

/* ---------- passcode lock: 4-digit PIN, local to this device ---------- */
const PIN_KEY='wd-pin';
function pinHash(pin){const s='dg:'+pin+':pin';let h1=0xdeadbeef,h2=0x41c6ce57;for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677)}h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);return(h2>>>0).toString(16)+'-'+(h1>>>0).toString(16)}
const pinIsSet=()=>!!lsGet(PIN_KEY);
const pinCheck=pin=>lsGet(PIN_KEY)===pinHash(pin);
function pinPadEl(onDone){
  let val='';
  const dots=h('div',{class:'pindots'},...[0,1,2,3].map(()=>h('span',{class:'pindot'})));
  const msg=h('div',{class:'pinmsg'});
  const draw=()=>{[...dots.children].forEach((d,i)=>d.classList.toggle('on',i<val.length))};
  const press=d=>{
    if(d==='del'){val=val.slice(0,-1);sfx('tap')}
    else if(val.length<4){val+=d;sfx('tap');if(val.length===4)setTimeout(()=>{const v=val;val='';draw();onDone(v)},150)}
    draw()};
  const key=(label,fn,cls)=>h('button',{class:'pinkey '+(cls||''),onclick:()=>fn()},label);
  const pad=h('div',{class:'pinpad'},
    ...['1','2','3','4','5','6','7','8','9'].map(n=>key(n,()=>press(n))),
    h('span'),key('0',()=>press('0')),key('⌫',()=>press('del'),'del'));
  return{el:h('div',{class:'pinwrap'},dots,msg,pad),
    reset(){val='';draw()},
    shake(){msg.textContent='رمز اشتباه است؛ دوباره تلاش کن';dots.classList.remove('shake');void dots.offsetWidth;dots.classList.add('shake');sfx('error');val='';draw()}}}
function dlgPinSetup(){
  let first=null;
  const step=h('div',{class:'muted',style:'text-align:center;font-size:13px'},'یه رمز ۴ رقمی انتخاب کن');
  const pad=pinPadEl(v=>{
    if(!first){first=v;step.textContent='رمز رو دوباره وارد کن';pad.reset();return}
    if(v===first){lsSet(PIN_KEY,pinHash(v));closeDialog();sfx('success');toast('🔐 رمز ورود فعال شد',false);if(window.__pinRedraw)window.__pinRedraw()}
    else{first=null;step.textContent='دو رمز یکی نبود؛ از اول وارد کن';pad.shake()}});
  dialog('🔐 تنظیم رمز ورود',step,pad.el)}
function dlgPinVerify(title,fn){
  const pad=pinPadEl(v=>{if(pinCheck(v)){closeDialog();fn()}else pad.shake()});
  dialog(title,h('div',{class:'muted',style:'text-align:center;font-size:13px'},'رمز فعلی رو وارد کن'),pad.el)}
function pinSettingsBlock(){
  const box=h('div',{});
  const draw=()=>{
    if(pinIsSet())box.replaceChildren(
      h('div',{class:'tog',onclick:()=>dlgPinVerify('تغییر رمز ورود',dlgPinSetup)},h('span',{},'🔐 تغییر رمز ورود'),h('span',{class:'chev'},'‹')),
      h('div',{class:'tog',onclick:()=>dlgPinVerify('حذف رمز ورود',()=>{localStorage.removeItem(PIN_KEY);sfx('success');toast('رمز ورود حذف شد',false);draw()})},h('span',{style:'color:var(--danger,#e53935)'},'🗑 حذف رمز ورود'),h('span',{class:'chev'},'‹')));
    else box.replaceChildren(
      h('div',{class:'tog',onclick:dlgPinSetup},h('span',{},'🔐 تنظیم رمز ورود'),h('span',{class:'chev'},'‹')),
      h('div',{class:'muted',style:'font-size:12px;line-height:1.7'},'با فعال‌کردن رمز ورود، هر بار که از دارک گرام خارج بشی و برگردی، اول این رمز ۴ رقمی ازت خواسته می‌شه.'));
  };
  window.__pinRedraw=draw;draw();return box}
let __pinLocked=false,__hiddenAt=0;
function showPinLock(){
  if(__pinLocked||!pinIsSet()||!S.me)return;__pinLocked=true;
  const pad=pinPadEl(v=>{if(pinCheck(v)){__pinLocked=false;ov.classList.add('bye');sfx('lock');setTimeout(()=>ov.remove(),260)}else pad.shake()});
  const ov=h('div',{id:'pinlock'},
    h('div',{class:'pinlockcard'},
      h('div',{class:'pinlocklogo'},'🔐'),
      h('b',{style:'font-size:19px'},'دارک گرام قفل است'),
      h('div',{class:'muted',style:'font-size:13px'},'رمز ورود ۴ رقمی رو وارد کن'),
      pad.el,
      h('button',{class:'btn soft',style:'margin-top:16px',onclick:()=>{localStorage.removeItem(PIN_KEY);__pinLocked=false;logout()}},'خروج از حساب')));
  document.body.append(ov)}
function maybePinLock(){if(pinIsSet())showPinLock()}
document.addEventListener('visibilitychange',()=>{if(document.hidden){__hiddenAt=Date.now()}else if(__hiddenAt&&Date.now()-__hiddenAt>60000)showPinLock()});

function dlgInfo(){
  const c=S.chats[S.current];if(!c)return;
  const muteRow=h('div',{class:'tog',onclick:async e=>{await setChat(c.id,{muted:!c.muted});e.currentTarget.lastChild.classList.toggle('on',!!c.muted)}},h('span',{},'بی‌صدا کردن اعلان‌ها'),h('span',{class:'sw2'+(c.muted?' on':'')}));
  if(c.kind==='private'&&c.peer){const p=c.peer;
    dialog('',profHead(p),profActions(p,c,false),profInfo(p),giftBox(p),muteRow,blockRow(p),h('button',{class:'btn soft',style:'margin-top:8px',onclick:()=>dlgReport({user_id:p.id})},'🚨 گزارش'),...sharedSection(c));return}
  if(c.saved){dialog('پیام‌های ذخیره‌شده',...sharedSection(c));return}
  if(c.channel&&!c.bcast){
    const adm=!!c.can_post,big=h('div',{class:'pbig'+(c.official?' offprof':'')}),err=h('div',{class:'msg'});
    const draw=()=>{const cc=S.chats[c.id]||c;big.replaceChildren(cc.avatar_at?gav('c',cc.id,cc.title,cc.avatar_at,112,false):h('div',{class:'avatar',style:'width:112px;height:112px;background:linear-gradient(135deg,#f4511e,#ff8a50)'},ic('channel',56)),
      adm?h('button',{class:'cam',onclick:pick,title:'تغییر عکس'},ic('camera',18)):null,h('b',{style:'font-size:18px'},cc.title),cc.official?h('div',{class:'offbanner'},'⭐ کانال رسمی پریمیوم'):null,h('div',{class:'muted',style:'font-size:13px;white-space:pre-wrap;text-align:center'},cc.description||''),h('div',{class:'muted',style:'font-size:12px'},fa(cc.member_count)+' مشترک'))};
    const[inp,pick]=photoPicker(null,'chat',c.id,()=>setTimeout(draw,400));draw();
    const title=h('input',{value:c.title,maxlength:40}),desc=h('textarea',{rows:2,maxlength:200,style:'resize:none'},c.description||'');
    dialog(c.title,big,inp,adm?h('div',{},h('label',{},'نام کانال'),title,h('label',{},'توضیحات'),desc,
      h('button',{class:'btn soft',onclick:async()=>{try{const r=await call('edit_group',{chat_id:c.id,title:title.value,description:desc.value});S.chats[c.id]=Object.assign(S.chats[c.id],r.chat);renderList();fillHeader();draw();toast('ذخیره شد',false)}catch(e){err.textContent=e.message}}},'ذخیره'),
      c.avatar_at?h('button',{class:'btn danger',onclick:async()=>{try{await call('remove_avatar',{chat_id:c.id});setTimeout(draw,400)}catch(e){err.textContent=e.message}}},'حذف عکس کانال'):null,err):null,muteRow,...sharedSection(c));return}
  const list=h('div'),err=h('div',{class:'msg'}),isOwner=c.owner_id===S.me.id,isMgr=isOwner||c.my_role==='admin';
  const big=h('div',{class:'pbig'});
  const B=!!c.bcast,draw=()=>{const cc=S.chats[c.id]||c;big.replaceChildren(cc.avatar_at||!B?gav('c',cc.id,cc.title,cc.avatar_at,112,false):h('div',{class:'avatar',style:'width:112px;height:112px;background:linear-gradient(135deg,#f4511e,#ff8a50)'},ic('channel',56)),isOwner?h('button',{class:'cam',onclick:pick},ic('camera',18)):null,h('b',{style:'font-size:18px'},cc.title),h('div',{class:'muted',style:'font-size:13px;white-space:pre-wrap'},cc.description||''),h('div',{class:'muted',style:'font-size:12px'},fa(cc.member_count)+(B?' مشترک':' عضو')))};
  const[inp,pick]=photoPicker(null,'chat',c.id,()=>setTimeout(draw,300));draw();
  const g={id:c.id,async reload(){draw();try{const r=await call('members',{chat_id:c.id});list.replaceChildren(...r.members.map(u=>h('div',{class:'member'},avatar('u',u.id,u.display_name,u.avatar_at,38,u.online),
    h('div',{class:'grow'},h('b',{},u.display_name),u.tag?h('span',{class:'gtag'},u.tag):null,h('div',{class:'muted',style:'font-size:12px'},at(u.username),(u.role==='owner'?' · سازنده':u.role==='admin'?' · ادمین':''))),
    isOwner&&u.role!=='owner'?h('button',{class:'iconbtn',title:u.role==='admin'?'برداشتن ادمین':'ادمین کردن',onclick:async()=>{try{await call('set_role',{chat_id:c.id,user_id:u.id,admin:u.role!=='admin'});err.textContent=''}catch(e){err.textContent=e.message}}},ic('check')):null,
    isMgr&&u.id!==S.me.id&&u.role!=='owner'&&(isOwner||u.role!=='admin')?h('button',{class:'iconbtn',title:c.bcast?'حذف از کانال':'حذف از گروه',onclick:async()=>{try{await call('remove_member',{chat_id:c.id,user_id:u.id})}catch(e){err.textContent=e.message}}},ic('close')):null)))}catch(e){err.textContent=e.message}}};
  const add=h('input',{placeholder:'نام کاربری عضو جدید',style:'flex:1'}),
    addBtn=h('button',{class:'btn',style:'width:auto;margin:0',onclick:async()=>{const n=add.value.trim().replace(/^@/,'');if(!n)return;try{await call('add_member',{chat_id:c.id,username:n});add.value='';err.textContent=''}catch(e){err.textContent=e.message}}},'افزودن');
  const title=h('input',{value:c.title,maxlength:40}),desc=h('textarea',{rows:2,maxlength:200,style:'resize:none'},c.description||''),
    uname=h('input',{value:c.username||'',placeholder:c.bcast?'مثلاً my_channel':'مثلاً my_group',maxlength:32,autocapitalize:'none',dir:'ltr'}),link=h('div',{class:'invl'});
  let pubSel=!!c.username;
  const pubLink=h('div',{class:'invl'}),pubBox=h('div',{},h('label',{},c.bcast?'آیدی عمومی کانال':'آیدی عمومی گروه'),uname,h('label',{},'لینک عمومی'),pubLink);
  const drawPub=()=>{const u=uname.value.trim().replace(/^@/,'');const url=location.origin+'/#join=@'+u;
    pubLink.replaceChildren(u?h('div',{class:'invurl',dir:'ltr'},url):h('div',{class:'muted',style:'font-size:12px'},'یه آیدی بنویس تا لینک عمومی ساخته بشه'),
    u?h('div',{class:'invbtns'},h('button',{class:'btn soft',onclick:()=>copyText(url)},'کپی لینک')):null)};
  uname.addEventListener('input',drawPub);drawPub();
  const segType=h('div',{class:'seg'},h('button',{class:!pubSel?'on':''},'🔒 خصوصی'),h('button',{class:pubSel?'on':''},'🌐 عمومی'));
  segType.children[0].onclick=()=>{pubSel=false;segType.children[0].classList.add('on');segType.children[1].classList.remove('on');pubBox.hidden=true};
  segType.children[1].onclick=()=>{pubSel=true;segType.children[1].classList.add('on');segType.children[0].classList.remove('on');pubBox.hidden=false};
  pubBox.hidden=!pubSel;
  const drawLink=async reset=>{try{const r=await call('invite_link',{chat_id:c.id,reset:!!reset});const u=location.origin+'/#join='+r.invite;
    link.replaceChildren(h('div',{class:'invurl',dir:'ltr'},u),h('div',{class:'invbtns'},h('button',{class:'btn soft',onclick:()=>copyText(u)},'کپی لینک'),
      h('button',{class:'btn soft',onclick:()=>{if(confirm('لینک قبلی از کار می‌افته. لینک جدید ساخته بشه؟'))drawLink(true)}},'لینک جدید')))}catch(e){err.textContent=e.message}};
  if(isOwner)drawLink(false);
  dialog(c.bcast?'اطلاعات کانال':'اطلاعات گروه',big,inp,
    isMgr?h('div',{},h('label',{},c.bcast?'نام کانال':'اسم گروه'),title,h('label',{},'توضیحات'),desc,h('label',{},'نوع '+(c.bcast?'کانال':'گروه')),segType,pubBox,h('label',{},'لینک دعوت خصوصی'),link,
      h('button',{class:'btn soft',onclick:async()=>{try{const r=await call('edit_group',{chat_id:c.id,title:title.value,description:desc.value,username:pubSel?uname.value:''});S.chats[c.id]=Object.assign(S.chats[c.id],r.chat);renderList();fillHeader();draw();toast('ذخیره شد',false)}catch(e){err.textContent=e.message}}},'ذخیره تغییرات')):null,
    muteRow,h('h4',{style:'margin:14px 0 4px'},c.bcast?(isMgr?'مشترک‌ها و ادمین‌ها':'مدیران کانال'):'اعضا'),list,isMgr?h('div',{style:'display:flex;gap:8px;margin-top:10px'},add,addBtn):null,err,
    c.bcast&&isOwner?null:h('button',{class:'btn danger',onclick:()=>leaveGroup(c)},c.bcast?'ترک کانال':'ترک گروه'),isOwner?h('button',{class:'btn danger',onclick:()=>deleteGroup(c)},c.bcast?'حذف کانال برای همه':'حذف گروه برای همه'):null,h('hr'),...sharedSection(c));
  window.__group=g;g.reload()}

function copyText(t){
  const done=()=>toast('کپی شد',false);
  if(navigator.clipboard&&window.isSecureContext)return navigator.clipboard.writeText(t).then(done).catch(()=>fallbackCopy(t,done));
  fallbackCopy(t,done)}
function fallbackCopy(t,done){const x=h('textarea',{style:'position:fixed;opacity:0'},t);document.body.append(x);x.select();try{document.execCommand('copy');done()}catch{toast('کپی نشد')}x.remove()}
/* join a group by invite link (#join=token) or by its public @id */
function joinDialog(info,ref){
  if(info.member&&S.chats[info.id]){closeDialog();return openChat(info.id)}
  dialog(info.bcast?'پیوستن به کانال':'پیوستن به گروه',h('div',{class:'pbig'},info.bcast?h('div',{class:'avatar',style:'width:84px;height:84px;background:linear-gradient(135deg,#f4511e,#ff8a50)'},ic('channel',42)):h('div',{class:'avatar',style:'width:84px;height:84px;font-size:36px;background:'+COLORS[(info.id||0)%COLORS.length]},initial(info.title)),
    h('b',{style:'font-size:18px'},info.title),info.username?h('div',{class:'muted',dir:'ltr'},'@'+info.username):null,h('div',{class:'muted',style:'font-size:13px;white-space:pre-wrap;text-align:center'},info.description||''),h('div',{class:'muted',style:'font-size:12px'},fa(info.member_count)+(info.bcast?' مشترک':' عضو'))),
    h('button',{class:'btn',onclick:async()=>{try{const r=await call('join',ref);S.chats[r.chat.id]=r.chat;closeDialog();renderList();openChat(r.chat.id)}catch(e){toast(e.message)}}},info.bcast?'عضو کانال شو':'عضو شو'))}
function parseJoinRef(u){try{const x=new URL(u);if(x.origin!==location.origin)return null;const m=x.hash.match(/^#join=([^&]{3,60})$/);return m?decodeURIComponent(m[1]):null}catch{return null}}
function parseGiftRef(u){try{const url=new URL(u);if(url.origin!==location.origin)return null;const m=url.hash.match(/^#gift=([\w]+)-(\d+)$/);return m?{gift:m[1],serial:+m[2]}:null}catch(_){return null}}
async function openGiftLink(ref){try{const r=await call('gift_info',{gift:ref.gift,serial:ref.serial});nftInfoDialog({gift:r.gift,serial:r.serial,backdrop:r.backdrop},r.owner)}catch(e){toast(e.message)}}
function grabGiftFromUrl(){const m=location.hash.match(/^#gift=([\w]+)-(\d+)$/);if(m){try{history.replaceState(null,'',location.pathname)}catch{}if(S.me)openGiftLink({gift:m[1],serial:+m[2]})}}
window.addEventListener('hashchange',grabGiftFromUrl);
async function handleJoin(){
  const v=lsGet('wd-join');if(!v||!S.me)return;lsSet('wd-join',null);
  const ref=v[0]==='@'?{username:v.slice(1)}:{token:v};
  try{const r=await call('invite_info',ref);joinDialog(r.chat,ref)}catch(e){if(ref.username)openMention(ref.username);else toast(e.message)}}
function grabJoinFromUrl(){const m=location.hash.match(/^#join=([^&]{3,60})$/);if(m){lsSet('wd-join',decodeURIComponent(m[1]));try{history.replaceState(null,'',location.pathname)}catch{}if(S.me)handleJoin()}}
window.addEventListener('hashchange',grabJoinFromUrl);

/* ---------- in-chat search ---------- */
const SR={res:[],i:0,job:null};
function openSearch(){$('#schbar').hidden=false;$('#schq').value='';$('#schq').focus();SR.res=[];$('#schcnt').textContent=''}
function closeSearch(){$('#schbar').hidden=true;SR.res=[]}
function gotoResult(){if(!SR.res.length)return;const m=SR.res[SR.i];$('#schcnt').textContent=fa(SR.i+1)+' از '+fa(SR.res.length);jumpTo(m.id)}
$('#schq')&&0;
async function runSearch(){
  const q=$('#schq').value.trim();if(q.length<2){SR.res=[];$('#schcnt').textContent='';return}
  try{const r=await call('search_messages',{chat_id:S.current,q});if(q!==$('#schq').value.trim())return;SR.res=r.messages;SR.i=0;$('#schcnt').textContent=r.messages.length?'':'چیزی پیدا نشد';gotoResult()}catch(e){toast(e.message)}}

/* ---------- voice calls (WebRTC; audio goes peer-to-peer, the server only rings and relays signals) ---------- */
let C=null,ringT=null;
const callText={hangup:'تماس تموم شد',rejected:'تماس رد شد',cancelled:'تماس لغو شد',missed:'پاسخی داده نشد',disconnected:'ارتباط تماس قطع شد',answered_elsewhere:''};
async function getMic(){
  if(!window.isSecureContext)throw new Error('مرورگر روی http اجازه میکروفون نمی‌ده. با آدرس https باز کن.');
  if(!navigator.mediaDevices)throw new Error('این مرورگر از تماس صوتی پشتیبانی نمی‌کنه');
  try{return await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:false,autoGainControl:true,channelCount:1},video:false})}catch{throw new Error('دسترسی به میکروفون داده نشد')}}
function ring(kind){clearInterval(ringT);ringT=null;if(!kind)return;const b=()=>beep(kind==='in'?520:425,kind==='in'?.6:1,.08);b();ringT=setInterval(b,kind==='in'?1800:3000)}
function showCallUI(){
  if(!C)return;const ui=$('#callui');ui.hidden=false;
  const st=C.state==='active'&&C.reconnecting?'در حال اتصال مجدد…':{ringing:'در حال زنگ زدن…',incoming:C.wantVideo?'تماس تصویری ورودی…':'تماس صوتی ورودی…',connecting:'در حال اتصال…',active:''}[C.state];
  const cb=(cls,t,icn,fn)=>h('button',{class:'cbtn '+cls,title:t,onclick:fn},ic(icn,28));
  const btns=C.state==='incoming'?[cb('red','رد','close',hangup),cb('green','پاسخ','phone',acceptCall)]
    :[cb(C.muted?'on':'',C.muted?'روشن کردن میکروفون':'بی‌صدا','mic',toggleMute),cb(C.cam?'on':'',C.cam?'خاموش کردن دوربین':'روشن کردن دوربین','video',toggleCam),cb(C.loud?'on':'','بلندگو / خروجی صدا','speaker',speakerMenu),cb('red','قطع','phone',hangup)];
  if(!C.rimg){C.rimg=h('img',{class:'rvid',alt:''});C.rimg.hidden=true;C.lvid=h('video',{class:'lvid',muted:true,playsinline:true,autoplay:true});C.lvid.muted=true;C.lvid.hidden=true;C.lvid.srcObject=C.vstream||null}
  ui.replaceChildren(C.rimg,C.lvid,h('div',{class:'cinfo'},C.rimg.hidden?avatar('u',C.peer.id,C.peer.display_name,C.peer.avatar_at,110,false):null,h('div',{class:'cname'},C.peer.display_name),h('div',{class:'cstat',id:'cstat'},st)),h('div',{class:'cbtns'},btns));
  if(C.state==='active')tickCall()}
/* camera: small JPEG frames (about 10 per second) relayed through the server, like the audio */
async function toggleCam(){
  const c=C;if(!c)return;
  if(c.cam){c.cam=false;clearInterval(c.camT);if(c.vstream)c.vstream.getTracks().forEach(t=>t.stop());c.vstream=null;c.lvid.srcObject=null;c.lvid.hidden=true;
    if(ws&&ws.readyState===1)ws.send(JSON.stringify({op:'call_video',call_id:c.id,d:''}));return showCallUI()}
  if(!navigator.mediaDevices)return toast('این مرورگر دوربین نداره');
  let vs;try{vs=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:480},height:{ideal:360},facingMode:'user'},audio:false})}catch{return toast('دسترسی به دوربین داده نشد')}
  if(C!==c){vs.getTracks().forEach(t=>t.stop());return}
  c.vstream=vs;c.cam=true;showCallUI();c.lvid.srcObject=vs;c.lvid.hidden=false;c.lvid.play().catch(()=>{});
  const cv=document.createElement('canvas'),vid=document.createElement('video');vid.muted=true;vid.playsInline=true;vid.srcObject=vs;await vid.play().catch(()=>{});
  c.camT=setInterval(()=>{
    if(C!==c||!ws||ws.readyState!==1||ws.bufferedAmount>80000||!vid.videoWidth)return;      // audio has priority: skip video when the link is busy
    const hh=Math.min(360,vid.videoHeight),w=Math.round(hh*vid.videoWidth/vid.videoHeight);cv.width=w;cv.height=hh;cv.getContext('2d').drawImage(vid,0,0,w,hh);       // 360p: the server upload is only ~5 Mbps
    const d=cv.toDataURL('image/jpeg',.5);ws.send(JSON.stringify({op:'call_video',call_id:c.id,d:d.slice(23)}))},125)}   // 8 fps
function onCallVideo(e){
  if(!C||C.id!==e.call_id||!C.rimg)return;
  if(!e.d){C.rimg.hidden=true;return showCallUI()}
  const was=C.rimg.hidden;C.rimg.src='data:image/jpeg;base64,'+e.d;if(was){C.rimg.hidden=false;showCallUI();C.rimg.hidden=false}}
function tickCall(){const e=$('#cstat');if(!e||!C||!C.t0)return;const s=Math.floor((Date.now()-C.t0)/1000);
  e.textContent=C.reconnecting?'در حال اتصال مجدد… صبر کن':C.peerAway?'اتصال طرف مقابل ضعیفه؛ منتظر برگشتنش…':fa(String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'))+(C.rtt!=null?'  ·  تأخیر شبکه '+fa(C.rtt)+' ms':'');
  if(!C.pinging&&(!C.lastPing||Date.now()-C.lastPing>2000)){const c=C;c.pinging=true;c.lastPing=Date.now();const t=performance.now();
    call('ping').then(()=>{c.rtt=Math.round(performance.now()-t)}).catch(()=>{}).finally(()=>{c.pinging=false})}}
async function startCall(video){
  const c=S.chats[S.current];if(!c||c.kind!=='private'||!c.peer)return;if(C)return toast('الان تو تماس هستی');if(REC.on)return toast('اول ضبط ویس رو تموم کن');
  let stream;try{stream=await getMic()}catch(e){return toast(e.message)}
  try{const r=await call('call_invite',{chat_id:c.id,video:!!video});
    C={id:r.call_id,chatId:c.id,peer:c.peer,state:'ringing',stream,pc:null,muted:false,ice:[],chain:Promise.resolve(),t0:null,wantVideo:!!video};showCallUI();ring('out')}
  catch(e){stream.getTracks().forEach(t=>t.stop());toast(e.message)}}
function onIncoming(e){
  if(C||REC.on){call('call_end',{call_id:e.call_id}).catch(()=>{});return}
  C={id:e.call_id,chatId:e.chat_id,peer:e.from,state:'incoming',stream:null,pc:null,muted:false,ice:[],chain:Promise.resolve(),t0:null,wantVideo:!!e.video};showCallUI();ring('in')}
async function acceptCall(){
  if(!C||C.state!=='incoming')return;const id=C.id;let stream;
  try{stream=await getMic()}catch(err){toast(err.message);return hangup()}
  if(!C||C.id!==id){stream.getTracks().forEach(t=>t.stop());return}
  C.stream=stream;C.state='active';C.t0=Date.now();ring(null);startRelay();showCallUI();C.tick=setInterval(tickCall,1000);if(C.wantVideo)toggleCam();
  try{await call('call_accept',{call_id:id})}catch(err){toast(err.message);endLocal()}}
function makePc(){
  const pc=new RTCPeerConnection({iceServers:S.ice||[{urls:'stun:stun.l.google.com:19302'}]}),id=C.id;C.pc=pc;
  C.stream.getTracks().forEach(t=>pc.addTrack(t,C.stream));
  C.cto=setTimeout(()=>{if(C&&C.id===id&&C.state!=='active'){toast('اتصال مستقیم صدا برقرار نشد (احتمالاً NAT/فایروال؛ برای تماس بین شبکه‌های مختلف سرور TURN لازمه — README)');hangup()}},20000);
  pc.onicecandidate=ev=>{if(ev.candidate&&C&&C.id===id)call('call_signal',{call_id:id,data:{type:'ice',candidate:ev.candidate}}).catch(()=>{})};
  pc.ontrack=ev=>{const a=$('#remote');a.srcObject=ev.streams[0];a.play().catch(()=>{})};
  pc.onconnectionstatechange=()=>{if(!C||C.id!==id)return;const st=pc.connectionState;
    if(st==='connected'){clearTimeout(C.cto);if(C.state!=='active'){C.state='active';C.t0=Date.now();clearInterval(C.tick);C.tick=setInterval(tickCall,1000);ring(null);showCallUI()}}
    else if(st==='disconnected'){const e=$('#cstat');if(e)e.textContent='اتصال ضعیفه…'}
    else if(st==='failed'){toast('اتصال صدا برقرار نشد');hangup()}}}
async function onAccepted(e){
  if(!C||C.id!==e.call_id||C.state!=='ringing')return;
  C.state='active';C.t0=Date.now();ring(null);startRelay();showCallUI();clearInterval(C.tick);C.tick=setInterval(tickCall,1000);if(C.wantVideo)toggleCam()}
function onSignal(){}
/* Audio is relayed through the Teegram server (16-bit PCM over the existing WebSocket): no STUN/TURN or
   internet needed, only the connection to this server. Small jitter buffer, drops audio if it falls behind. */
/* Audio is relayed through the Teegram server over the existing WebSocket as 16-bit PCM (16 kHz mono, 64 ms frames).
   Quality first: nothing is dropped on the sender, the microphone is captured on the audio thread (AudioWorklet),
   and the receiver keeps a big adaptive jitter buffer (starts ~0.4 s, grows after every stall) so playback stays smooth. */
/* voice calls: 48 kHz Opus (~56 kbps, WebCodecs) when both browsers can, else 16 kHz PCM. Both sides start with PCM + an "hq" hint and switch as soon as the other side shows it can decode Opus. */
function callBlock(c,f){
  if(C!==c||c.muted||!ws||ws.readyState!==1||ws.bufferedAmount>400000)return;
  if(!(c.hq&&c.peerHq&&c.ctx.sampleRate===48000))return sendFrame(c,f);
  c.acc=c.acc||new Float32Array(8192);c.n=c.n||0;if(c.n+f.length>c.acc.length)c.n=0;c.acc.set(f,c.n);c.n+=f.length;
  while(c.n>=960){const fr=c.acc.slice(0,960);c.acc.copyWithin(0,960,c.n);c.n-=960;
    try{if(!c.enc)callEncInit(c);c.enc.encode(new AudioData({format:'f32-planar',sampleRate:48000,numberOfFrames:960,numberOfChannels:1,timestamp:c.ets=(c.ets||0)+20000,data:fr}))}catch{c.hq=false;return}}}
function callEncInit(c){
  const cfg={codec:'opus',sampleRate:48000,numberOfChannels:1,bitrate:56000};
  const mk=o=>{const e=new AudioEncoder({output:ch=>{if(C!==c||!ws||ws.readyState!==1)return;const u=new Uint8Array(ch.byteLength);ch.copyTo(u);let s='';for(let i=0;i<u.length;i++)s+=String.fromCharCode(u[i]);
    ws.send(JSON.stringify({op:'call_audio',call_id:c.id,sr:48000,c:'opus',hq:1,d:btoa(s)}))},error:()=>{c.hq=false;c.enc=null}});e.configure(o);return e};
  try{c.enc=mk({...cfg,opus:{application:'voip',signal:'voice',frameDuration:20000,complexity:6,useinbandfec:true}})}catch{c.enc=mk(cfg)}}
function sendFrame(c,f){
  if(C!==c||c.muted||!ws||ws.readyState!==1||ws.bufferedAmount>400000)return;
  if(c.ctx.sampleRate>16000){const k=Math.round(c.ctx.sampleRate/16000),n=Math.floor(f.length/k),g=new Float32Array(n);for(let i=0;i<n;i++){let s=0;for(let j=0;j<k;j++)s+=f[i*k+j];g[i]=s/k}f=g;c.psr=Math.round(c.ctx.sampleRate/k)}else c.psr=c.ctx.sampleRate;
  const pcm=new Int16Array(f.length);for(let i=0;i<f.length;i++){const v=Math.max(-1,Math.min(1,f[i]));pcm[i]=v<0?v*32768:v*32767}
  const u=new Uint8Array(pcm.buffer);let s='';for(let i=0;i<u.length;i+=0x4000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x4000));
  ws.send(JSON.stringify({op:'call_audio',call_id:c.id,sr:c.psr,c:'pcm',hq:c.hq?1:0,d:btoa(s)}))}
async function startRelay(){
  const c=C,AC=window.AudioContext||window.webkitAudioContext;
  c.hq=await rHqCheck();if(C!==c)return;
  try{c.ctx=c.hq?new AC({sampleRate:48000,latencyHint:'interactive'}):new AC({sampleRate:16000,latencyHint:'playback'})}catch{c.hq=false;c.ctx=new AC()}
  c.ctx.resume&&c.ctx.resume();c.next=0;
  c.out=c.ctx.createGain();c.out.gain.value=c.loud?2.2:1;const comp=c.ctx.createDynamicsCompressor();c.out.connect(comp);
  try{c.dest=c.ctx.createMediaStreamDestination();comp.connect(c.dest);const a=$('#remote');a.srcObject=c.dest.stream;a.play().catch(()=>{})}   // a media element keeps playing in the background and can pick the output device
  catch{comp.connect(c.ctx.destination)}
  keepCallAlive(c);
  const src=c.ctx.createMediaStreamSource(c.stream);c.src=src;
  try{
    await c.ctx.audioWorklet.addModule('/static/mic-worklet.js');if(C!==c)return;
    const node=new AudioWorkletNode(c.ctx,'mic',{numberOfInputs:1,numberOfOutputs:0});node.port.onmessage=ev=>callBlock(c,ev.data);src.connect(node);c.proc=node;
  }catch{                                           // old browser: main-thread fallback
    if(C!==c)return;const proc=c.ctx.createScriptProcessor(1024,1,1),mute=c.ctx.createGain();mute.gain.value=0;
    proc.onaudioprocess=ev=>callBlock(c,new Float32Array(ev.inputBuffer.getChannelData(0)));src.connect(proc);proc.connect(mute);mute.connect(c.ctx.destination);c.proc=proc}}
function onCallAudio(e){
  if(!C||C.id!==e.call_id||!C.ctx)return;
  if(e.hq)C.peerHq=true;
  try{const bin=atob(e.d),n=bin.length,u=new Uint8Array(n);for(let i=0;i<n;i++)u[i]=bin.charCodeAt(i);
    if(e.c==='opus'){
      if(!window.AudioDecoder)return;
      if(!C.dec){const c=C;c.dec=new AudioDecoder({output:ad=>{try{const f=new Float32Array(ad.numberOfFrames);ad.copyTo(f,{planeIndex:0,format:'f32-planar'});ad.close();if(C===c)callPlay(f,48000)}catch{try{ad.close()}catch{}}},error:()=>{c.dec=null}});
        c.dec.configure({codec:'opus',sampleRate:48000,numberOfChannels:1});c.dts=0}
      C.dec.decode(new EncodedAudioChunk({type:'key',timestamp:C.dts+=20000,data:u}));return}
    const k=n>>1,dv=new DataView(u.buffer),f=new Float32Array(k);for(let i=0;i<k;i++)f[i]=dv.getInt16(i*2,true)/32768;callPlay(f,e.sr||16000)}catch{}}
function callPlay(f,sr){
  const ctx=C&&C.ctx;if(!ctx)return;let pk=0;for(let i=0;i<f.length;i++){const v=Math.abs(f[i]);if(v>pk)pk=v}
  const ab=ctx.createBuffer(1,f.length,sr);ab.copyToChannel(f,0);
  C.rx=(C.rx||0)+1;C.peak=Math.max(C.peak||0,pk);
  const node=ctx.createBufferSource();node.buffer=ab;node.connect(C.out||ctx.destination);const now=ctx.currentTime,minT=C.hq&&C.peerHq?.12:.3;
  C.target=C.target||(C.hq&&C.peerHq?.15:.4);
  if(C.next<now+.01){                              // buffer ran dry: rebuild it, and make it bigger next time
    if(C.next>0&&now-(C.lastUnder||0)>1){C.target=Math.min(1.5,C.target+(minT<.2?.06:.2));C.lastUnder=now}
    C.next=now+C.target;C.stable=now}
  else if(now-(C.stable||now)>(minT<.2?8:20)&&C.target>minT){C.target=Math.max(minT,C.target-.03);C.stable=now}
  else if(C.next>now+C.target+3)return;           // 3 s behind after a long stall: skip to stay (nearly) live
  node.start(C.next);C.next+=ab.duration}
function toggleLoud(){if(!C)return;C.loud=!C.loud;if(C.out)C.out.gain.value=C.loud?2.2:1;showCallUI()}
async function speakerMenu(e){
  e.stopPropagation();if(!C)return;const r=e.currentTarget.getBoundingClientRect();
  const items=[[C.loud?'صدای عادی':'صدای بلندتر (حالت بلندگو)','speaker',toggleLoud]],rm=$('#remote');
  if(rm.setSinkId&&navigator.mediaDevices&&navigator.mediaDevices.enumerateDevices){
    try{(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audiooutput').forEach(d=>items.push([(C.sink===d.deviceId?'✓ ':'')+(d.label||'خروجی صدا'),'speaker',async()=>{try{await rm.setSinkId(d.deviceId);C.sink=d.deviceId}catch{toast('این خروجی انتخاب نشد')}}]))}catch{}}
  else items.push(['(این مرورگر انتخاب خروجی نداره؛ از دکمه‌های صدای گوشی استفاده کن)','info',()=>{}]);
  popMenu(Math.max(8,r.left-60),r.top-40-items.length*40,items)}
/* keep the call alive when the app goes to the background: screen wake lock + media session; resume audio when you come back */
async function keepCallAlive(c){
  c.wd=setInterval(()=>{if(C===c)resumeCall()},4000);
  try{if(navigator.wakeLock){c.wl=await navigator.wakeLock.request('screen');c.wl.addEventListener('release',()=>{c.wl=null})}}catch{}
  try{if('mediaSession' in navigator){navigator.mediaSession.metadata=new MediaMetadata({title:'تماس با '+c.peer.display_name,artist:'DarkGram'});
    try{navigator.mediaSession.setActionHandler('hangup',()=>hangup())}catch{}}}catch{}}
function resumeCall(){if(!C)return;try{C.ctx&&C.ctx.state!=='running'&&C.ctx.resume()}catch{}try{$('#remote').paused&&$('#remote').play().catch(()=>{})}catch{}
  if(!C.wl&&navigator.wakeLock&&document.visibilityState==='visible'){const c=C;navigator.wakeLock.request('screen').then(w=>{c.wl=w;w.addEventListener('release',()=>{c.wl=null})}).catch(()=>{})}}
function toggleMute(){if(!C||!C.stream)return;C.muted=!C.muted;C.stream.getAudioTracks().forEach(t=>{t.enabled=!C.muted});showCallUI()}
function hangup(){if(!C)return;const id=C.id;call('call_end',{call_id:id}).catch(()=>{});endLocal()}
function endLocal(msg){
  if(!C)return;try{C.wl&&C.wl.release()}catch{}try{if('mediaSession' in navigator)navigator.mediaSession.metadata=null}catch{}ring(null);clearTimeout(C.cto);clearInterval(C.tick);clearInterval(C.wd);try{C.pc&&C.pc.close()}catch{}clearInterval(C.camT);if(C.vstream)C.vstream.getTracks().forEach(t=>t.stop());try{C.proc&&C.proc.disconnect();C.src&&C.src.disconnect();C.ctx&&C.ctx.close()}catch{}
  try{C.enc&&C.enc.close()}catch{}try{C.dec&&C.dec.close()}catch{}
  if(C.stream)C.stream.getTracks().forEach(t=>t.stop());
  $('#remote').srcObject=null;C=null;$('#callui').hidden=true;$('#callui').replaceChildren();if(msg)toast(msg,false)}
window.addEventListener('beforeunload',()=>{if(C)hangup()});
function logout(silent){
  if(C)hangup();cancelRec(true);stopVoice();if(!silent){try{pushOff();call('logout').catch(()=>{})}catch{}}
  setToken(null);clearInterval(S.keyTimer);clearInterval(pingTimer);const s=ws;ws=null;setTimeout(()=>{try{s&&s.close()}catch{}},150);
  openDrawer(false);closeDialog();if(!silent)showAuth();setNet(true)}

/* ---------- wiring ---------- */
setIcon($('#menu'),'menu');setIcon($('#sico'),'search');setIcon($('#fab'),'pencil');setIcon($('#back'),'back');setIcon($('#callbtn'),'phone');setIcon($('#vcallbtn'),'video');setIcon($('#hsearch'),'search');setIcon($('#hmore'),'more');applyChrome();
setIcon($('#sx'),'close',16);
{const sb=document.querySelector('.searchbox'),si2=$('#search'),sxb=$('#sx');
 if(sb&&si2&&sxb){sb.addEventListener('click',()=>{if(sb.classList.contains('exp'))return;sb.classList.add('exp');sxb.hidden=false;setTimeout(()=>{try{si2.focus()}catch{}},70)});
 sxb.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();si2.value='';si2.dispatchEvent(new Event('input'));sb.classList.remove('exp');sxb.hidden=true;try{si2.blur()}catch{}})}}
setIcon($('#emo'),'emoji');setIcon($('#attach'),'attach');setIcon($('#sendbtn'),'mic');setIcon($('#bar-c'),'close');setIcon($('#down'),'down');
setIcon($('#schup'),'up');setIcon($('#schdn'),'down');setIcon($('#schx'),'close');
$('#tab-login').onclick=()=>buildAuth('login');$('#tab-register').onclick=()=>buildAuth('register');
$('#abtn').onclick=submitAuth;$('#form').addEventListener('submit',e=>e.preventDefault());$('#form').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submitAuth()}});
$('#bnav').querySelectorAll('button').forEach(b=>b.onclick=()=>navGo(b.dataset.t));
if(window.WD)document.documentElement.classList.add('inapp');syncBar();
$('#menu').onclick=e=>{e.stopPropagation();openDrawer(true)};$('#scrim').onclick=()=>openDrawer(false);
$('#fab').onclick=e=>{e.stopPropagation();const r=e.currentTarget.getBoundingClientRect();popMenu(r.left,r.top-150,[['چت جدید','pencil',dlgNewChat],['گروه جدید','group',()=>dlgNewGroup()],['کانال جدید','channel',()=>dlgNewGroup(true)]])};
$('#hdr').onclick=e=>{if(!e.target.closest('#back,#callbtn,#vcallbtn,#hsearch,#hmore'))dlgInfo()};
$('#callbtn').onclick=e=>{e.stopPropagation();startCall(false)};$('#vcallbtn').onclick=e=>{e.stopPropagation();startCall(true)};$('#back').onclick=e=>{e.stopPropagation();$('#app').classList.remove('show-chat');S.current=null;renderList()};
$('#hsearch').onclick=e=>{e.stopPropagation();openSearch()};
$('#hmore').onclick=e=>{e.stopPropagation();const c=S.chats[S.current];if(!c)return;const r=e.currentTarget.getBoundingClientRect();
  popMenu(r.left,r.bottom+4,[...(matchMedia('(max-width:760px)').matches?[['تماس تصویری','video',()=>startCall(true)],...(c.channel?[]:[['اتاق تماشا / گوش دادن همزمان','film',()=>openRoom(c.id)]])]:[]),['اطلاعات','info',dlgInfo],['گزارش','info',()=>dlgReport(c.kind==='private'&&c.peer?{user_id:c.peer.id}:{chat_id:c.id})],['جستجو در پیام‌ها','search',openSearch],[c.muted?'فعال کردن اعلان':'بی‌صدا کردن','bellx',()=>setChat(c.id,{muted:!c.muted})],
    [c.fav?'برداشتن سنجاق چت':'سنجاق چت','pin',()=>setChat(c.id,{fav:!c.fav})],c.kind==='group'&&(!c.channel||c.bcast)&&!(c.bcast&&c.owner_id===S.me.id)?['ترک '+(c.bcast?'کانال':'گروه'),'logout',()=>leaveGroup(c),true]:null,c.kind==='group'&&(!c.channel||c.bcast)&&c.owner_id===S.me.id?['حذف '+(c.bcast?'کانال':'گروه'),'delete',()=>deleteGroup(c),true]:null])};
$('#pinbar').onclick=()=>{const c=S.chats[S.current];if(c&&c.pin_msg)jumpTo(c.pin_msg.id)};
$('#schq').addEventListener('input',()=>{clearTimeout(SR.job);SR.job=setTimeout(runSearch,300)});
$('#schq').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();if(SR.res.length){SR.i=(SR.i+1)%SR.res.length;gotoResult()}}if(e.key==='Escape')closeSearch()});
$('#schup').onclick=()=>{if(SR.res.length){SR.i=(SR.i+1)%SR.res.length;gotoResult()}};$('#schdn').onclick=()=>{if(SR.res.length){SR.i=(SR.i-1+SR.res.length)%SR.res.length;gotoResult()}};$('#schx').onclick=closeSearch;
$('#bar-c').onclick=()=>{if(S.editing)$('#input').value='';clearBar();autosize()};
// hold the mic button = record, let go = send, drag away sideways = cancel (a quick tap still works the old way: tap to start, tap to send)
(()=>{const sb=$('#sendbtn');let hold=false,t0=0,sx=0,pr=null,away=false,swallow=false;
  sb.style.touchAction='none';sb.style.userSelect='none';sb.style.webkitUserSelect='none';
  sb.addEventListener('contextmenu',e=>e.preventDefault());
  sb.addEventListener('pointerdown',e=>{if(e.button>0||REC.on||!S.current||S.editing||$('#input').value.trim())return;
    hold=true;away=false;t0=Date.now();sx=e.clientX;swallow=true;try{sb.setPointerCapture(e.pointerId)}catch{}pr=startRec()});
  sb.addEventListener('pointermove',e=>{if(!hold)return;const a=Math.abs(e.clientX-sx)>90;if(a!==away){away=a;$('#rec').classList.toggle('will-cancel',a)}});
  const up=async e=>{if(!hold)return;hold=false;if(e.type==='pointercancel'){away=false;$('#rec').classList.remove('will-cancel');setTimeout(()=>{swallow=false},350);return}const held=Date.now()-t0,cancel=away;away=false;$('#rec').classList.remove('will-cancel');
    setTimeout(()=>{swallow=false},350);try{await pr}catch{}if(!REC.on)return;
    if(cancel)cancelRec();else if(held>=450)finishRec()};
  sb.addEventListener('pointerup',up);sb.addEventListener('pointercancel',up);
  sb.onclick=()=>{if(swallow){swallow=false;return}sendCurrent()}})();$('#reccancel').onclick=()=>cancelRec();
$('#attach').onclick=()=>$('#file').click();$('#file').onchange=e=>{sendFiles(e.target.files);e.target.value=''};
$('#down').onclick=scrollBottom;$('#msgs').addEventListener('scroll',()=>{if(nearBottom()&&!S.hasNewer[S.current]){S.newBelow=0;if(S.current)markRead(S.current)}updateDown()},{passive:true});
$('#input').addEventListener('input',()=>{autosize();updateSendBtn();if(S.current){S.drafts[S.current]=$('#input').value;saveDrafts()}const n=Date.now();if(S.current&&n-S.lastTyping>2500&&$('#input').value.trim()){S.lastTyping=n;call('typing',{chat_id:S.current}).catch(()=>{})}});
$('#input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();sendCurrent()}
  if(e.key==='ArrowUp'&&!$('#input').value&&S.current){const l=S.msgs[S.current]||[];for(let i=l.length-1;i>=0;i--)if(l[i].sender_id===S.me.id&&l[i].body&&!l[i].deleted){startEdit(l[i]);e.preventDefault();break}}});
$('#input').addEventListener('paste',e=>{const fs=[...(e.clipboardData&&e.clipboardData.files||[])];if(fs.length){e.preventDefault();sendFiles(fs)}});
$('#search').addEventListener('input',()=>{clearTimeout(S.searchJob);const q=$('#search').value.trim().replace(/^@/,'');renderList();
  if(!USER_RE.test(q))S.searchRes=[],S.searchGroups=[];if(q.length<2)S.msgRes=[];
  if(q.length<2)return;
  S.searchJob=setTimeout(async()=>{const cur=()=>q===$('#search').value.trim().replace(/^@/,'');
    if(USER_RE.test(q))try{const r=await call('search_users',{q});if(cur()){S.searchRes=r.users;S.searchGroups=r.groups||[];renderList()}}catch{}
    try{const r=await call('search_all',{q});if(cur()){S.msgRes=r.results;renderList()}}catch{}},300)});
const emo=$('#emoji');
async function sendSticker(x){if(!S.current)return;try{const r=await call('send',{chat_id:S.current,sticker:x});sfx('send');ingest(r.message);$('#msgs').scrollTop=$('#msgs').scrollHeight;emo.hidden=true;}catch(e){toast(e.message)}}
const emoGrid=h('div',{class:'emogrid'});EMOJIS.forEach(x=>emoGrid.append(h('button',{type:'button',onclick:()=>{const t=$('#input');t.setRangeText(x,t.selectionStart,t.selectionEnd,'end');t.focus();autosize();updateSendBtn()}},x)));
const stkGrid=h('div',{class:'emogrid stkgrid',hidden:true});STICKERS.forEach(x=>stkGrid.append(h('button',{type:'button',class:'stkbtn',title:'استیکر پریمیوم',onclick:()=>sendSticker(x)},x)));
const premGrid=h('div',{class:'emogrid premgrid',hidden:true});PREM_EMOJIS.forEach(x=>premGrid.append(h('button',{type:'button',class:'prembtn',title:'ایموجی پریمیوم ⭐',onclick:()=>{const t=$('#input');t.setRangeText(x,t.selectionStart,t.selectionEnd,'end');t.focus();autosize();updateSendBtn()}},x)));
const giftGrid=h('div',{class:'giftpanel',hidden:true});
async function sendGiftFromPanel(g,isNft){
  const c=S.chats[S.current];
  if(!c||c.kind!=='private'||!c.peer||c.saved){emo.hidden=true;dlgGifts();return}
  try{const r=await call(isNft?'nft_buy':'gift_send',{gift:g.id,username:c.peer.username});S.me.stars=r.stars;sfx('send');ingest(r.message);$('#msgs').scrollTop=$('#msgs').scrollHeight;emo.hidden=true;toast('🎁 گیفت فرستاده شد',false)}catch(e){toast(e.message)}}
async function renderGiftPanel(){
  if(!S.me.premium){giftGrid.replaceChildren(h('div',{class:'hint',style:'line-height:2.1'},'🔒 بخش گیفت فقط برای مشترکین پریمیومه',
    h('button',{class:'btn',style:'width:auto;padding:7px 18px;display:block;margin:8px auto 2px',onclick:async()=>{try{const r=await call('premium_activate');S.me.premium=true;S.me.stars=r.stars;toast('⭐ پریمیوم فعال شد و '+fa(r.bonus||0)+' ستاره هدیه گرفتی!',false);renderGiftPanel()}catch(e){toast(e.message)}}},'فعال‌سازی پریمیوم ⭐')));return}
  giftGrid.replaceChildren(h('div',{class:'hint'},'در حال بارگذاری…'));
  try{const r=await call('stars_me');S.me.stars=r.stars;S.unlimited=r.unlimited;
    const cell=(g,isNft)=>h('button',{type:'button',class:'giftcell'+(isNft?' nftcell':'')+(isNft&&g.id==='nft_eternal'?' uni1':''),onclick:()=>sendGiftFromPanel(g,isNft)},
      h('span',{class:'giftart aemo a-'+emoAnim(g.art)},g.art),h('b',{},g.name),
      isNft?h('small',{style:'color:#e8a13a'},'💵 $'+g.usd):null,h('small',{},'⭐ '+fa(isNft?g.price_stars:g.price)),
      isNft?h('small',{class:'muted'},'مونده: '+fa(g.supply-g.minted)):null);
    giftGrid.replaceChildren(h('div',{class:'giftbal'},r.unlimited?'♾️ موجودی تو: نامحدود':'⭐ موجودی تو: '+fa(r.stars)+' ستاره'),
      h('div',{class:'giftgrid'},...r.catalog.map(g=>cell(g,false)),...(r.nft_catalog||[]).map(g=>{const b=cell(g,true);b.onclick=()=>{if(g.supply-g.minted<=0)return toast('این NFT کاملاً فروخته شده 🏁');emo.hidden=true;const c=S.chats[S.current];if(c&&c.kind==='private'&&c.peer&&!c.saved)nftDetail(g,'@'+c.peer.username);else dlgGifts()};return b})));
  }catch(e){giftGrid.replaceChildren(h('div',{class:'hint'},e.message))}}
const cherryGrid=h('div',{class:'emogrid stkgrid',hidden:true});
function renderCherryPanel(){
  if(!S.me.premium){cherryGrid.replaceChildren(h('div',{class:'hint',style:'line-height:2.1;grid-column:1/-1'},'🔒 پک استیکر چری 🍒 فقط برای مشترکین پریمیومه',
    h('button',{class:'btn',style:'width:auto;padding:7px 18px;display:block;margin:8px auto 2px',onclick:async()=>{try{const r=await call('premium_activate');S.me.premium=true;S.me.stars=r.stars;toast('⭐ پریمیوم فعال شد و '+fa(r.bonus||0)+' ستاره هدیه گرفتی!',false);renderCherryPanel()}catch(e){toast(e.message)}}},'فعال‌سازی پریمیوم ⭐')));return}
  if(cherryGrid.dataset.done)return;cherryGrid.dataset.done='1';cherryGrid.replaceChildren();
  for(let n=1;n<=23;n++)cherryGrid.append(h('button',{type:'button',class:'stkimgbtn',title:'استیکر چری 🍒',onclick:()=>sendSticker('cherry:'+n)},h('img',{src:'/static/ch'+n+'.webp',alt:'🍒',loading:'lazy',style:'width:64px;height:64px;object-fit:contain'})))}
const myStkGrid=h('div',{class:'emogrid stkgrid',hidden:true});
async function renderMyStickers(){
  myStkGrid.replaceChildren(h('div',{class:'hint',style:'grid-column:1/-1'},'در حال بارگذاری…'));
  try{const r=await call('my_stickers');const items=r.stickers||[];const kids=[];
    if(!items.length)kids.push(h('div',{class:'hint',style:'grid-column:1/-1;line-height:2'},'هنوز استیکر شخصی نداری 🧩'));
    items.forEach(x=>{kids.push(h('button',{type:'button',class:'stkimgbtn',style:'position:relative',title:'استیکر من',onclick:()=>sendSticker('user:'+x.id)},
      h('img',{src:'/ustk/'+x.id+'?k='+encodeURIComponent(S.mediaKey||''),alt:'🧩',loading:'lazy',style:'width:64px;height:64px;object-fit:contain'}),
      h('span',{style:'position:absolute;top:2px;inset-inline-end:2px;background:rgba(0,0,0,.55);color:#fff;border-radius:50%;width:18px;height:18px;font-size:11px;line-height:18px;text-align:center',onclick:async e=>{e.stopPropagation();if(!confirm('این استیکر حذف بشه؟'))return;try{await call('sticker_delete',{id:x.id});renderMyStickers()}catch(err){toast(err.message)}}},'✕')))});
    kids.push(h('button',{class:'btn',style:'grid-column:1/-1;margin-top:6px',onclick:()=>{emo.hidden=true;openPrivate('DarkStickers')}},'➕ ساخت استیکر جدید با @DarkStickers'));
    myStkGrid.replaceChildren(...kids);
  }catch(e){myStkGrid.replaceChildren(h('div',{class:'hint',style:'grid-column:1/-1'},e.message))}}
const emoTabs=h('div',{class:'emotabs'},h('button',{type:'button',class:'on'},'ایموجی'),h('button',{type:'button'},'⭐ استیکر پریمیوم'),h('button',{type:'button'},'⭐ ایموجی پریمیوم'),h('button',{type:'button'},'🎁 گیفت'),h('button',{type:'button'},'🍒 چری'),h('button',{type:'button'},'🧩 استیکر من'));
const emoGrids=[emoGrid,stkGrid,premGrid,giftGrid,cherryGrid,myStkGrid];
[...emoTabs.children].forEach((b,i)=>b.onclick=()=>{emoGrids.forEach((g,j)=>g.hidden=j!==i);[...emoTabs.children].forEach((x,j)=>x.classList.toggle('on',j===i));if(i===3)renderGiftPanel();if(i===4)renderCherryPanel();if(i===5)renderMyStickers()});
emo.replaceChildren(emoTabs,emoGrid,stkGrid,premGrid,giftGrid,cherryGrid,myStkGrid);
$('#emo').onclick=e=>{e.stopPropagation();emo.hidden=!emo.hidden};
/* drag & drop files */
let dragN=0;const main=$('#main');
main.addEventListener('dragenter',e=>{if(!S.current||!(e.dataTransfer&&[...e.dataTransfer.types].includes('Files')))return;e.preventDefault();dragN++;$('#dropz').hidden=false});
main.addEventListener('dragover',e=>{if(S.current)e.preventDefault()});
main.addEventListener('dragleave',()=>{if(--dragN<=0){dragN=0;$('#dropz').hidden=true}});
main.addEventListener('drop',e=>{e.preventDefault();dragN=0;$('#dropz').hidden=true;if(S.current&&e.dataTransfer.files.length)sendFiles(e.dataTransfer.files)});
document.addEventListener('click',e=>{$('#ctx').hidden=true;if(!e.target.closest('#emoji,#emo'))emo.hidden=true});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('#ctx').hidden=true;emo.hidden=true;openDrawer(false);if(!$('#modal').hidden)closeDialog();else if(!$('#lightbox').hidden){$('#lightbox').hidden=true}else if(!$('#schbar').hidden)closeSearch();else if(S.reply||S.editing){clearBar()}}});
window.addEventListener('online',()=>{if(getToken()&&(!ws||ws.readyState!==1))reconnect()});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')resumeCall();if(document.visibilityState==='visible'&&getToken()){if(!ws||ws.readyState!==1)reconnect();else if(S.me){const sk=ws;Promise.race([call('ping'),new Promise((_,r)=>setTimeout(()=>r(0),6000))]).catch(()=>sockDead(sk))}}if(S.current)markRead(S.current)});
window.addEventListener('focus',()=>{if(S.current)markRead(S.current)});
try{setTheme(lsGet('wd-theme','midnight'));applyAccent(PREF.accent);applySize(PREF.size);applyTheme2(lsGet('wd-theme2',''))}catch{}
grabJoinFromUrl();
applyWall();$('#wallfile').addEventListener('change',e=>{pickWallImage(e.target.files[0]);e.target.value=''});
boot();

/* finger-following swipes (like Telegram): drag a chat to the right = back to the list (the list shows underneath);
   drag the chat list left/right = next/previous filter tab */
(()=>{
  const phone=()=>matchMedia('(max-width:760px)').matches,app=$('#app'),main=$('#main'),side=$('#side'),list=$('#list');
  if(!app||!main||!side||!list)return;
  const blocked=t=>t.closest('input,textarea,select,#emoji,#lightbox,#callui,.wv,.prng,video,audio,#schbar')||document.getElementById('psheet')||!$('#modal').hidden||!$('#ctx').hidden;
  const raf2=f=>requestAnimationFrame(()=>requestAnimationFrame(f));
  // ---- chat -> list
  let a=null;
  main.addEventListener('touchstart',e=>{a=null;if(!phone()||!app.classList.contains('show-chat')||e.touches.length!==1||blocked(e.target))return;
    const p=e.touches[0];a={x:p.clientX,y:p.clientY,t:Date.now(),on:false,dx:0}},{passive:true});
  main.addEventListener('touchmove',e=>{if(!a)return;const p=e.touches[0],dx=p.clientX-a.x,dy=p.clientY-a.y;
    if(!a.on){if(Math.abs(dy)>14&&Math.abs(dy)>=Math.abs(dx)){a=null;return}
      if(dx>14&&dx>Math.abs(dy)*1.5){a.on=true;a.x=p.clientX;main.style.transition='none';main.style.boxShadow='-8px 0 24px rgba(0,0,0,.4)';
        side.style.transition='none';side.style.transform='none';side.style.zIndex=1;side.style.opacity='.85'}else return}
    a.dx=Math.max(0,p.clientX-a.x);main.style.transform='translateX('+a.dx+'px)';side.style.opacity=String(.85+.15*Math.min(1,a.dx/main.offsetWidth))},{passive:true});
  const endA=()=>{const s=a;a=null;if(!s||!s.on)return;
    const W=main.offsetWidth||360,go=s.dx>W*.33||(s.dx>50&&Date.now()-s.t<280);
    main.style.transition='transform .2s ease-out';main.style.transform=go?'translateX('+W+'px)':'translateX(0)';
    setTimeout(()=>{
      if(go)$('#back').click();
      main.style.transition='';main.style.transform='';main.style.boxShadow='';
      side.style.transition='none';side.style.transform='';side.style.zIndex='';side.style.opacity='';
      void side.offsetWidth;raf2(()=>{side.style.transition=''})},go?210:210)};
  main.addEventListener('touchend',endA,{passive:true});main.addEventListener('touchcancel',endA,{passive:true});
  // ---- list: tabs
  let b=null;
  list.addEventListener('touchstart',e=>{b=null;if(!phone()||e.touches.length!==1||blocked(e.target))return;const p=e.touches[0];b={x:p.clientX,y:p.clientY,t:Date.now(),on:false,dx:0}},{passive:true});
  list.addEventListener('touchmove',e=>{if(!b)return;const p=e.touches[0],dx=p.clientX-b.x,dy=p.clientY-b.y;
    if(!b.on){if(Math.abs(dy)>14&&Math.abs(dy)>=Math.abs(dx)){b=null;return}
      if(Math.abs(dx)>14&&Math.abs(dx)>Math.abs(dy)*1.5){b.on=true;b.x=p.clientX;list.style.transition='none'}else return}
    const i=FILTERS.findIndex(f=>f[0]===S.filter),n=i+(p.clientX-b.x<0?1:-1),ok=n>=0&&n<FILTERS.length;
    b.dx=p.clientX-b.x;list.style.transform='translateX('+(ok?b.dx:b.dx*.2)+'px)'},{passive:true});
  const endB=()=>{const s=b;b=null;if(!s||!s.on)return;
    const W=list.offsetWidth||360,i=FILTERS.findIndex(f=>f[0]===S.filter),dir=s.dx<0?1:-1,n=i+dir,
      go=n>=0&&n<FILTERS.length&&(Math.abs(s.dx)>W*.25||(Math.abs(s.dx)>50&&Date.now()-s.t<280));
    list.style.transition='transform .14s ease-out';
    if(!go){list.style.transform='translateX(0)';setTimeout(()=>{list.style.transition='';list.style.transform=''},150);return}
    list.style.transform='translateX('+(dir>0?-W:W)+'px)';
    setTimeout(()=>{S.filter=FILTERS[n][0];renderFilters();renderList();list.scrollTop=0;
      const f=$('#filters .on');if(f&&f.scrollIntoView)f.scrollIntoView({inline:'center',block:'nearest'});
      list.style.transition='none';list.style.transform='translateX('+(dir>0?W:-W)+'px)';void list.offsetWidth;
      list.style.transition='transform .16s ease-out';list.style.transform='translateX(0)';
      setTimeout(()=>{list.style.transition='';list.style.transform=''},180)},150)};
  list.addEventListener('touchend',endB,{passive:true});list.addEventListener('touchcancel',endB,{passive:true});
})();

/* ---------- full music player sheet (tap the mini player): playlist of the chat's songs + seek bar + repeat/prev/play/next ---------- */
IC.repeat="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z";
IC.repeat1="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zm-4-2V9h-1l-2 1v1h1.5v4H13z";
function songTitle(m){return m.file.name.replace(/\.[^.]+$/,'')}
function closeSheet(){const e=document.getElementById('psheet');if(e)e.remove();const sc=document.getElementById('psheet-scrim');if(sc)sc.remove()}
function openPlayer(){
  if(!VP.m||VP.m.file.voice)return;closeSheet();
  const sc=h('div',{id:'psheet-scrim',onclick:closeSheet}),sh=h('div',{id:'psheet'});document.body.append(sc,sh);
  const grip=h('div',{class:'pgrip'}),list=h('div',{class:'plist'}),
    tt=h('div',{class:'ptt'}),ts=h('div',{class:'pts'}),
    rng=h('input',{type:'range',class:'prng',min:0,max:1000,value:0,oninput:e=>{const a=VP.audio;if(a&&isFinite(a.duration))a.currentTime=e.target.value/1000*a.duration}}),
    t0=h('span',{},fmtDur(0)),t1=h('span',{},fmtDur(0)),
    rep=h('button',{class:'iconbtn',type:'button',title:'تکرار',onclick:()=>{VP.repeat=VP.repeat==='all'?'one':VP.repeat==='one'?'':'all';paintSheet()}}),
    prev=h('button',{class:'iconbtn',type:'button',onclick:()=>VP.m&&playNext(VP.m,-1)}),
    pp=h('button',{class:'iconbtn pbig',type:'button',onclick:()=>{if(VP.audio)VP.audio.paused?VP.audio.play().catch(()=>{}):VP.audio.pause()}}),
    next=h('button',{class:'iconbtn',type:'button',onclick:()=>VP.m&&playNext(VP.m,1)}),
    more=h('button',{class:'iconbtn',type:'button',onclick:e=>{e.stopPropagation();menu.hidden=!menu.hidden}}),
    menu=h('div',{class:'pmenu',hidden:true},
      h('button',{type:'button',onclick:()=>{const m=VP.m;closeSheet();if(m&&S.chats[m.chat_id])openChat(m.chat_id,m.id)}},'رفتن به پیام'),
      h('button',{type:'button',onclick:()=>{menu.hidden=true;if(VP.m)download(VP.m)}},'دانلود'),
      h('button',{type:'button',onclick:()=>{VP.rate=VP.rate===1?1.5:VP.rate===1.5?2:1;if(VP.audio)VP.audio.playbackRate=VP.rate;menu.hidden=true;paintSheet()}},'سرعت پخش'));
  setIcon(prev,'skipprev',26);setIcon(next,'skipnext',26);setIcon(more,'more',22);
  sh.append(grip,list,h('div',{class:'pnow'},tt,ts,rng,h('div',{class:'ptimes'},t0,t1),h('div',{class:'pctl'},rep,prev,pp,next,more),menu));
  sh._p={list,tt,ts,rng,t0,t1,rep,pp,prev,next};
  let y0=null;grip.addEventListener('touchstart',e=>{y0=e.touches[0].clientY},{passive:true});
  sh.addEventListener('touchend',e=>{if(y0!=null&&e.changedTouches[0].clientY-y0>70&&e.target.closest('.pgrip,.pnow'))closeSheet();y0=null},{passive:true});
  paintSheet(true)}
function paintSheet(rebuild){
  const sh=document.getElementById('psheet');if(!sh)return;
  if(!VP.m||!VP.audio||VP.m.file.voice){closeSheet();return}
  const q=sh._p,m=VP.m,a=VP.audio;
  const songs=songsOf(m.chat_id),sig=songs.map(x=>x.id).join(',');
  if(rebuild||q.list._sig!==sig){q.list._sig=sig;
    q.list.replaceChildren(...songs.map(x=>{const on=x.id===m.id,b=h('button',{class:'prow'+(on?' on':''),type:'button',onclick:()=>{VP.mid===x.id&&VP.audio?(VP.audio.paused?VP.audio.play().catch(()=>{}):VP.audio.pause()):startPlay(x,null)}},
      h('span',{class:'pcov'},ic(on&&!a.paused?'pause':'play',22)),h('div',{class:'pmeta'},h('b',{},songTitle(x)),h('small',{},x.sender_id===S.me.id?'تو':(x.sender_name||''))));return b}));
    const cur=q.list.querySelector('.on');if(cur&&cur.scrollIntoView)cur.scrollIntoView({block:'nearest'})}
  else [...q.list.children].forEach((b,i)=>{const on=songs[i].id===m.id;b.classList.toggle('on',on);setIcon(b.firstChild,on&&!a.paused?'pause':'play',22)});
  q.tt.textContent=songTitle(m);q.ts.textContent=(m.sender_id===S.me.id?'تو':(m.sender_name||''))+(VP.rate!==1?' · ×'+fa(VP.rate):'');
  setIcon(q.pp,a.paused?'play':'pause',34);setIcon(q.rep,VP.repeat==='one'?'repeat1':'repeat',24);q.rep.classList.toggle('on',!!VP.repeat);
  q.prev.disabled=!neighbour(m,-1);q.next.disabled=!neighbour(m,1);paintSheetBar()}
function paintSheetBar(){
  const sh=document.getElementById('psheet'),a=VP.audio;if(!sh||!sh._p||!a)return;const q=sh._p;
  if(!q.rng._drag&&document.activeElement!==q.rng)q.rng.value=isFinite(a.duration)&&a.duration?Math.round(a.currentTime/a.duration*1000):0;
  q.t0.textContent=fmtDur(a.currentTime);q.t1.textContent=isFinite(a.duration)?fmtDur(a.duration):'—'}

;(()=>{const w=document.getElementById('wall');if(w&&window.ResizeObserver){let t=null;new ResizeObserver(()=>{clearTimeout(t);t=setTimeout(()=>{const v=lsGet('wd-wall','')||'';if(v.startsWith('mine:')&&Object.keys(wallSet(v.slice(5))).length)applyWall()},80)}).observe(w)}})();
