/* Teegram extras: default dark theme + attach pill menu (gallery / file / music) */
(()=>{
const d=document;
try{if(!Object.keys(localStorage).some(k=>k.includes('wd-theme')))d.documentElement.dataset.theme='dark'}catch{}
const S=(p)=>`<svg viewBox="0 0 24 24">${p}</svg>`;
const ITEMS=[
 ['گالری','image/*,video/*',S('<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 4 3-3 4 4"/>')],
 ['فایل','',S('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>')],
 ['موزیک','audio/*',S('<circle cx="12" cy="12" r="9"/><path d="M10 8.5l5 3.5-5 3.5z"/>')]];
let box=null;
const close=()=>{if(box){box.remove();box=null}};
const btn=d.getElementById('attach'),file=d.getElementById('file');
if(!btn||!file)return;
btn.addEventListener('click',e=>{
  e.stopImmediatePropagation();e.preventDefault();
  if(box)return close();
  box=d.createElement('div');box.id='tgattach';
  for(const [t,acc,svg] of ITEMS){
    const b=d.createElement('button');b.type='button';b.innerHTML=svg+'<span></span>';b.lastChild.textContent=t;
    b.onclick=()=>{close();if(acc)file.setAttribute('accept',acc);else file.removeAttribute('accept');file.click()};
    box.append(b);
  }
  d.body.append(box);
  const r=btn.getBoundingClientRect();
  box.style.bottom=(innerHeight-r.top+10)+'px';
  box.style.left=Math.max(8,Math.min(r.left,innerWidth-box.offsetWidth-8))+'px';
},true);
file.addEventListener('change',()=>setTimeout(()=>file.removeAttribute('accept'),0));
d.addEventListener('click',e=>{if(box&&!box.contains(e.target)&&e.target!==btn&&!btn.contains(e.target))close()});
})();

/* verified ticks: the server appends an invisible marker (U+2063 + U+200B/200C/200D) to names of verified accounts;
   draw it as a tick — U+200D is the DarkGram OWNER: crown + «مالک دارک گرام» label */
(()=>{
const d=document,RX=/\u2063([\u200B\u200C\u200D\u200E\u200F\u200A\u2060\u2061\u2062])/g;
const PREM_SVG='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="url(#premGrad)" stroke="url(#premGrad)" stroke-width="1.5" stroke-linejoin="round" d="M12 2.6l2.95 6.18 6.8.86-4.98 4.7 1.28 6.72L12 17.77l-6.05 3.29 1.28-6.72-4.98-4.7 6.8-.86z"/></svg>';
(function(){const add=()=>{if(d.getElementById('premGrad')||!d.body)return;const dv=d.createElement('div');dv.style.display='none';dv.setAttribute('aria-hidden','true');dv.innerHTML='<svg width="0" height="0"><defs><linearGradient id="premGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#C86BFF"/><stop offset=".55" stop-color="#8A5CFF"/><stop offset="1" stop-color="#5B8CFF"/></linearGradient></defs></svg>';d.body.append(dv)};if(d.body)add();else d.addEventListener('DOMContentLoaded',add)})();
const SVG='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 1.6l2.5 1.7 3-.2 1.3 2.7 2.7 1.3-.2 3L23 12l-1.7 2.5.2 3-2.7 1.3-1.3 2.7-3-.2L12 22.4l-2.5-1.7-3 .2-1.3-2.7-2.7-1.3.2-3L1 12l1.7-2.5-.2-3 2.7-1.3 1.3-2.7 3 .2z"/><path d="M7.6 12.4l3 3 5.9-6.3" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const BOUNTY_SVG='<svg viewBox="0 0 48 48" aria-hidden="true"><defs><radialGradient id="bntG" cx="38%" cy="32%" r="80%"><stop offset="0%" stop-color="#ffe98a"/><stop offset="55%" stop-color="#f5b921"/><stop offset="100%" stop-color="#b97e0a"/></radialGradient></defs><path d="M17 3l7 10 7-10 5 20-8-6h-8l-8 6z" fill="#d33f2e"/><path d="M24 13L17 3H12l4 20 4-7z" fill="#2b6cff"/><circle cx="24" cy="29" r="15.5" fill="url(#bntG)"/><circle cx="24" cy="29" r="12.3" fill="#20242c"/><g fill="#ffd94d"><ellipse cx="24" cy="30" rx="4.6" ry="6"/><circle cx="24" cy="22.6" r="3.1"/><path d="M24 24v12M20 27l-5-2.6M20 31l-5.4.6M28 27l5-2.6M28 31l5.4.6M21.4 36.4L18 40M26.6 36.4L30 40" stroke="#ffd94d" stroke-width="1.7" fill="none" stroke-linecap="round"/></g><circle cx="24" cy="29" r="13.6" fill="none" stroke="#ff3b30" stroke-width="3.4"/><path d="M14.5 38.5L33.5 19.5" stroke="#ff3b30" stroke-width="3.4" stroke-linecap="round"/></svg>';
const CROWN='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 8.2l4.6 3.9L12 5.2l4.4 6.9L21 8.2l-1.7 9.4H4.7L3 8.2zm1.9 11.1h14.2v1.9H4.9v-1.9z"/></svg>';
function fix(t){
  let v=t.nodeValue;if(!v||(v.indexOf('\u2063')<0&&v.indexOf('\u2064')<0))return;
  const p=t.parentNode;if(!p||(p.closest&&p.closest('script,style,textarea,[contenteditable=true]')))return;
  const prem=v.indexOf('\u2064')>=0;if(prem)v=v.replace(/\u2064/g,'');
  v=v.replace(/\u2063(?![\u200B\u200C\u200D\u200E\u200F\u200A\u2060\u2061\u2062])/g,'');
  if(v.indexOf('\u2063')<0){if(v!==t.nodeValue)t.replaceWith(v);return}
  const f=d.createDocumentFragment();let last=0,m;RX.lastIndex=0;
  while((m=RX.exec(v))){
    if(m.index>last)f.append(v.slice(last,m.index));
    if(m[1]==='\u200D'){
      const s=d.createElement('span');s.className='vb vb3';s.innerHTML=CROWN;s.title='مالک دارک گرام';f.append(s);
      const tag=d.createElement('span');tag.className='owntag';tag.textContent='مالک دارک گرام';f.append(tag);
    }else if(m[1]==='\u200E'){
      const tag=d.createElement('span');tag.className='offtag';tag.textContent='کانال رسمی';tag.title='کانال رسمی دارک گرام';f.append(tag);
    }else if(m[1]==='\u200F'){
      const tag=d.createElement('span');tag.className='fakeflag';tag.textContent='FAKE';tag.title='Fake account';f.append(tag);
    }else if(m[1]==='\u2062'){
      const tag=d.createElement('span');tag.className='scamflag';tag.textContent='SCAM';tag.title='حساب کلاهبرداری';f.append(tag);
    }else if(m[1]==='\u2061'){
      const tag=d.createElement('span');tag.className='newstag';tag.textContent='📢 اطلاع‌رسانی';tag.title='کانال اطلاع‌رسانی';f.append(tag);
    }else if(m[1]==='\u2060'){
      const tag=d.createElement('span');tag.className='bountymedal';tag.innerHTML=BOUNTY_SVG;tag.title='مدال باگ بانتی دارک گرام';f.append(tag);
    }else if(m[1]==='\u200A'){
      const tag=d.createElement('span');tag.className='loyaltag';tag.textContent='💙 کاربر وفادار';tag.title='کاربر وفادار دارک گرام';f.append(tag);
    }else{
      const s=d.createElement('span');s.className='vb vb'+(m[1]==='\u200B'?1:2);s.innerHTML=SVG;f.append(s);
    }
    last=RX.lastIndex;
  }
  if(last<v.length)f.append(v.slice(last));
  if(prem){const st=d.createElement('span');st.className='premstar';st.innerHTML=PREM_SVG;st.title='دارک گرام پریمیوم';f.append(st)}
  t.replaceWith(f);
}
function scan(root){
  if(root.nodeType===3)return fix(root);
  if(root.nodeType!==1)return;
  const tc=root.textContent;if(!tc||(tc.indexOf('\u2063')<0&&tc.indexOf('\u2064')<0))return;
  const w=d.createTreeWalker(root,NodeFilter.SHOW_TEXT),a=[];let n;
  while((n=w.nextNode()))if(n.nodeValue.indexOf('\u2063')>=0||n.nodeValue.indexOf('\u2064')>=0)a.push(n);
  a.forEach(fix);
}
const _mq=new Set();let _mf=false;
function _mflush(){_mf=false;const rs=[..._mq];_mq.clear();for(const r of rs){if(!r.isConnected)continue;if(r.nodeType===3)fix(r);else scan(r)}}
function _mqueue(n){_mq.add(n);if(!_mf){_mf=true;requestAnimationFrame(_mflush)}}
new MutationObserver(ms=>{for(const m of ms){if(m.type==='characterData')_mqueue(m.target);else m.addedNodes.forEach(_mqueue)}})
  .observe(d.body,{childList:true,subtree:true,characterData:true});
scan(d.body);
})();
