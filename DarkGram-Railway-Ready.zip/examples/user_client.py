#!/usr/bin/env python3
"""Use your own account through the API.   python examples/user_client.py https://SERVER:8443 12:TOKEN [--insecure]
Get the token from BotFather: /usertoken.   Prints every new message sent to you; reply with ".. " in the chat to test."""
import json, ssl, sys, urllib.request

args = [a for a in sys.argv[1:] if not a.startswith("--")]
if len(args) != 2:
    sys.exit(__doc__)
BASE = f"{args[0].rstrip('/')}/user{args[1]}/"
CTX = ssl._create_unverified_context() if "--insecure" in sys.argv else None

def call(method, **p):
    req = urllib.request.Request(BASE + method, json.dumps(p).encode(), {"Content-Type": "application/json"})
    return json.load(urllib.request.urlopen(req, timeout=60, context=CTX))["result"]

print("me:", call("getMe"))
offset = -1
while True:
    for u in call("getUpdates", offset=offset, timeout=25):
        offset = u["update_id"] + 1
        m = u["message"]
        print(f"[{m['chat'].get('title') or m['chat'].get('username')}] {m['from']['first_name']}: {m['text']}")
        if m["text"].startswith("/ping"):
            call("sendMessage", chat_id=m["chat"]["id"], text="pong 🏓", reply_to_message_id=m["message_id"])
