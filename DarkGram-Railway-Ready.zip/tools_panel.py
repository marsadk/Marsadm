"""Datasheet tool window: send announcements (any file type) and edit BotFather's name/bio/photo.
Talks to the running server through its local admin API (127.0.0.1 + the key in data/admin.key)."""
import json
import os
import ssl
import threading
import tkinter as tk
import urllib.error
import urllib.parse
import urllib.request
from tkinter import filedialog, ttk

import common

PORT = int(os.environ.get("TEEGRAM_WEB_PORT", "8087"))


def api(action, params=None, body=None):
    """POST /admin/<action>. `params` -> JSON body; `body` (bytes) -> raw body with `params` in the query string."""
    key = (common.DATA_DIR / "admin.key").read_text().strip()
    last = None
    for scheme in ("https", "http"):
        url = f"{scheme}://127.0.0.1:{PORT}/admin/{action}"
        if body is not None:
            url += "?" + urllib.parse.urlencode(params or {})
            data, ctype = body, "application/octet-stream"
        else:
            data, ctype = json.dumps(params or {}).encode(), "application/json"
        req = urllib.request.Request(url, data=data, headers={"Content-Type": ctype, "X-Admin-Key": key})
        try:
            ctx = ssl._create_unverified_context() if scheme == "https" else None
            with urllib.request.urlopen(req, timeout=120, context=ctx) as r:
                return json.loads(r.read())["result"]
        except urllib.error.HTTPError as e:
            try:
                raise RuntimeError(json.loads(e.read()).get("description", str(e)))
            except ValueError:
                raise RuntimeError(str(e))
        except (urllib.error.URLError, ssl.SSLError, ConnectionError, OSError) as e:
            last = e
    raise RuntimeError(f"به سرور وصل نشد (پورت {PORT}؛ سرور روشنه؟): {last}")


def open_tools(parent, T, font):
    win = tk.Toplevel(parent)
    win.title("اطلاعیه و BotFather")
    win.configure(bg=T["bg"])
    win.geometry("560x560")
    nb = ttk.Notebook(win)
    nb.pack(fill="both", expand=True, padx=12, pady=12)
    status = tk.Label(win, text="", bg=T["bg"], fg=T["muted"], font=font(10), anchor="w")
    status.pack(fill="x", padx=14, pady=(0, 10))

    def say(msg, bad=False):
        status.config(text=msg, fg=T["danger"] if bad else T["muted"])

    def run(work, done):
        def th():
            try:
                res, err = work(), None
            except Exception as e:
                res, err = None, e
            win.after(0, lambda: (say(str(err), True) if err else done(res)))
        threading.Thread(target=th, daemon=True).start()

    def lab(parent_, text):
        tk.Label(parent_, text=text, bg=T["side"], fg=T["muted"], font=font(10), anchor="e").pack(fill="x", padx=14, pady=(10, 2))

    def entry(parent_):
        e = tk.Entry(parent_, bg=T["entry"], fg=T["text"], insertbackground=T["text"], relief="flat", font=font(11), justify="right")
        e.pack(fill="x", padx=14, ipady=6)
        return e

    # ---------------- announcements
    ann = tk.Frame(nb, bg=T["side"])
    nb.add(ann, text="📣 اطلاعیه‌ها")
    lab(ann, "متن اطلاعیه (برای همه‌ی کاربران)")
    txt = tk.Text(ann, height=9, bg=T["entry"], fg=T["text"], insertbackground=T["text"], relief="flat", font=font(11), wrap="word")
    txt.pack(fill="both", expand=True, padx=14)
    chosen = {"path": None}
    fl = tk.Label(ann, text="فایلی انتخاب نشده", bg=T["side"], fg=T["muted"], font=font(10))
    voice = tk.IntVar(value=0)

    def pick_file():
        p = filedialog.askopenfilename(parent=win, title="عکس، ویدیو، موزیک یا هر فایلی")
        if p:
            chosen["path"] = p
            fl.config(text=os.path.basename(p))

    def clear_file():
        chosen["path"] = None
        fl.config(text="فایلی انتخاب نشده")
    row = tk.Frame(ann, bg=T["side"])
    row.pack(fill="x", padx=14, pady=8)
    tk.Button(row, text="📎 انتخاب فایل", command=pick_file, relief="flat", bg=T["entry"], fg=T["text"], font=font(10)).pack(side="left")
    tk.Button(row, text="✕", command=clear_file, relief="flat", bg=T["entry"], fg=T["text"], font=font(10)).pack(side="left", padx=4)
    tk.Checkbutton(row, text="به‌صورت پیام صوتی", variable=voice, bg=T["side"], fg=T["muted"], selectcolor=T["entry"],
                   activebackground=T["side"], font=font(10)).pack(side="right")
    fl.pack(fill="x", padx=14)

    def send():
        text, path = txt.get("1.0", "end").strip(), chosen["path"]
        if not text and not path:
            return say("متن یا فایل بذار", True)
        say("در حال ارسال…")

        def work():
            if path:
                with open(path, "rb") as f:
                    body = f.read()
                q = {"file_name": os.path.basename(path), "text": text[:300]}
                if voice.get():
                    q["voice"] = "1"
                r = api("announce", q, body)
                if len(text) > 300:
                    api("announce", {"text": text})
                return r
            return api("announce", {"text": text})

        def done(_r):
            txt.delete("1.0", "end")
            clear_file()
            say("✅ اطلاعیه برای همه فرستاده شد")
        run(work, done)
    tk.Button(ann, text="ارسال به همه", command=send, relief="flat", bg=T["accent"], fg="#fff", font=font(11, "bold"),
              pady=8).pack(fill="x", padx=14, pady=(4, 14))

    # ---------------- BotFather
    bf = tk.Frame(nb, bg=T["side"])
    nb.add(bf, text="🤖 BotFather")
    lab(bf, "اسم نمایشی")
    e_name = entry(bf)
    lab(bf, "بیوگرافی")
    e_bio = entry(bf)
    lab(bf, "توضیح ربات (در پروفایلش نشون داده می‌شه؛ تا ۲۰۰ حرف)")
    e_desc = entry(bf)
    photo = {"path": None}
    pl = tk.Label(bf, text="عکس جدید انتخاب نشده", bg=T["side"], fg=T["muted"], font=font(10))

    def pick_photo():
        p = filedialog.askopenfilename(parent=win, title="عکس BotFather", filetypes=[("image", "*.png *.jpg *.jpeg *.webp")])
        if p:
            photo["path"] = p
            pl.config(text=os.path.basename(p))
    tk.Button(bf, text="🖼 انتخاب عکس", command=pick_photo, relief="flat", bg=T["entry"], fg=T["text"], font=font(10)).pack(anchor="e", padx=14, pady=(12, 2))
    pl.pack(fill="x", padx=14)

    def fill(info):
        for e, k in ((e_name, "display_name"), (e_bio, "bio"), (e_desc, "description")):
            e.delete(0, "end")
            e.insert(0, info.get(k) or "")

    def save():
        say("در حال ذخیره…")

        def work():
            info = api("botfatherSet", {"display_name": e_name.get(), "bio": e_bio.get(), "description": e_desc.get()})
            if photo["path"]:
                with open(photo["path"], "rb") as f:
                    api("botfatherPhoto", {}, f.read())
            return info

        def done(info):
            photo["path"] = None
            pl.config(text="عکس جدید انتخاب نشده")
            fill(info)
            say("✅ مشخصات BotFather ذخیره شد")
        run(work, done)
    tk.Button(bf, text="ذخیره", command=save, relief="flat", bg=T["accent"], fg="#fff", font=font(11, "bold"),
              pady=8).pack(fill="x", padx=14, pady=(18, 14), side="bottom")
    run(lambda: api("botfatherGet"), lambda info: (fill(info), say("")))

    # ---------------- verified ticks
    tk_ = tk.Frame(nb, bg=T["side"])
    nb.add(tk_, text="✔ تیک آبی/زرد")
    target = tk.StringVar(value="user")
    tb = tk.Frame(tk_, bg=T["side"])
    tb.pack(fill="x", padx=14, pady=(10, 0))
    for val, text in (("chat", "گروه / کانال"), ("user", "کاربر / ربات")):
        tk.Radiobutton(tb, text=text, value=val, variable=target, bg=T["side"], fg=T["text"], selectcolor=T["entry"],
                       activebackground=T["side"], font=font(10)).pack(side="right", padx=8)
    lab(tk_, "کاربر/ربات: نام کاربری (بدون @)  ·  گروه/کانال: @نام‌کاربری عمومی، شناسه‌ی عددی یا اسم")
    e_user = entry(tk_)
    kind = tk.IntVar(value=1)
    box = tk.Frame(tk_, bg=T["side"])
    box.pack(fill="x", padx=14, pady=10)
    for val, text, color in ((1, "تیک آبی", "#3b9cf5"), (2, "تیک زرد", "#f5b301"), (0, "حذف تیک", T["muted"])):
        tk.Radiobutton(box, text="● " + text, value=val, variable=kind, bg=T["side"], fg=color, selectcolor=T["entry"],
                       activebackground=T["side"], activeforeground=color, font=font(11, "bold")).pack(side="right", padx=10)
    lst = tk.Label(tk_, text="", bg=T["side"], fg=T["muted"], font=font(10), justify="right", anchor="ne")

    def refresh_list():
        def done(rows):
            names = {1: "آبی", 2: "زرد"}
            lst.config(text="\n".join(f"{r['kind']}  {r['name']}  ←  {names.get(r['badge'], '')}" for r in rows) or "هنوز تیکی ثبت نشده")
        run(lambda: api("badgeList"), done)

    def apply_badge():
        u = e_user.get().strip()
        if not u:
            return say("هدف رو بنویس", True)
        say("در حال ثبت…")
        run(lambda: api("setBadge", {"kind": target.get(), "target": u, "badge": kind.get()}),
            lambda r: (say("✅ تیک «%s» %s" % (r["name"], "ثبت شد" if r["badge"] else "حذف شد")), refresh_list()))
    tk.Button(tk_, text="اعمال", command=apply_badge, relief="flat", bg=T["accent"], fg="#fff", font=font(11, "bold"),
              pady=8).pack(fill="x", padx=14, pady=(4, 10))
    tk.Label(tk_, text="دارای تیک:", bg=T["side"], fg=T["text"], font=font(10, "bold"), anchor="e").pack(fill="x", padx=14)
    lst.pack(fill="x", padx=14)
    refresh_list()
